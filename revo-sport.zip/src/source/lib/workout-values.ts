export function latinWorkoutDigits(value: string | number): string {
  return String(value ?? "")
    .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
    .replace(/[٫،,]/g, ".");
}

export function cleanWorkoutInput(value: string, decimal: boolean): string {
  const raw = latinWorkoutDigits(value).replace(decimal ? /[^\d.]/g : /[^\d]/g, "");
  const [whole, ...fraction] = raw.split(".");
  return (decimal && fraction.length ? `${whole}.${fraction.join("").slice(0, 2)}` : whole).slice(0, 7);
}

export function prescribedMetric(value: string, field: "weight" | "reps"): number {
  const raw = latinWorkoutDigits(value).trim();
  // An RPE instruction is not a kilogram prescription.
  const match = field === "weight"
    ? raw.match(/^(\d+(?:\.\d+)?)\s*(?:kg|kgs|کیلو|کیلوگرم)?$/i)
    : raw.match(/\d+/);
  return match ? Number(match[1] ?? match[0]) : 0;
}

export function resolvedMetric(value: string | undefined, prescription: string, field: "weight" | "reps"): number {
  const raw = latinWorkoutDigits(value ?? "").trim();
  if (raw && /^\d+(?:\.\d+)?$/.test(raw)) {
    return field === "reps" ? Math.floor(Number(raw)) : Number(raw);
  }
  return prescribedMetric(prescription, field);
}

/** تخمین یک تکرار بیشینه (1RM) با فرمول استاندارد Epley */
export function estimate1RM(weight: number, reps: number): number {
  if (!Number.isFinite(weight) || weight <= 0 || !Number.isFinite(reps) || reps <= 0) return 0;
  if (reps === 1) return Math.round(weight * 10) / 10;
  const raw = weight * (1 + Math.min(reps, 30) / 30);
  return Math.round(raw * 2) / 2;
}

const STANDARD_PLATES = [25, 20, 15, 10, 5, 2.5, 1.25] as const;

/** محاسبهٔ دیسک‌های هر سمت هالتر */
export function calculatePlates(
  totalWeight: number,
  barWeight = 20,
): { perSide: number; plates: number[]; remainder: number } {
  const total = Number.isFinite(totalWeight) ? Math.max(0, totalWeight) : 0;
  const bar = Number.isFinite(barWeight) ? Math.max(0, barWeight) : 0;
  if (total <= bar) return { perSide: 0, plates: [], remainder: 0 };
  const targetPerSide = Math.round(((total - bar) / 2) * 100) / 100;
  let left = targetPerSide;
  const plates: number[] = [];
  for (const plate of STANDARD_PLATES) {
    while (left + 1e-6 >= plate && plates.length < 16) {
      plates.push(plate);
      left = Math.round((left - plate) * 100) / 100;
    }
  }
  return { perSide: targetPerSide, plates, remainder: Math.max(0, left) };
}
