import type { GuideRole } from "../components/guide-content";

export interface GuideProgress {
  status: "in-progress" | "completed" | "skipped";
  step: string;
  updatedAt: string;
}

type SavedGuides = Record<string, GuideProgress>;
const sessionFallback = new Map<string, SavedGuides>();

export function guideStorageKey(role: GuideRole, userId: string): string {
  return `revo-guides-v1:${role}:${encodeURIComponent(userId)}`;
}

export function readGuideProgress(role: GuideRole, userId: string): SavedGuides {
  const key = guideStorageKey(role, userId);
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(key) ?? "{}");
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const clean: SavedGuides = {};
    for (const [page, record] of Object.entries(parsed)) {
      if (!record || typeof record !== "object") continue;
      const value = record as Partial<GuideProgress>;
      if (!["in-progress", "completed", "skipped"].includes(value.status ?? "")) continue;
      if (typeof value.step !== "string" || typeof value.updatedAt !== "string") continue;
      clean[page] = value as GuideProgress;
    }
    return { ...clean, ...sessionFallback.get(key) };
  } catch {
    return sessionFallback.get(key) ?? {};
  }
}

export function saveGuideProgress(role: GuideRole, userId: string, page: string, progress: GuideProgress): void {
  const key = guideStorageKey(role, userId);
  const next = { ...readGuideProgress(role, userId), [page]: progress };
  sessionFallback.set(key, next);
  try {
    localStorage.setItem(key, JSON.stringify(next));
  } catch {
    // Private browsing and full storage must never prevent using the app.
  }
}

export interface GuideRect { left: number; top: number; width: number; height: number }

export function placeGuidePanel(
  target: GuideRect | null,
  viewport: { left: number; top: number; width: number; height: number },
  panel: { width: number; height: number },
): { left: number; top: number; placement: "above" | "below" | "beside" | "center" } {
  const pad = 16;
  const gap = 20;
  const xMin = viewport.left + pad;
  const yMin = viewport.top + pad;
  const xMax = Math.max(xMin, viewport.left + viewport.width - panel.width - pad);
  const yMax = Math.max(yMin, viewport.top + viewport.height - panel.height - pad);
  const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
  const center = { left: (xMin + xMax) / 2, top: (yMin + yMax) / 2, placement: "center" as const };
  if (!target) return center;
  const left = clamp(target.left + target.width / 2 - panel.width / 2, xMin, xMax);
  if (target.top - gap - panel.height >= yMin) {
    return { left, top: target.top - gap - panel.height, placement: "above" };
  }
  if (target.top + target.height + gap <= yMax) {
    return { left, top: target.top + target.height + gap, placement: "below" };
  }
  if (viewport.width >= 860) {
    if (target.left - gap - panel.width >= xMin) {
      return { left: target.left - gap - panel.width, top: clamp(target.top, yMin, yMax), placement: "beside" };
    }
    if (target.left + target.width + gap <= xMax) {
      return { left: target.left + target.width + gap, top: clamp(target.top, yMin, yMax), placement: "beside" };
    }
  }
  const spaceAbove = target.top - viewport.top;
  const spaceBelow = viewport.top + viewport.height - (target.top + target.height);
  return { left, top: spaceAbove > spaceBelow ? yMin : yMax, placement: "center" };
}