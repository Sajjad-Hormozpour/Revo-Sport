export type Gender = "male" | "female";

const GENDER_KEY = "revo-profile-gender";

/** جنسیت مربوط به تجربهٔ کاربر: رسانه‌ها، پوسته و پیش‌فرض‌های تمرینی */
export function readGender(): Gender {
  try {
    return localStorage.getItem(GENDER_KEY) === "female" ? "female" : "male";
  } catch {
    return "male";
  }
}

export function writeGender(gender: Gender): void {
  try {
    localStorage.setItem(GENDER_KEY, gender);
  } catch {
    /* ignore */
  }
  applyGenderTheme(gender);
}

/** اعمال تم بصری جنسیت روی کل برنامه (رنگ‌های شاخص و پیش‌فرض‌ها) */
export function applyGenderTheme(gender: Gender = readGender()): void {
  try {
    document.documentElement.setAttribute("data-gender", gender);
  } catch {
    /* ignore */
  }
}

export function hasGenderChoice(): boolean {
  try {
    return localStorage.getItem(GENDER_KEY) === "male" || localStorage.getItem(GENDER_KEY) === "female";
  } catch {
    return false;
  }
}

/** نقش سمت داده‌ها: «زن» یا «مرد» */
export function genderFromProfile(value: string | undefined | null): Gender {
  return value === "زن" || value === "female" ? "female" : "male";
}

export function genderLabel(gender: Gender): string {
  return gender === "female" ? "بانوان" : "آقایان";
}

/** رنگ شاخص هر جنسیت: سبز-لیمویی برای آقایان، رز برای بانوان */
export function genderAccent(gender: Gender = readGender()): string {
  return gender === "female" ? "#ff4d8d" : "#c9f31c";
}


// پوسته را از همان لحظهٔ بارگذاری با جنسیت ذخیره‌شده هماهنگ نگه می‌دارد.
applyGenderTheme();
