import { currentLanguage, localize, localizeStatic } from "../../../i18n";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Home, Dumbbell, ClipboardList, TrendingUp, MessagesSquare, MessageCircle, Crown,
  Check, Moon, Bell, LogOut, Flame, Trophy, ChevronLeft, ChevronDown,
  Plus, Target, Sun, ArrowRight, Zap, Ticket, CalendarDays, X, Scale, Palette,
  CheckCircle, Lock, Coffee, Globe, Salad,
} from "lucide-react";
import { useStore } from "../../lib/store";
import { notifVisible, useNotifPrefs } from "../../lib/i18n";
import { LanguageSection, NotificationSection, SettingsSection } from "../../components/settings-blocks";
import { useLang } from "../../lib/i18n";
import { ExThumb, ExVideo, resolveExercise } from "../../components/exercise";
import { SessionClock, type SessionSetValue, type SetKind } from "../../components/session-view";
import { ImmersiveWorkout, RestOverlay, WorkoutModal, WorkoutOverview, type PreviousExerciseSummary } from "../../components/immersive-workout";
import { MuscleMiniMap, type MapGender } from "../../components/muscle-map";
import { StudentWorkoutHistory } from "../../components/workout-calendar";
import { GuideHelpButton, ProductGuide } from "../../components/product-guide";
import { fa, go } from "../../lib/core";
import { BrandBtn, ClockLive, Empty, Field, Pill, ProgressBar, inputCls } from "../../components/ui";
import { ChatThread } from "../../components/chat";
import SubscriptionView from "./Subscription";
import { StudentCheckin } from "../../components/checkin";
import { calculateAdherence } from "../../lib/adherence";
import { ProfileEditor } from "../../components/profile";
import { AppearanceSettings } from "../../components/appearance";
import {
  WEEK, addDays, dayKey, daysBetween, formatDateTime, formatJalaliDate, formatJalaliLong,
  formatRelative, greetingAt, nowIso, useNow, weekdayName,
} from "../../lib/time";
import { weekLogCount, workoutStreak, xpOf } from "../../lib/metrics";
import { serviceState } from "../../nutrition/engine";
import NutritionStudent from "../../nutrition/NutritionStudent";
import type { AppData, ProgramSet, WorkoutDay, WorkoutProgram } from "../../data/types";
import { estimate1RM, resolvedMetric } from "../../lib/workout-values";
import { applyGenderTheme, genderFromProfile, readGender, writeGender } from "../../lib/gender";

export type StudentView = "home" | "workout" | "history" | "progress" | "chat" | "subscription" | "profile" | "nutrition";

const NAV: { id: StudentView; label: string; icon: typeof Home }[] = [
  { id: "workout", label: "snav.workout", icon: Dumbbell },
  { id: "history", label: "snav.history", icon: ClipboardList },
  { id: "home", label: "snav.home", icon: Home },
  { id: "progress", label: "snav.progress", icon: TrendingUp },
  { id: "chat", label: "snav.chat", icon: MessagesSquare },
  { id: "subscription", label: "snav.subscription", icon: Crown },
];

const TITLES: Record<StudentView, string> = {
  home: "stitle.home",
  workout: "stitle.workout",
  history: "stitle.history",
  progress: "stitle.progress",
  chat: "stitle.chat",
  subscription: "stitle.subscription",
  profile: "stitle.profile",
  nutrition: "stitle.nutrition",
};

/** Shown only when the coach has enabled nutrition for this athlete. */
const NUTRITION_NAV: { id: StudentView; label: string; icon: typeof Home } = { id: "nutrition", label: "snav.nutrition", icon: Salad };

export default function StudentApp({
  view, onView, onToast,
}: {
  view: StudentView;
  onView: (v: StudentView) => void;
  onToast: (t: string, d: string) => void;
  onShare: () => void;
}) {
  const { session, studentOf, userById, data, logout, light, toggleLight } = useStore();
  const { t, dir } = useLang();
  const st = studentOf(session!.userId);
  const me = userById(session!.userId);
  const stack = useRef<StudentView[]>([]);
  const scroller = useRef<HTMLDivElement>(null);

  // جنسیت ثبت‌شده در پروفایل، منبع حقیقت رسانه‌ها و تم برنامه است
  useEffect(() => {
    const profileGender = st?.gender ? genderFromProfile(st.gender) : null;
    if (!profileGender) return;
    if (readGender() !== profileGender) {
      writeGender(profileGender);
    } else {
      applyGenderTheme(profileGender);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [st?.gender]);

  useEffect(() => {
    scroller.current?.scrollTo({ top: 0 });
  }, [view]);

  const mounted = useRef(false);
  useEffect(() => {
    if (!mounted.current) {
      mounted.current = true;
      if (view !== "home") onView("home");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const nav = (v: StudentView) => {
    if (v === view) return;
    stack.current.push(view);
    onView(v);
  };
  const back = () => {
    const prev = stack.current.pop();
    onView(prev ?? "home");
  };
  const tab = (v: StudentView) => {
    stack.current = v === "home" ? [] : ["home"];
    if (v !== view) onView(v);
  };

  if (!st || !me) {
    return (
      <div className="flex h-dvh items-center justify-center p-6 text-center">
        <div>
          <p className="font-black">{localizeStatic("پروفایل شاگرد پیدا نشد")}</p>
          <button className="mt-3 text-[#e9e400]" onClick={() => { logout(); go("/login"); }}>{localizeStatic("بازگشت به ورود")}</button>
        </div>
      </div>
    );
  }

  const unreadNotifs = data.notifs.filter((n) => !n.read).length;
  const unreadChat = data.messages.some((m) => m.from === "coach" && m.unread);
  const navItems = serviceState(data, st.id) !== "off" ? [NAV[0], NUTRITION_NAV, ...NAV.slice(1)] : NAV;
  const navCols = navItems.length;
  const idx = Math.max(0, navItems.findIndex((n) => n.id === (view === "profile" ? "subscription" : view)));

  return (
    <div data-guide-scope="student" className="mx-auto flex h-dvh max-w-lg flex-col bg-[var(--color-bg)] sm:border-x sm:border-[var(--color-line)]" dir={dir}>
      {view === "home" ? (
        <header className="glass-strong mobile-safe-top flex shrink-0 items-center justify-between gap-2 border-x-0 border-t-0 px-3 py-2.5 sm:px-4 sm:py-3">
          <button onClick={() => nav("profile")} className="press flex min-w-0 items-center gap-2.5 text-right">
            <span className="relative shrink-0">
              <img src={me.avatar} alt="" className="h-11 w-11 rounded-2xl object-cover ring-2 ring-[#e9e400]/50" />
              <span className="absolute -bottom-0.5 -left-0.5 h-3 w-3 rounded-full border-2 border-[var(--color-card)] bg-emerald-500" />
            </span>
            <div className="min-w-0">
              <p className="text-[10.5px] font-bold text-[#e9e400]">{localize(greetingAt())}</p>
              <b className="block truncate text-[14.5px] leading-5">{me.name}</b>
            </div>
          </button>
          <div className="flex items-center gap-1.5">
            <GuideHelpButton role="student" />
            <div className="glass-subtle hidden rounded-xl px-2.5 py-1 min-[380px]:block"><ClockLive compact /></div>
            <HeaderBtn onClick={toggleLight} label={localizeStatic("تم")}>{localize(light ? <Moon size={16} /> : <Sun size={16} />)}</HeaderBtn>
            <HeaderBtn onClick={() => nav("profile")} label={localizeStatic("اعلان‌ها")}>
              <Bell size={16} />
              {localize(unreadNotifs > 0 && <span className="absolute left-1.5 top-1.5 h-2 w-2 rounded-full bg-red-500 ring-2 ring-[var(--color-card)]" />)}
            </HeaderBtn>
          </div>
        </header>
      ) : (
        <header className="glass-strong mobile-safe-top flex shrink-0 items-center gap-2 border-x-0 border-t-0 px-2.5 py-2">
          <button onClick={back} className="press glass-subtle flex h-11 min-w-[92px] items-center justify-center gap-1.5 rounded-2xl px-3 text-[12.5px] font-black" aria-label={localizeStatic("بازگشت")}>
            <ArrowRight size={17} />{localizeStatic(" بازگشت")}</button>
          <b className="flex-1 truncate text-center text-[14px] font-black sm:text-[14.5px]">{localize(t(TITLES[view]))}</b>
          <GuideHelpButton role="student" />
          <div className="glass-subtle min-w-[76px] rounded-2xl px-2 py-1 text-left"><ClockLive compact /></div>
        </header>
      )}

      <div
        ref={scroller}
        data-guide="page-content"
        className={view === "chat" ? "min-h-0 flex-1 overflow-hidden" : "noscroll min-h-0 flex-1 overflow-y-auto px-4 pb-4 pt-1"}
      >
        {localize(view === "home" && <HomeView stId={st.id} nav={nav} />)}
        {localize(view === "workout" && <WorkoutView stId={st.id} onToast={onToast} nav={nav} />)}
        {localize(view === "nutrition" && <NutritionStudent stId={st.id} onToast={onToast} onChat={() => nav("chat")} />)}
        {localize(view === "history" && <HistoryView stId={st.id} nav={nav} />)}
        {localize(view === "progress" && <ProgressView stId={st.id} onToast={onToast} />)}
        {localize(view === "chat" && <ChatView stId={st.id} nav={nav} />)}
        {localize(view === "subscription" && <SubscriptionView stId={st.id} onGo={(v) => nav(v)} />)}
        {localize(view === "profile" && <ProfileView stId={st.id} onToast={onToast} />)}
      </div>

      <nav className="mobile-safe-bottom shrink-0 px-2.5 pt-1.5 sm:px-3">
        <div className="glass-strong relative grid grid-cols-6 rounded-[24px] p-1.5 shadow-[0_18px_44px_-20px_rgba(0,0,0,0.65)]" style={navCols !== 6 ? { gridTemplateColumns: `repeat(${navCols}, minmax(0, 1fr))` } : undefined}>
          <span
            aria-hidden
            className="pointer-events-none absolute bottom-1.5 top-1.5 rounded-[20px] bg-[#e9e400] shadow-[0_10px_24px_-10px_rgba(233,228,0,0.9)] transition-[right] duration-300 ease-out"
            style={{ width: `calc((100% - 12px) / ${navCols})`, right: `calc(6px + ${idx} * (100% - 12px) / ${navCols})` }}
          />
          {localize(navItems.map((n, i) => {
            const active = i === idx;
            const badge = n.id === "chat" && unreadChat;
            const isHome = n.id === "home";
            return (
              <button
                key={n.id}
                data-guide={`student-nav-${n.id}`}
                onClick={() => tab(n.id)}
                aria-label={localize(t(n.label))}
                aria-current={active ? "page" : undefined}
                className="press relative z-10 flex flex-col items-center justify-center gap-1 py-2"
              >
                <span className={`relative flex items-center justify-center rounded-full transition-colors duration-300 ${isHome && !active ? "bg-[#e9e400]/15 p-1" : ""}`}>
                  <n.icon size={isHome ? 23 : 21} strokeWidth={active ? 2.4 : 1.8} className={`transition-colors duration-300 ${active ? "text-black" : isHome ? "text-[#e9e400]" : "text-[var(--color-mute)]"}`} />
                  {localize(badge && <span className="absolute -left-1 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-[var(--color-card)] bg-red-500" />)}
                </span>
                <span className={`text-[9.5px] font-black leading-none transition-colors duration-300 ${active ? "text-black" : "text-[var(--color-mute)]"}`}>{localize(t(n.label))}</span>
              </button>
            );
          }))}
        </div>
      </nav>
      <ProductGuide role="student" userId={session!.userId} section={view} />
    </div>
  );
}

function HeaderBtn({ children, onClick, label }: { children: ReactNode; onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} aria-label={localize(label)} className="press relative flex h-9 w-9 items-center justify-center rounded-full bg-[var(--color-card)]">
      {localize(children)}
    </button>
  );
}

function useStudentBasics(stId: string) {
  const { data, userById } = useStore();
  const st = data.students.find((s) => s.id === stId)!;
  const coach = st?.coachId ? userById(st.coachId) : undefined;
  const programs = data.programs.filter((p) => p.studentId === stId && (p.status === "فعال" || p.status === "در حال اتمام"));
  return { st, coach, programs };
}

/** جلسه امروز بر اساس روز واقعی هفته (شنبه تا جمعه) */
function todaySession(data: AppData, stId: string, programs: WorkoutProgram[]) {
  const today = weekdayName();
  const tk = dayKey();
  const sorted = [...programs].sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
  const program = sorted.find((p) => p.days.some((d) => d.weekday === today && d.items.length > 0)) ?? sorted[0];
  const todays = program ? program.days.filter((d) => d.weekday === today && d.items.length > 0) : [];
  const loggedFor = (dayId: string) => data.logs.find((l) => l.studentId === stId && l.dayId === dayId && l.date === tk);
  const day = todays.find((d) => !loggedFor(d.id)) ?? todays[0];
  const log = day ? loggedFor(day.id) : undefined;
  let next: { date: Date; day: WorkoutDay } | null = null;
  if (program) {
    for (let i = 1; i <= 7; i++) {
      const d = addDays(new Date(), i);
      const pd = program.days.find((x) => x.weekday === weekdayName(d) && x.items.length > 0);
      if (pd) {
        next = { date: d, day: pd };
        break;
      }
    }
  }
  return { program, day, log, next, today };
}

/* ================= HOME ================= */
function HomeView({ stId, nav }: { stId: string; nav: (v: StudentView) => void }) {
  const { data } = useStore();
  const { coach, programs } = useStudentBasics(stId);
  const { program, day, log, next, today } = todaySession(data, stId, programs);
  const streak = workoutStreak(data, stId);
  const lastMsg = [...data.messages].reverse().find((m) => m.studentId === stId && m.from === "coach");
  const upcoming = [...data.appts]
    .filter((a) => a.status === "رزرو" && new Date(a.startAt).getTime() > Date.now())
    .sort((a, b) => a.startAt.localeCompare(b.startAt))[0];
  const logs = [...data.logs.filter((l) => l.studentId === stId)].sort((a, b) => (b.at || "").localeCompare(a.at || ""));
  const adherence = calculateAdherence(data, stId);

  return (
    <div className="screen-in space-y-3 pb-2">
      {coach ? (
        <div data-guide="student-coach" className="flex items-center gap-3 rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-3">
          <img src={coach.avatar} alt="" className="h-11 w-11 rounded-full object-cover ring-2 ring-[#e9e400]/40" />
          <div className="min-w-0 flex-1">
            <p className="text-[10.5px] font-bold text-[#e9e400]">{localizeStatic("مربی تو")}</p>
            <b className="block truncate text-[14px]">{coach.name}</b>
          </div>
          <button onClick={() => nav("chat")} className="press flex h-9 items-center gap-1 rounded-full bg-[#e9e400] px-3 text-[11.5px] font-black text-black"><MessageCircle size={14} />{localizeStatic(" پیام")}</button>
        </div>
      ) : (
        <button onClick={() => nav("profile")} className="press flex w-full items-center gap-3 rounded-2xl border border-dashed border-[#e9e400]/40 bg-[#e9e400]/[0.06] p-3 text-right">
          <Ticket size={22} className="text-[#e9e400]" />
          <span className="flex-1">
            <b className="block text-[13px]">{localizeStatic("هنوز به مربی وصل نیستی")}</b>
            <span className="text-[11px] text-[var(--color-mute)]">{localizeStatic("کد مربی را در پروفایل وارد کن")}</span>
          </span>
          <ChevronLeft size={16} />
        </button>
      )}

      <button data-guide="student-today" onClick={() => nav("workout")} className="press relative block w-full overflow-hidden rounded-3xl text-right">
        {localize(day?.items[0] ? (
          <ExThumb exerciseId={day.items[0].exerciseId} data={data} className="h-44 w-full object-cover" />
        ) : (
          <div className="h-44 w-full bg-gradient-to-br from-[#e9e400]/30 via-[#2a2c10] to-black" />
        ))}
        <div className="on-dark absolute inset-0 bg-gradient-to-t from-black via-black/50 to-black/10 p-4">
          <div className="flex items-center justify-between">
            <Pill tone="brand">{localizeStatic("تمرین امروز • ")}{localize(today)}</Pill>
            {localize(log && <Pill tone="ok">{localizeStatic("انجام شد ✓")}</Pill>)}
          </div>
          <div className="absolute inset-x-4 bottom-4">
            <b className="block text-[19px] text-white">{localize(day ? day.focus : program ? "امروز روز استراحت است" : "برنامه‌ای نداری")}</b>
            <span className="tnum block text-[12px] text-white/70">
              {localize(day
                ? `${fa(day.items.length)} حرکت • ${fa(day.items.reduce((a, i) => a + i.sets, 0))} ست`
                : next
                  ? `جلسه بعدی: ${next.day.weekday} ${formatJalaliDate(next.date)}`
                  : program
                    ? "جلسه‌ای در برنامه نیست"
                    : "مربی هنوز برنامه نفرستاده")}
            </span>
            {program && <span className="mt-0.5 block text-[11px] text-[#e9e400]">{program.name}{coach ? ` • طراحی: ${coach.name}` : ""}</span>}
          </div>
        </div>
      </button>

      <div className="grid grid-cols-4 gap-2">
        <Mini icon={<Flame size={15} />} v={fa(streak)} l={localizeStatic("روز متوالی")} />
        <Mini icon={<Trophy size={15} />} v={fa(xpOf(data, stId))} l={localizeStatic("XP")} />
        <Mini icon={<CalendarDays size={15} />} v={fa(weekLogCount(data, stId))} l={localizeStatic("این هفته")} />
        <Mini icon={<CheckCircle size={15} />} v={fa(logs.length)} l={localizeStatic("کل تمرین")} />
      </div>

      <button onClick={() => nav("progress")} className="press flex w-full items-center justify-between rounded-2xl bg-[var(--color-card)] p-3 text-right"><b className="text-[12px]">{localizeStatic("پایبندی کلی این هفته")}</b><span className="tnum text-[13px] font-black text-[#e9e400]">{localize(adherence.overall === null ? "—" : `${fa(adherence.overall)}٪`)}</span></button>

      {lastMsg && (
        <button onClick={() => nav("chat")} className="press flex w-full items-center gap-3 rounded-2xl bg-[var(--color-card)] p-3 text-right">
          <img src={coach?.avatar} className="h-10 w-10 rounded-full object-cover" alt="" />
          <span className="min-w-0 flex-1">
            <b className="block text-[12.5px]">{localizeStatic("آخرین پیام ")}{coach?.name ?? "مربی"}</b>
            <span className="block truncate text-[11.5px] text-[var(--color-mute)]">{localize(lastMsg.text)}</span>
            <span className="block text-[10px] text-[var(--color-mute)]">{localize(formatRelative(lastMsg.time))}</span>
          </span>
          <ChevronLeft size={16} />
        </button>
      )}

      {localize(upcoming && (
        <div className="rounded-2xl border border-[#e9e400]/25 bg-[#e9e400]/10 p-3">
          <b className="flex items-center gap-1.5 text-[13px]"><CalendarDays size={15} className="text-[#e9e400]" />{localizeStatic(" جلسه آینده")}</b>
          <p className="mt-1 text-[12px] text-[var(--color-mute)]">{localize(upcoming.title)} — {localize(formatDateTime(upcoming.startAt))} ({localize(formatRelative(upcoming.startAt))})</p>
        </div>
      ))}

      <button
        onClick={() => nav("history")}
        className="press flex w-full items-center gap-3 rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-3 text-right transition hover:border-[#e9e400]/35"
      >
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#e9e400]/15 text-[#e9e400]">
          <CalendarDays size={18} />
        </span>
        <span className="min-w-0 flex-1">
          <b className="block text-[13px]">{localizeStatic("تقویم و تاریخچه‌ی تمرین")}</b>
          <span className="tnum block truncate text-[11.5px] text-[var(--color-mute)]">
            {logs.length > 0
              ? `${localize(formatDateTime(logs[0].at))} • ${localize(fa(logs[0].durationMin))}${localizeStatic(" دقیقه")}`
              : localizeStatic("مشاهده تقویم ماهانه، جلسات قبلی و جزئیات وزنه‌ها")}
          </span>
        </span>
        <ChevronLeft size={16} className="shrink-0 text-[var(--color-mute)]" />
      </button>
    </div>
  );
}

function Mini({ icon, v, l }: { icon: ReactNode; v: string; l: string }) {
  return (
    <div className="rounded-2xl bg-[var(--color-card)] p-2.5 text-center">
      <div className="flex justify-center text-[#e9e400]">{localize(icon)}</div>
      <b className="tnum mt-1 block text-[15px]">{localize(v)}</b>
      <span className="text-[9.5px] text-[var(--color-mute)]">{localize(l)}</span>
    </div>
  );
}

/* ================= WORKOUT (read-only prescription) ================= */
interface Draft {
  date: string;
  programId: string;
  dayId: string;
  startedAt: string | null;
  done: Record<string, boolean[]>;
  /** مقادیر واقعی هر ست که شاگرد وارد می‌کند */
  actual?: Record<string, SessionSetValue[]>;
  /** تعداد ست‌های اضافه‌ای که شاگرد در این جلسه به یک حرکت افزوده */
  extraSets?: Record<string, number>;
}

const draftKey = (stId: string) => `revo-draft-${stId}`;
const exNoteKey = (stId: string) => `revo-ex-notes-${stId}`;

function loadExNotes(stId: string): Record<string, string> {
  try {
    const raw = localStorage.getItem(exNoteKey(stId));
    return raw ? (JSON.parse(raw) as Record<string, string>) : {};
  } catch {
    return {};
  }
}

function loadDraft(stId: string): Draft | null {
  try {
    const r = localStorage.getItem(draftKey(stId));
    if (!r) return null;
    const d = JSON.parse(r) as Draft;
    if (!d || d.date !== dayKey() || !d.done || typeof d.done !== "object") return null;
    return d;
  } catch {
    return null;
  }
}

function defaultSet(it: ProgramSet): SessionSetValue {
  const reps = num(it.reps);
  return {
    weight: "",
    reps: reps ? String(reps) : it.reps,
    rir: String(Math.max(0, Math.min(5, 10 - (it.rpe || 7)))),
    tag: "normal",
  };
}

function buildSets(it: ProgramSet, saved?: SessionSetValue[], count = it.sets): SessionSetValue[] {
  return Array.from({ length: Math.max(1, count) }).map((_, i) => saved?.[i] ?? defaultSet(it));
}

function num(s: string): number {
  const m = String(s ?? "")
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .match(/\d+(\.\d+)?/);
  return m ? Number(m[0]) : 0;
}

function WorkoutView({ stId, onToast, nav }: { stId: string; onToast: (t: string, d: string) => void; nav: (v: StudentView) => void }) {
  const { data, logWorkout } = useStore();
  const { coach, programs } = useStudentBasics(stId);
  // هر دقیقه یک‌بار برای تاریخ/روز — ساعت زندهٔ ثانیه‌ای داخل SessionClock است تا کل صفحه هر ثانیه رندر نشود
  const now = useNow(60_000);
  const session = useMemo(() => todaySession(data, stId, programs), [data, stId, programs, now]);
  const { program, day, log, next, today } = session;
  const todayKey = dayKey(now);
  const mapGender: MapGender = data.students.find((s) => s.id === stId)?.gender === "زن" ? "female" : "male";
  const fresh = (): Draft => ({ date: dayKey(), programId: program?.id ?? "", dayId: day?.id ?? "", startedAt: null, done: {}, actual: {}, extraSets: {} });
  const [draft, setDraft] = useState<Draft>(() => {
    const s = loadDraft(stId);
    return s && s.programId === (program?.id ?? "") && s.dayId === (day?.id ?? "") ? s : fresh();
  });
  const [exNotes, setExNotes] = useState<Record<string, string>>(() => loadExNotes(stId));
  const [focusIdx, setFocusIdx] = useState(0);
  const [rest, setRest] = useState<{ left: number; total: number } | null>(null);
  const [restRun, setRestRun] = useState(true);
  const restDeadline = useRef<number | null>(null);
  const [video, setVideo] = useState<string | null>(null);
  const [summary, setSummary] = useState(false);
  const [immersive, setImmersive] = useState(false);

  // Release even when the browser resolves a wake-lock request after unmount.
  useEffect(() => {
    if (!immersive || !draft.startedAt || !day || log) return;
    let disposed = false;
    let wakeLock: WakeLockSentinel | null = null;
    const request = async () => {
      if (document.hidden || !('wakeLock' in navigator) || (wakeLock && !wakeLock.released)) return;
      try {
        const acquired = await navigator.wakeLock.request("screen");
        if (disposed) await acquired.release();
        else wakeLock = acquired;
      } catch {
        // Low-power mode can deny this optional capability.
      }
    };
    void request();
    document.addEventListener('visibilitychange', request);
    return () => {
      disposed = true;
      document.removeEventListener('visibilitychange', request);
      if (wakeLock) wakeLock.release().catch(() => undefined);
    };
  }, [immersive, draft.startedAt, day?.id, log?.id]);

  // حالت تمرکز: ناوبری پایین و حواس‌پرتی‌ها مخفی می‌شوند
  useEffect(() => {
    const active = immersive && !!draft.startedAt;
    document.documentElement.classList.toggle("revo-workout-focus", active);
    return () => document.documentElement.classList.remove("revo-workout-focus");
  }, [immersive, draft.startedAt]);

  // با عوض شدن روز (مثلاً رد شدن از نیمه‌شب) جلسه جدید آماده می‌شود
  useEffect(() => {
    if (draft.dayId !== (day?.id ?? "") || draft.programId !== (program?.id ?? "") || draft.date !== todayKey) {
      setDraft({ date: todayKey, programId: program?.id ?? "", dayId: day?.id ?? "", startedAt: null, done: {}, actual: {} });
      setFocusIdx(0);
      setRest(null);
      restDeadline.current = null;
      setImmersive(false);
      setSummary(false);
      setVideo(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [day?.id, program?.id, todayKey]);

  // آمار جلسه (ست‌های انجام‌شده، حجم، تکرار) — memoized و «قبل از» returnهای شرطی تا ترتیب hookها ثابت بماند
  const stats = useMemo(() => {
    const items = day?.items ?? [];
    const setCountOf = (it: ProgramSet) => Math.max(1, Math.min(16, it.sets + (draft.extraSets?.[it.id] ?? 0)));
    const marksOf = (itemId: string, sets: number) => Array.from({ length: sets }).map((_, k) => !!draft.done[itemId]?.[k]);
    const allSets = items.reduce((a, i) => a + setCountOf(i), 0);
    let doneSets = 0;
    let volume = 0;
    let reps = 0;
    for (const it of items) {
      const totalForItem = setCountOf(it);
      const marks = marksOf(it.id, totalForItem);
      const vals = buildSets(it, draft.actual?.[it.id], totalForItem);
      for (let i = 0; i < marks.length; i++) {
        if (!marks[i]) continue;
        doneSets++;
        const w = resolvedMetric(vals[i]?.weight, it.weight, "weight");
        const r = resolvedMetric(vals[i]?.reps, it.reps, "reps");
        volume += w * r;
        reps += r;
      }
    }
    return { setCountOf, marksOf, allSets, doneSets, volume, reps };
  }, [day?.items, draft.done, draft.actual, draft.extraSets]);
  const { setCountOf, marksOf, allSets, doneSets, volume, reps } = stats;

  useEffect(() => {
    if (draft.startedAt || Object.keys(draft.done).length || Object.keys(draft.extraSets ?? {}).length) {
      localStorage.setItem(draftKey(stId), JSON.stringify(draft));
    }
  }, [draft, stId]);

  useEffect(() => {
    if (!rest || !restRun) { restDeadline.current = null; return; }
    if (rest.left <= 0) {
      setRest(null);
      try {
        navigator.vibrate?.(300);
      } catch {
        /* ignore */
      }
      // اگر همهٔ ست‌های جلسه کامل شد، خلاصهٔ ثبت جلسه را خودکار باز کن
      const items = day?.items ?? [];
      let done = 0;
      let total = 0;
      for (const it of items) {
        const count = setCountOf(it);
        total += count;
        const marks = draft.done[it.id] ?? [];
        for (let i = 0; i < count; i++) if (marks[i]) done++;
      }
      if (total > 0 && done === total) setSummary(true);
      return;
    }
    if (restDeadline.current === null) restDeadline.current = Date.now() + rest.left * 1000;
    const t = window.setTimeout(() => {
      const left = Math.max(0, Math.ceil(((restDeadline.current ?? Date.now()) - Date.now()) / 1000));
      setRest((r) => r ? { ...r, left } : r);
    }, 1000);
    return () => window.clearTimeout(t);
  }, [rest, restRun, day?.items, draft.done]);

  if (!program) {
    return (
      <div className="screen-in py-10 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-[#e9e400]/15"><Dumbbell size={28} className="text-[#e9e400]" /></div>
        <b className="mt-3 block text-[16px]">{localizeStatic("هنوز برنامه تمرینی نداری")}</b>
        <p className="mt-1 text-[12.5px] leading-6 text-[var(--color-mute)]">
          {coach
            ? currentLanguage() === "fa"
              ? `${coach.name} به‌زودی برنامه شما را ارسال می‌کند. می‌توانید به مربی پیام دهید.`
              : `${coach.name} will send your program soon. You can send your coach a message.`
            : localize("اول با کد مربی به یک مربی وصل شو.")}
        </p>
        <BrandBtn className="mx-auto mt-4" onClick={() => nav(coach ? "chat" : "profile")}>{localize(coach ? "پیام به مربی" : "وارد کردن کد مربی")}</BrandBtn>
      </div>
    );
  }

  const estMin = day ? Math.max(1, Math.round(day.items.reduce((a, i) => a + i.sets * (i.rest + 45), 0) / 60)) : 0;

  const header = (
    <div className="rounded-3xl border border-[var(--color-line)] bg-gradient-to-bl from-[#e9e400]/15 via-[var(--color-card)] to-[var(--color-card)] p-4">
      <div className="flex items-center gap-2.5">
        {coach && <img src={coach.avatar} alt="" className="h-9 w-9 rounded-full object-cover ring-2 ring-[#e9e400]/40" />}
        <div className="min-w-0">
          <p className="truncate text-[11px] font-bold text-[#e9e400]">{program.name}</p>
          <p className="truncate text-[11px] text-[var(--color-mute)]">{localizeStatic("طراحی‌شده توسط مربی: ")}<b className="text-[var(--color-ink)]">{coach?.name ?? "—"}</b></p>
        </div>
      </div>
      <p className="mt-3 text-[11.5px] font-bold text-[var(--color-mute)]">{localize(formatJalaliLong(now))}</p>
      {localize(day ? (
        <>
          <h2 className="mt-0.5 text-[20px] font-black">{localize(day.focus)}</h2>
          <div className="mt-2 grid grid-cols-3 gap-2 text-center">
            <Stat v={fa(day.items.length)} l={localizeStatic("حرکت")} />
            <Stat v={fa(day.items.reduce((a, i) => a + i.sets, 0))} l={localizeStatic("ست")} />
            <Stat v={`~${fa(estMin)}`} l={localizeStatic("دقیقه")} />
          </div>
        </>
      ) : (
        <h2 className="mt-0.5 text-[20px] font-black">{localizeStatic("روز استراحت")}</h2>
      ))}
    </div>
  );

  /* ---------- rest day ---------- */
  if (!day) {
    return (
      <div className="screen-in space-y-3 pb-6">
        {localize(header)}
        <div className="rounded-3xl border border-[var(--color-line)] bg-[var(--color-card)] p-5 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-sky-500/15"><Coffee size={28} className="text-sky-400" /></div>
          <b className="mt-3 block text-[17px]">{localizeStatic("امروز (")}{localize(today)}{localizeStatic(") تمرینی نداری")}</b>
          <p className="mt-1 text-[12.5px] leading-6 text-[var(--color-mute)]">{localizeStatic("مربی برای امروز جلسه‌ای تعیین نکرده. ریکاوری هم بخشی از پیشرفت است.")}</p>
          {localize(next && (
            <div className="mt-4 rounded-2xl bg-[var(--color-bg)] p-3 text-right">
              <p className="text-[11px] font-bold text-[#e9e400]">{localizeStatic("جلسه بعدی")}</p>
              <b className="block text-[14px]">{localize(next.day.weekday)} — {localize(next.day.focus)}</b>
              <span className="tnum text-[11.5px] text-[var(--color-mute)]">{localize(formatJalaliLong(next.date))} • {localize(fa(Math.max(1, daysBetween(now, next.date))))}{localizeStatic(" روز دیگر")}</span>
            </div>
          ))}
        </div>
        <WeekPlan program={program} today={today} />
      </div>
    );
  }

  /* ---------- already logged today ---------- */
  if (log) {
    const lDone = log.items.reduce((a, i) => a + i.sets.filter((s) => s.done).length, 0);
    const lAll = log.items.reduce((a, i) => a + i.sets.length, 0);
    const lVol = log.items.reduce((a, i) => a + i.sets.filter((s) => s.done).reduce((x, s) => x + s.weight * s.reps, 0), 0);
    return (
      <div className="screen-in space-y-3 pb-6">
        {localize(header)}
        <div className="rounded-3xl border border-emerald-500/30 bg-emerald-500/10 p-5 text-center">
          <div className="pop mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500 text-white"><Check size={30} strokeWidth={3} /></div>
          <b className="mt-3 block text-[17px]">{localizeStatic("تمرین امروز ثبت شد")}</b>
          <p className="mt-1 text-[12px] text-[var(--color-mute)]">{localize(formatDateTime(log.at || log.date))}</p>
          <div className="mt-4 grid grid-cols-3 gap-2">
            <Stat v={fa(log.durationMin)} l={localizeStatic("دقیقه")} />
            <Stat v={`${fa(lDone)}/${fa(lAll)}`} l={localizeStatic("ست")} />
            <Stat v={fa(Math.round(lVol))} l={localizeStatic("حجم kg")} />
          </div>
          {localize(next && <p className="mt-3 text-[12px] text-[var(--color-mute)]">{localizeStatic("جلسه بعدی: ")}<b className="text-[var(--color-ink)]">{localize(next.day.weekday)} {localize(formatJalaliDate(next.date))}</b></p>)}
          <BrandBtn className="mx-auto mt-4" onClick={() => nav("history")}><ClipboardList size={15} />{localizeStatic(" مشاهده در سوابق")}</BrandBtn>
        </div>
        <WeekPlan program={program} today={today} />
      </div>
    );
  }

  /* ---------- active session ---------- */
  const previousFor = (exerciseId: string): PreviousExerciseSummary | null => {
    const logs = [...data.logs]
      .filter((l) => l.studentId === stId)
      .sort((a, b) => (b.at || b.date || "").localeCompare(a.at || a.date || ""));
    let bestWeight = 0;
    let bestReps = 0;
    let best1RM = 0;
    let lastSets: { weight: number; reps: number }[] = [];
    let dateLabel = "";
    for (const l of logs) {
      const entry = l.items.find((x) => x.exerciseId === exerciseId);
      const doneList = entry?.sets.filter((s) => s.done) ?? [];
      if (!doneList.length) continue;
      if (!lastSets.length) {
        lastSets = doneList.map((s) => ({ weight: s.weight, reps: s.reps }));
        dateLabel = formatRelative(l.at || l.date);
      }
      for (const s of doneList) {
        const e1 = estimate1RM(s.weight, s.reps);
        if (s.weight > bestWeight || (s.weight === bestWeight && s.reps > bestReps)) {
          bestWeight = s.weight;
          bestReps = s.reps;
        }
        if (e1 > best1RM) best1RM = e1;
      }
    }
    if (!lastSets.length) return null;
    return { dateLabel, bestWeight, bestReps, best1RM, sets: lastSets };
  };

  const toggle = (idx: number, i: number) => {
    const it = day.items[idx];
    const totalCount = it ? setCountOf(it) : 0;
    if (!it || i < 0 || i >= totalCount) return;
    const willDone = !draft.done[it.id]?.[i];
    if (willDone && resolvedMetric(buildSets(it, draft.actual?.[it.id], totalCount)[i]?.reps, it.reps, "reps") <= 0) {
      onToast("تکرار را وارد کن", "تعداد تکرار انجام‌شده باید بیشتر از صفر باشد.");
      return;
    }
    const after = marksOf(it.id, totalCount);
    after[i] = willDone;
    const completedAll = willDone && after.every(Boolean);
    const isFocused = idx === Math.min(focusIdx, Math.max(0, day.items.length - 1));
    setDraft((d) => {
      const count = Math.max(1, Math.min(16, it.sets + (d.extraSets?.[it.id] ?? 0)));
      const arr = Array.from({ length: count }).map((_, k) => !!d.done[it.id]?.[k]);
      arr[i] = willDone;
      return { ...d, startedAt: d.startedAt ?? nowIso(), done: { ...d.done, [it.id]: arr } };
    });
    if (willDone) {
      try { navigator.vibrate?.(40); } catch { /* ignore */ }
      // فقط وقتی حرکتِ «در حال تمرکز» کامل شد به حرکت بعدی برو
      if (completedAll && isFocused && day.items[idx + 1]) {
        setFocusIdx(idx + 1);
      }
      if (it.rest > 0) {
        restDeadline.current = Date.now() + it.rest * 1000;
        setRest({ left: it.rest, total: it.rest });
        setRestRun(true);
      } else {
        // اگر استراحتی نداریم و همهٔ ست‌های جلسه کامل شد، خلاصه را خودکار باز کن
        const allDone = day.items.every((other) =>
          other.id === it.id ? after.every(Boolean) : marksOf(other.id, setCountOf(other)).every(Boolean)
        );
        if (allDone && isFocused) setSummary(true);
      }
    }
  };

  const startSessionAt = (index?: number) => {
    setDraft((d) => ({ ...d, startedAt: d.startedAt ?? nowIso() }));
    if (typeof index === "number") {
      setFocusIdx(index);
    } else {
      // شروع هوشمند از اولین حرکتِ ناتمام
      const firstIncomplete = day.items.findIndex((it) => !marksOf(it.id, setCountOf(it)).every(Boolean));
      if (firstIncomplete !== -1) setFocusIdx(firstIncomplete);
    }
    setImmersive(true);
  };

  const focusPos = Math.min(focusIdx, Math.max(0, day.items.length - 1));
  const focusItem = day.items[focusPos];
  const focusTotalSets = focusItem ? setCountOf(focusItem) : 0;
  const focusExercise = focusItem ? resolveExercise(focusItem.exerciseId, data) : null;
  const focusValues = focusItem ? buildSets(focusItem, draft.actual?.[focusItem.id], focusTotalSets) : [];
  const focusDone = focusItem ? marksOf(focusItem.id, focusTotalSets) : [];
  const firstOpen = focusDone.findIndex((v) => !v);
  const activeSetIndex = firstOpen === -1 ? Math.max(0, focusDone.length - 1) : firstOpen;
  const focusPrevious = focusItem ? previousFor(focusItem.exerciseId) : null;
  const restNextLabel = (() => {
    for (const it of day.items) {
      const firstOpenSet = marksOf(it.id, setCountOf(it)).findIndex((value) => !value);
      if (firstOpenSet !== -1) {
        return `${resolveExercise(it.exerciseId, data).name} — ${localizeStatic("ست")} ${fa(firstOpenSet + 1)}`;
      }
    }
    return localizeStatic("پایان جلسه");
  })();

  const editSet = (itemId: string, setIndex: number, patch: Partial<SessionSetValue>) => {
    const item = day.items.find((x) => x.id === itemId);
    if (!item) return;
    setDraft((d) => {
      const count = Math.max(1, Math.min(16, item.sets + (d.extraSets?.[itemId] ?? 0)));
      const arr = buildSets(item, d.actual?.[itemId], count);
      arr[setIndex] = { ...(arr[setIndex] ?? defaultSet(item)), ...patch };
      return { ...d, startedAt: d.startedAt ?? nowIso(), actual: { ...d.actual, [itemId]: arr } };
    });
  };

  const addExtraSet = () => {
    if (!focusItem) return;
    setDraft((d) => {
      const curExtra = d.extraSets?.[focusItem.id] ?? 0;
      if (focusItem.sets + curExtra >= 16) return d;
      const nextCount = focusItem.sets + curExtra + 1;
      const arr = buildSets(focusItem, d.actual?.[focusItem.id], nextCount);
      // آخرین ست را به‌عنوان پیش‌فرض کپی کن تا تایپ مجدد لازم نباشد
      const prev = arr[nextCount - 2];
      if (prev) arr[nextCount - 1] = { ...prev };
      return {
        ...d,
        startedAt: d.startedAt ?? nowIso(),
        extraSets: { ...(d.extraSets ?? {}), [focusItem.id]: curExtra + 1 },
        actual: { ...(d.actual ?? {}), [focusItem.id]: arr },
      };
    });
  };

  const removeExtraSet = () => {
    if (!focusItem) return;
    setDraft((d) => {
      const curExtra = d.extraSets?.[focusItem.id] ?? 0;
      if (curExtra <= 0) return d;
      const nextCount = Math.max(1, focusItem.sets + curExtra - 1);
      const arr = buildSets(focusItem, d.actual?.[focusItem.id], nextCount).slice(0, nextCount);
      const doneArr = (d.done[focusItem.id] ?? []).slice(0, nextCount);
      return {
        ...d,
        extraSets: { ...(d.extraSets ?? {}), [focusItem.id]: curExtra - 1 },
        actual: { ...(d.actual ?? {}), [focusItem.id]: arr },
        done: { ...d.done, [focusItem.id]: doneArr },
      };
    });
  };

  const copyToRemaining = (fromIndex: number) => {
    if (!focusItem) return;
    setDraft((d) => {
      const count = Math.max(1, Math.min(16, focusItem.sets + (d.extraSets?.[focusItem.id] ?? 0)));
      const arr = buildSets(focusItem, d.actual?.[focusItem.id], count);
      const source = arr[fromIndex];
      if (!source) return d;
      const marks = d.done[focusItem.id] ?? [];
      for (let i = fromIndex + 1; i < count; i++) {
        if (!marks[i]) {
          arr[i] = { ...arr[i], weight: source.weight, reps: source.reps };
        }
      }
      return { ...d, startedAt: d.startedAt ?? nowIso(), actual: { ...(d.actual ?? {}), [focusItem.id]: arr } };
    });
    onToast("کپی شد", "وزن و تکرار در ست‌های باقی‌مانده قرار گرفت");
  };

  const applyPreviousSets = () => {
    if (!focusItem || !focusPrevious?.sets.length) return;
    setDraft((d) => {
      const count = Math.max(1, Math.min(16, focusItem.sets + (d.extraSets?.[focusItem.id] ?? 0)));
      const arr = buildSets(focusItem, d.actual?.[focusItem.id], count);
      const marks = d.done[focusItem.id] ?? [];
      for (let i = 0; i < count; i++) {
        if (marks[i]) continue;
        const src = focusPrevious.sets[Math.min(i, focusPrevious.sets.length - 1)];
        if (src) {
          arr[i] = { ...arr[i], weight: String(src.weight), reps: String(src.reps) };
        }
      }
      return { ...d, startedAt: d.startedAt ?? nowIso(), actual: { ...(d.actual ?? {}), [focusItem.id]: arr } };
    });
    onToast("جای‌گذاری شد", "اعداد جلسهٔ قبل در ست‌ها قرار گرفت");
  };

  const resetCurrentExercise = () => {
    if (!focusItem) return;
    setDraft((d) => {
      const done = { ...d.done };
      const actual = { ...(d.actual ?? {}) };
      const extraSets = { ...(d.extraSets ?? {}) };
      delete done[focusItem.id];
      delete actual[focusItem.id];
      delete extraSets[focusItem.id];
      return { ...d, done, actual, extraSets };
    });
  };

  const savePersonalNote = (exerciseId: string, value: string) => {
    setExNotes((prev) => {
      const next = { ...prev, [exerciseId]: value };
      try {
        localStorage.setItem(exNoteKey(stId), JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  };

  const startCustomRest = (seconds: number) => {
    restDeadline.current = Date.now() + seconds * 1000;
    setRest({ left: seconds, total: seconds });
    setRestRun(true);
  };

  const resetSession = () => {
    if (!confirm("تمرین لغو شود؟ تیک‌ها و وزن‌های این جلسه پاک می‌شود.")) return;
    localStorage.removeItem(draftKey(stId));
    setDraft(fresh());
    setFocusIdx(0);
    setImmersive(false);
    setRest(null);
    restDeadline.current = null;
    setSummary(false);
  };

  const finishSession = () => {
    if (doneSets === 0) {
      onToast("هنوز ستی انجام نشده", "حداقل یک ست را تیک بزن");
      return;
    }
    setRest(null);
    restDeadline.current = null;
    setSummary(true);
  };

  const save = () => {
    // زمان دقیق در لحظهٔ ذخیره محاسبه می‌شود (نه با ساعت دقیقه‌ای صفحه)
    const elapsedSec = draft.startedAt
      ? Math.max(0, Math.floor((Date.now() - new Date(draft.startedAt).getTime()) / 1000))
      : 0;
    const durationMin = Math.max(1, Math.round(elapsedSec / 60));
    const items = day.items.map((it) => {
      const count = setCountOf(it);
      const enteredSets = buildSets(it, draft.actual?.[it.id], count);
      return {
        exerciseId: it.exerciseId,
        sets: marksOf(it.id, count).map((done, i) => {
          const entered = enteredSets[i];
          const rir = entered?.rir;
          return {
            set: i + 1,
            weight: resolvedMetric(entered?.weight, it.weight, "weight"),
            reps: resolvedMetric(entered?.reps, it.reps, "reps"),
            rpe: rir !== undefined && rir !== "" ? Math.max(1, Math.min(10, 10 - Number(rir))) : it.rpe,
            done,
          };
        }),
      };
    });
    logWorkout({ studentId: stId, programId: program.id, dayId: day.id, durationMin, items, startedAt: draft.startedAt ?? nowIso() });
    localStorage.removeItem(draftKey(stId));
    setDraft(fresh());
    setSummary(false);
    setImmersive(false);
    setRest(null);
    onToast("تمرین ذخیره شد", `${fa(durationMin)} دقیقه • ${formatDateTime(new Date())}`);
    nav("history");
  };

  return (
    <div data-guide-page="workout-session" className="screen-in space-y-2.5 pb-2">
      <WorkoutOverview
        title={day.focus}
        programName={program.name}
        coachName={coach?.name}
        coachAvatar={coach?.avatar}
        data={data}
        items={day.items.map((it) => {
          const ex = resolveExercise(it.exerciseId, data);
          const count = setCountOf(it);
          const marks = marksOf(it.id, count);
          const prev = previousFor(it.exerciseId);
          return {
            id: it.id,
            exerciseId: it.exerciseId,
            name: ex.name,
            muscle: ex.muscle,
            equipment: ex.equipment,
            sets: count,
            doneSets: marks.filter(Boolean).length,
            reps: it.reps,
            rest: it.rest,
            complete: marks.every(Boolean),
            lastBest: prev && prev.bestWeight > 0 ? `${prev.bestWeight} kg × ${prev.bestReps}` : undefined,
          };
        })}
        onStart={() => startSessionAt()}
        onSelectExercise={(index) => startSessionAt(index)}
        onPreview={(index) => setVideo(day.items[index].exerciseId)}
        onFinish={finishSession}
        started={!!draft.startedAt}
        doneSets={doneSets}
        totalSets={allSets}
        volume={volume}
        estimatedMinutes={estMin}
        onReset={resetSession}
      />
      <details className="border-t border-[var(--color-line)] py-4 text-[12px] text-[var(--color-mute)]">
        <summary className="cursor-pointer">{localizeStatic("مشاهدهٔ برنامه هفتگی")}</summary>
        <div className="pt-3"><WeekPlan program={program} today={today} /></div>
      </details>

      {immersive && focusItem && focusExercise && (
        <ImmersiveWorkout
          onBack={() => setImmersive(false)}
          onFinish={finishSession}
          item={focusItem}
          exercise={focusExercise}
          values={focusValues}
          done={focusDone}
          activeSet={activeSetIndex}
          onEdit={(i, field, value) => editSet(focusItem.id, i, { [field]: value })}
          onRir={(i, value) => editSet(focusItem.id, i, { rir: value })}
          onTag={(i, tag: SetKind) => editSet(focusItem.id, i, { tag })}
          onToggleSet={(i) => toggle(focusPos, i)}
          onAddSet={addExtraSet}
          onRemoveSet={removeExtraSet}
          canRemoveSet={(draft.extraSets?.[focusItem.id] ?? 0) > 0}
          onCopyToRemaining={copyToRemaining}
          onApplyPrevious={focusPrevious ? applyPreviousSets : undefined}
          onResetExercise={resetCurrentExercise}
          onStartCustomRest={startCustomRest}
          personalNote={exNotes[focusItem.exerciseId] ?? ""}
          onPersonalNote={(note) => savePersonalNote(focusItem.exerciseId, note)}
          previous={focusPrevious}
          exerciseCompleted={day.items.map((it) => marksOf(it.id, setCountOf(it)).every(Boolean))}
          onJump={(i) => { setFocusIdx(i); setRest(null); restDeadline.current = null; }}
          exerciseIndex={focusPos + 1}
          totalExercises={day.items.length}
          focusName={day.focus}
          onGuide={() => setVideo(focusItem.exerciseId)}
          startedAt={draft.startedAt}
          sessionDone={doneSets}
          sessionTotal={allSets}
          sessionVolume={volume}
          suspended={!!rest || !!video || summary}
        />
      )}

      <RestOverlay
        rest={rest}
        paused={!restRun}
        nextLabel={restNextLabel}
        onSkip={() => {
          setRest(null);
          restDeadline.current = null;
          if (allSets > 0 && doneSets === allSets) setSummary(true);
        }}
        onTogglePause={() => setRestRun((v) => !v)}
        onAdjust={(delta) => {
          if (!rest) return;
          const left = Math.max(0, rest.left + delta);
          restDeadline.current = restRun ? Date.now() + left * 1000 : null;
          setRest({ left, total: Math.max(rest.total, left) });
        }}
      />

      {video && (
        <WorkoutModal label={localizeStatic("آموزش حرکت")} onClose={() => setVideo(null)}>
          {(() => {
            const exercise = resolveExercise(video, data);
            return <>
              <div className="mb-4 flex items-center justify-between gap-3"><b>{localize(exercise.name)}</b><button className="iw-sheet-close" onClick={() => setVideo(null)} aria-label={localizeStatic("بستن")}><X size={18} /></button></div>
              <ExVideo exerciseId={video} data={data} />
              <MuscleMiniMap muscleLabel={exercise.muscle} gender={mapGender} className="mt-3" />
              {exercise.how && <p className="mt-3 text-[12.5px] leading-7 text-white/65">{localize(exercise.how)}</p>}
              <p className="mt-2 text-[12px] text-white/55">{localize(exercise.muscle)} • {localize(exercise.equipment)}</p>
            </>;
          })()}
        </WorkoutModal>
      )}

      {summary && (
        <WorkoutModal label={localizeStatic("خلاصهٔ تمرین")} onClose={() => setSummary(false)}>
          <div className="py-2 text-center">
            <span className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-[#4ca866]/15 text-[#67bc7f]"><Check size={26} /></span>
            <h3 className="text-[20px] font-bold">{localizeStatic("آفرین! جلسه تمام شد")}</h3>
            <p className="mt-2 text-[12px] text-white/50">{localize(day.focus)} • {localize(formatDateTime(new Date()))}</p>
            <div className="my-6 grid grid-cols-4 gap-2">
              <Stat v={draft.startedAt ? <SessionClock startedAt={draft.startedAt} /> : "0:00"} l={localizeStatic("زمان")} />
              <Stat v={`${fa(doneSets)}/${fa(allSets)}`} l={localizeStatic("ست")} />
              <Stat v={fa(reps)} l={localizeStatic("تکرار")} />
              <Stat v={fa(Math.round(volume))} l={localizeStatic("حجم kg")} />
            </div>
            {doneSets < allSets && <p className="mb-4 text-[12px] text-[#d3af72]">{fa(allSets - doneSets)} {localizeStatic("ست انجام نشده؛ فقط ست‌های تیک‌خورده ثبت می‌شوند.")}</p>}
            <button className="iw-finish-action" onClick={save}>{localizeStatic("ذخیره و ارسال برای مربی")}</button>
            <button className="mt-4 py-2 text-[12px] text-white/55" onClick={() => setSummary(false)}>{localizeStatic("ادامه تمرین")}</button>
          </div>
        </WorkoutModal>
      )}
    </div>
  );
}

function WeekPlan({ program, today }: { program: WorkoutProgram; today: string }) {
  const { data } = useStore();
  const [open, setOpen] = useState<string | null>(null);
  const days = [...program.days].sort((a, b) => WEEK.indexOf(a.weekday) - WEEK.indexOf(b.weekday));
  return (
    <div data-guide="weekly-plan" className="rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-3.5">
      <b className="flex items-center gap-1.5 text-[13.5px]"><CalendarDays size={15} className="text-[#e9e400]" />{localizeStatic(" برنامه هفتگی")}</b>
      <p className="mt-0.5 flex items-center gap-1 text-[11px] text-[var(--color-mute)]"><Lock size={11} />{localizeStatic(" فقط مشاهده — هر روز فقط تمرین همان روز باز می‌شود")}</p>
      <div className="mt-2.5 space-y-1.5">
        {localize(days.map((d) => {
          const isToday = d.weekday === today;
          const isOpen = open === d.id;
          return (
            <div key={d.id} className={`overflow-hidden rounded-xl border ${isToday ? "border-[#e9e400]/40 bg-[#e9e400]/[0.06]" : "border-[var(--color-line)] bg-[var(--color-bg)]"}`}>
              <button onClick={() => setOpen(isOpen ? null : d.id)} className="flex w-full items-center gap-2 p-2.5 text-right">
                <b className="text-[12.5px]">{localize(d.weekday)}</b>
                {localize(isToday && <Pill tone="brand">{localizeStatic("امروز")}</Pill>)}
                <span className="min-w-0 flex-1 truncate text-[11.5px] text-[var(--color-mute)]">{localize(d.focus)}</span>
                <span className="tnum shrink-0 text-[11px] text-[var(--color-mute)]">{localize(fa(d.items.length))}{localizeStatic(" حرکت")}</span>
                <ChevronDown size={14} className={`shrink-0 transition ${isOpen ? "rotate-180" : ""}`} />
              </button>
              {localize(isOpen && (
                <div className="space-y-1.5 border-t border-[var(--color-line)] p-2.5">
                  {localize(d.items.length === 0 && <p className="text-[11px] text-[var(--color-mute)]">{localizeStatic("حرکتی ندارد")}</p>)}
                  {localize(d.items.map((it, i) => (
                    <div key={it.id} className="flex items-center gap-2">
                      <span className="tnum w-4 text-[10.5px] font-black text-[#e9e400]">{localize(fa(i + 1))}</span>
                      <ExThumb exerciseId={it.exerciseId} data={data} className="h-8 w-8 rounded-lg object-cover" />
                      <span className="min-w-0 flex-1 truncate text-[12px] font-bold">{localize(resolveExercise(it.exerciseId, data).name)}</span>
                      <span className="tnum shrink-0 text-[11px] text-[var(--color-mute)]">{localize(fa(it.sets))}×{localize(fa(it.reps))}</span>
                    </div>
                  )))}
                </div>
              ))}
            </div>
          );
        }))}
      </div>
    </div>
  );
}

function Stat({ v, l }: { v: ReactNode; l: string }) {
  return (
    <div className="rounded-xl bg-black/20 px-1 py-2">
      <b className="tnum block text-[14px]">{localize(v)}</b>
      <span className="text-[10px] text-[var(--color-mute)]">{localize(l)}</span>
    </div>
  );
}

/* ================= HISTORY & WORKOUT CALENDAR ================= */
function HistoryView({ stId, nav }: { stId: string; nav: (v: StudentView) => void }) {
  const { data } = useStore();
  return <StudentWorkoutHistory stId={stId} data={data} onGoWorkout={() => nav("workout")} />;
}

/* ================= PROGRESS ================= */
function ProgressView({ stId, onToast }: { stId: string; onToast: (t: string, d: string) => void }) {
  const { data, addProgress, addSleep, addGoal, updateMyStudent } = useStore();
  const pr = [...data.progress.filter((p) => p.studentId === stId)].sort((a, b) => a.date.localeCompare(b.date));
  const goals = data.goals.filter((g) => g.studentId === stId);
  const sleeps = data.sleep[stId] ?? [];
  const logsCount = data.logs.filter((l) => l.studentId === stId).length;
  const [w, setW] = useState("");
  const [waist, setWaist] = useState("");
  const [bed, setBed] = useState("23:30");
  const [wake, setWake] = useState("07:00");
  const [gTitle, setGTitle] = useState("");
  const [gTarget, setGTarget] = useState("");
  const [gCur, setGCur] = useState("");
  const streak = workoutStreak(data, stId);
  const xp = xpOf(data, stId);
  const level = Math.floor(xp / 400) + 1;
  const badges = [
    { t: "اولین تمرین", ok: logsCount >= 1 },
    { t: "۱۰ تمرین", ok: logsCount >= 10 },
    { t: "۷ روز متوالی", ok: streak >= 7 },
    { t: "۳۰ تمرین", ok: logsCount >= 30 },
    { t: "۳۰ روز متوالی", ok: streak >= 30 },
    { t: "۱۰۰ تمرین", ok: logsCount >= 100 },
  ];
  const ws = pr.map((p) => p.weight);
  const min = ws.length ? Math.min(...ws) - 2 : 0;
  const max = ws.length ? Math.max(...ws) + 1 : 1;

  const sleepHours = () => {
    const [bh, bm] = bed.split(":").map(Number);
    const [wh, wm] = wake.split(":").map(Number);
    const mins = ((wh * 60 + wm) - (bh * 60 + bm) + 1440) % 1440;
    return +(mins / 60).toFixed(1);
  };

  return (
    <div className="screen-in space-y-3 pb-4">
      <div data-guide="progress-overview" className="flex items-center gap-3 rounded-2xl bg-gradient-to-l from-[#e9e400]/15 to-[var(--color-card)] p-3.5">
        <div className="flex h-14 w-14 flex-col items-center justify-center rounded-2xl bg-[#e9e400] text-black">
          <Zap size={14} fill="currentColor" />
          <b className="tnum text-[15px] leading-4">{localize(fa(level))}</b>
        </div>
        <div className="flex-1">
          <b>{localizeStatic("سطح ")}{localize(fa(level))}</b>
          <ProgressBar pct={((xp % 400) / 400) * 100} className="mt-1.5" />
          <p className="tnum mt-1 text-[11px] text-[var(--color-mute)]">{localize(fa(xp))}{localizeStatic(" XP • ")}{localize(fa(400 - (xp % 400)))}{localizeStatic(" تا سطح بعد")}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {localize(badges.map((b) => (
          <div key={b.t} className={`rounded-2xl p-2.5 text-center ${b.ok ? "bg-[#e9e400]/15" : "bg-[var(--color-card)] opacity-45"}`}>
            <Trophy size={17} className={`mx-auto ${b.ok ? "text-[#e9e400]" : ""}`} />
            <p className="mt-1 text-[10.5px] font-bold">{localize(b.t)}</p>
          </div>
        )))}
      </div>

      <div data-guide="progress-measurements" className="rounded-2xl bg-[var(--color-card)] p-3.5">
        <b className="flex items-center gap-1.5"><Scale size={15} className="text-[#e9e400]" />{localizeStatic(" ثبت وزن و دور کمر")}</b>
        {localize(pr.length > 0 && (
          <div className="mt-3 flex h-24 items-end gap-1.5">
            {localize(pr.slice(-10).map((p) => (
              <div key={p.id} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
                <span className="tnum text-[9px]">{localize(fa(p.weight))}</span>
                <div className="w-full rounded-t bg-[#e9e400]" style={{ height: `${Math.max(8, ((p.weight - min) / (max - min || 1)) * 100)}%` }} />
              </div>
            )))}
          </div>
        ))}
        <div className="mt-3 grid grid-cols-[1fr_1fr_auto] gap-2">
          <input className={inputCls} placeholder={localizeStatic("وزن (kg)")} value={w} onChange={(e) => setW(e.target.value)} inputMode="decimal" />
          <input className={inputCls} placeholder={localizeStatic("کمر (cm)")} value={waist} onChange={(e) => setWaist(e.target.value)} inputMode="decimal" />
          <BrandBtn onClick={() => {
            const val = num(w);
            if (!val) return onToast("وزن را وارد کن", "");
            addProgress({ studentId: stId, date: nowIso(), weight: val, arm: 0, waist: num(waist), chest: 0, thigh: 0 });
            updateMyStudent({ weight: val });
            onToast("ثبت شد", `${fa(val)} کیلو • ${formatDateTime(new Date())}`);
            setW("");
            setWaist("");
          }}>{localizeStatic("ثبت")}</BrandBtn>
        </div>
        {localize(pr.length > 0 && (
          <div className="mt-3 max-h-36 space-y-1 overflow-y-auto">
            {localize([...pr].reverse().map((p) => (
              <p key={p.id} className="flex justify-between text-[11.5px]"><span className="text-[var(--color-mute)]">{localize(formatDateTime(p.date))}</span><b className="tnum">{localize(fa(p.weight))}{localizeStatic(" kg")}{localize(p.waist ? ` • کمر ${fa(p.waist)}` : "")}</b></p>
            )))}
          </div>
        ))}
      </div>

      <div className="rounded-2xl bg-[var(--color-card)] p-3.5">
        <b className="flex items-center gap-1.5"><Target size={15} className="text-[#e9e400]" />{localizeStatic(" اهداف من")}</b>
        {localize(goals.map((g) => {
          const pct = ((g.current - g.start) / ((g.target - g.start) || 1)) * 100;
          return (
            <div key={g.id} className="mt-2.5">
              <div className="flex justify-between text-[12px]"><b>{g.title}</b><span className="tnum">{localize(fa(g.current))} → {localize(fa(g.target))} {localize(g.unit)}</span></div>
              <ProgressBar pct={pct} className="mt-1" />
            </div>
          );
        }))}
        <div className="mt-3 grid grid-cols-3 gap-2">
          <input className={inputCls} placeholder={localizeStatic("عنوان (مثلاً وزن)")} value={gTitle} onChange={(e) => setGTitle(e.target.value)} />
          <input className={inputCls} placeholder={localizeStatic("فعلی")} value={gCur} onChange={(e) => setGCur(e.target.value)} inputMode="decimal" />
          <input className={inputCls} placeholder={localizeStatic("هدف")} value={gTarget} onChange={(e) => setGTarget(e.target.value)} inputMode="decimal" />
        </div>
        <button
          onClick={() => {
            const c = num(gCur);
            const t = num(gTarget);
            if (!gTitle.trim() || !t) return onToast("عنوان و هدف لازم است", "");
            addGoal({ studentId: stId, title: gTitle.trim(), unit: "", start: c, current: c, target: t });
            setGTitle("");
            setGCur("");
            setGTarget("");
            onToast("هدف اضافه شد", "");
          }}
          className="press mt-2 flex items-center gap-1 rounded-full bg-[var(--color-bg)] px-3 py-2 text-[12px] font-bold"
        >
          <Plus size={13} />{localizeStatic(" افزودن هدف")}</button>
      </div>

      <div data-guide="progress-sleep" className="rounded-2xl bg-[var(--color-card)] p-3.5">
        <b className="flex items-center gap-1.5"><Moon size={15} className="text-[#e9e400]" />{localizeStatic(" ثبت خواب")}</b>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <Field label={localizeStatic("ساعت خواب")}><input className={inputCls} type="time" value={bed} onChange={(e) => setBed(e.target.value)} /></Field>
          <Field label={localizeStatic("ساعت بیداری")}><input className={inputCls} type="time" value={wake} onChange={(e) => setWake(e.target.value)} /></Field>
        </div>
        <button onClick={() => { const h = sleepHours(); addSleep(stId, h, bed, wake); onToast("خواب ثبت شد", `${fa(h)} ساعت`); }} className="press mt-2 w-full rounded-full bg-[var(--color-bg)] py-2.5 text-[12.5px] font-black">{localizeStatic("ثبت خواب امروز (")}{localize(fa(sleepHours()))}{localizeStatic(" ساعت)")}</button>
        {localize(sleeps.slice(-5).reverse().map((s, i) => (
          <p key={i} className="mt-1.5 flex justify-between text-[11.5px] text-[var(--color-mute)]"><span>{localize(formatJalaliDate(s.date))}</span><span className="tnum">{localize(fa(s.hours))}{localizeStatic(" ساعت (")}{localize(fa(s.bed))}{localizeStatic(" تا ")}{localize(fa(s.wake))})</span></p>
        )))}
      </div>
      <StudentCheckin studentId={stId} onToast={onToast} />
    </div>
  );
}

/* ================= CHAT ================= */
function ChatView({ stId, nav }: { stId: string; nav: (v: StudentView) => void }) {
  const { data, markChatRead } = useStore();
  const { coach } = useStudentBasics(stId);
  const msgs = data.messages.filter((m) => m.studentId === stId);

  useEffect(() => {
    markChatRead(stId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [msgs.length]);

  if (!coach) {
    return (
      <div className="py-10">
        <Empty text="برای گفتگو، اول با کد مربی به مربی‌ات وصل شو." />
        <BrandBtn className="mx-auto mt-3" onClick={() => nav("profile")}>{localizeStatic("وارد کردن کد مربی")}</BrandBtn>
      </div>
    );
  }

  return (
    <div className="screen-in flex h-full min-h-0 flex-col">
      <div className="mx-3 mb-2 mt-2 flex shrink-0 items-center gap-2.5 rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-2.5">
        <img src={coach.avatar} className="h-10 w-10 rounded-full object-cover" alt="" />
        <div className="min-w-0 flex-1">
          <b className="block truncate text-[13px]">{coach.name}</b>
          <span className="text-[10.5px] text-[var(--color-mute)]">{localizeStatic("مربی شما • آخرین ورود ")}{localize(formatRelative(coach.lastLoginAt))}</span>
        </div>
        <span className="tnum shrink-0 text-[10.5px] text-[var(--color-mute)]">{localize(fa(msgs.length))}{localizeStatic(" پیام")}</span>
      </div>
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-t-3xl border-t border-[var(--color-line)] bg-[var(--color-bg2)]">
        <ChatThread
          studentId={stId}
          me="student"
          peerName={coach.name}
          peerAvatar={coach.avatar}
          placeholder={`پیام به ${coach.name}…`}
          compact
        />
      </div>
    </div>
  );
}

/* ================= PROFILE ================= */
function ProfileView({ stId, onToast }: { stId: string; onToast: (t: string, d: string) => void }) {
  const { data, logout, joinCoach, markNotif } = useStore();
  const { t } = useLang();
  const [notifPrefs] = useNotifPrefs();
  const { coach } = useStudentBasics(stId);
  const [code, setCode] = useState("");
  const notifs = data.notifs.filter((n) => notifVisible(n.title, notifPrefs));

  return (
    <div className="screen-in space-y-3 pb-6">
      <div className="rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-4">
        <b className="flex items-center gap-1.5 text-[14px]"><Ticket size={16} className="text-[#e9e400]" />{localizeStatic(" مربی من")}</b>
        {coach ? (
          <div className="mt-3 flex items-center gap-3">
            <img src={coach.avatar} className="h-12 w-12 rounded-full object-cover" alt="" />
            <div>
              <b className="block text-[14px]">{coach.name}</b>
              <span className="text-[11.5px] text-[var(--color-mute)]" dir="ltr">{coach.email}</span>
            </div>
          </div>
        ) : (
          <>
            <p className="mt-1 text-[12px] text-[var(--color-mute)]">{localizeStatic("کد ۶ حرفی که مربی به تو داده را وارد کن.")}</p>
            <div className="mt-2 flex gap-2">
              <input className={`${inputCls} tracking-[0.3em]`} value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder={localizeStatic("A3K9PQ")} dir="ltr" maxLength={8} />
              <BrandBtn onClick={async () => { const e = await Promise.resolve(joinCoach(code)); if (e) onToast(e, ""); else { onToast("به مربی وصل شدی", "حالا برنامه‌ات را از او می‌گیری"); setCode(""); } }}>{localizeStatic("اتصال")}</BrandBtn>
            </div>
          </>
        )}
      </div>

      <ProfileEditor onToast={onToast} />

      <div data-guide="student-settings">
        <SettingsSection icon={<Palette size={17} />} title={localize(t("set.appearance"))}>
          <AppearanceSettings onToast={onToast} />
        </SettingsSection>
      </div>

      <SettingsSection icon={<Globe size={17} />} title={localize(t("set.language"))}>
        <LanguageSection />
      </SettingsSection>

      <SettingsSection icon={<Bell size={17} />} title={localize(t("set.notifications"))}>
        <NotificationSection />
        <div className="mt-3 border-t border-[var(--color-line)] pt-3">
          {localize(notifs.length === 0 && <p className="mt-2 text-[12px] text-[var(--color-mute)]">{localizeStatic("اعلانی نداری.")}</p>)}
          {localize(notifs.slice(0, 10).map((n) => (
            <button key={n.id} onClick={() => markNotif(n.id)} className="press mt-2 flex w-full items-start gap-2 rounded-xl bg-[var(--color-bg)] p-2.5 text-right">
              {localize(!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-[#e9e400]" />)}
              <span className="flex-1">
                <b className="block text-[12.5px]">{localize(n.title)}</b>
                <span className="block text-[11.5px] text-[var(--color-mute)]">{localize(n.body)}</span>
                <span className="text-[10px] text-[var(--color-mute)]">{localize(formatRelative(n.time))}</span>
              </span>
            </button>
          )))}
        </div>
      </SettingsSection>

      <button onClick={() => { logout(); go("/login"); }} className="press flex w-full items-center justify-center gap-2 rounded-2xl bg-red-500/15 py-3.5 text-[13px] font-black text-red-400">
        <LogOut size={16} />{localizeStatic(" خروج از حساب")}</button>
      <p className="text-center text-[10.5px] text-[var(--color-mute)]" dir="ltr">{localizeStatic("Revo sport")}</p>
    </div>
  );
}
