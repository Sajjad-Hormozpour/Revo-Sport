import { currentLanguage, localize, localizeStatic } from "../../../i18n";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Camera, Clapperboard, Dumbbell, Image as ImageIcon, Info, Library, Link as LinkIcon,
  List, Grid2X2, Pencil, PersonStanding, Play, Plus, RotateCcw, Search, Send, SlidersHorizontal,
  Sparkles, Trash2, Upload, Video, X, Target, CheckCircle2,
} from "lucide-react";
import { useStore } from "../../lib/store";
import { EQUIPMENT, EXERCISES, MUSCLES, libraryFor } from "../../data/library";
import { readGender } from "../../lib/gender";
import type { AppData, CoachExercise, ProgramSet, WorkoutProgram } from "../../data/types";
import { fa, uid } from "../../lib/core";
import { addDays, dayKey, formatJalaliDate, nowIso, WEEK } from "../../lib/time";
import { deleteBlob, saveBlob, useMediaUrl } from "../../lib/media";
import { ExThumb, ExVideo } from "../../components/exercise";
import { libraryAnimation } from "../../components/ExerciseAnimation";
import {
  GROUP_BY_ID, MUSCLE_GROUPS, MuscleMapCredit, MuscleMapPanel, MuscleMiniMap,
  groupIdsForMuscleLabel, readMapGender, type MapGender,
} from "../../components/muscle-map";
import { BrandBtn, Empty, Field, Modal, Pill, inputCls } from "../../components/ui";
import AnimationStudio from "../../animation/AnimationStudio";

export type MovesTab = "library" | "muscles" | "mine" | "studio";

type Level = "مبتدی" | "متوسط" | "پیشرفته";

/** یک حرکت، چه استاندارد و چه اختصاصی مربی — با یک شکل واحد */
interface MoveRow {
  id: string;
  name: string;
  en: string;
  muscle: string;
  equipment: string;
  level: Level;
  custom: boolean;
  source: CoachExercise | null;
}

interface AssignTarget {
  id: string;
  name: string;
  muscle: string;
  equipment: string;
  defaultSets: number;
  defaultReps: string;
  defaultWeight: string;
  defaultRest: number;
  defaultRpe: number;
  defaultTempo: string;
}

const LEVEL_ORDER: Record<Level, number> = { مبتدی: 1, متوسط: 2, پیشرفته: 3 };
const PAGE = 18;

const asTarget = (row: MoveRow): AssignTarget => {
  if (row.source) {
    return {
      id: row.id,
      name: row.name,
      muscle: row.muscle,
      equipment: row.equipment,
      defaultSets: row.source.defaultSets,
      defaultReps: row.source.defaultReps,
      defaultWeight: row.source.defaultWeight,
      defaultRest: row.source.defaultRest,
      defaultRpe: row.source.defaultRpe,
      defaultTempo: row.source.defaultTempo,
    };
  }
  const preset: Record<Level, { reps: string; rest: number; rpe: number }> = {
    مبتدی: { reps: "۱۲", rest: 60, rpe: 6 },
    متوسط: { reps: "۱۰", rest: 75, rpe: 7 },
    پیشرفته: { reps: "۸", rest: 90, rpe: 8 },
  };
  const p = preset[row.level];
  return {
    id: row.id,
    name: row.name,
    muscle: row.muscle,
    equipment: row.equipment,
    defaultSets: 3,
    defaultReps: p.reps,
    defaultWeight: "—",
    defaultRest: p.rest,
    defaultRpe: p.rpe,
    defaultTempo: "۳-۰-۱",
  };
};

/* ------------------------------------------------------------------ */
/* main                                                                */
/* ------------------------------------------------------------------ */

export default function CoachMoves({
  onToast, initialTab = "library",
}: {
  onToast: (t: string, d: string) => void;
  initialTab?: MovesTab;
}) {
  const { data, session, saveCoachExercise, removeCoachExercise } = useStore();
  const coachId = session?.userId ?? "";
  const [tab, setTab] = useState<MovesTab>(initialTab);
  const [q, setQ] = useState("");
  const [muscle, setMuscle] = useState("همه");
  const [mapGender, setMapGender] = useState<MapGender>(readMapGender);
  const [mapGroup, setMapGroup] = useState<string | null>(null);
  const [eq, setEq] = useState("همه");
  const [lv, setLv] = useState("همه");
  const [origin, setOrigin] = useState<"all" | "standard" | "custom">("all");
  const [sort, setSort] = useState<"name" | "muscle" | "level">("name");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [limit, setLimit] = useState(PAGE);
  const [detail, setDetail] = useState<MoveRow | null>(null);
  const [form, setForm] = useState<CoachExercise | "new" | null>(null);
  const [assign, setAssign] = useState<MoveRow | null>(null);

  useEffect(() => setTab(initialTab), [initialTab]);
  useEffect(() => {
    if (tab === "mine") setOrigin("all");
  }, [tab]);
  useEffect(() => setLimit(PAGE), [q, muscle, mapGroup, eq, lv, origin, sort, tab]);

  const mine = useMemo(
    () => data.coachExercises.filter((c) => !c.coachId || c.coachId === coachId),
    [data.coachExercises, coachId],
  );

  const rows = useMemo<MoveRow[]>(() => {
    const gender = readGender();
    const custom: MoveRow[] = mine.map((c) => ({
      id: c.id, name: c.name, en: c.en, muscle: c.muscle, equipment: c.equipment,
      level: c.level, custom: true, source: c,
    }));
    const standard: MoveRow[] = libraryFor(gender).map((e) => ({
      id: e.id, name: e.name, en: e.en, muscle: e.muscle, equipment: e.equipment,
      level: e.level, custom: false, source: null,
    }));
    return [...custom, ...standard];
  }, [mine]);

  const showOrigin = tab === "library" || tab === "muscles";

  const mapCounts = useMemo(() => {
    const term = q.trim().toLowerCase();
    const acc: Record<string, number> = {};
    for (const row of rows) {
      if (origin === "standard" && row.custom) continue;
      if (origin === "custom" && !row.custom) continue;
      if (eq !== "همه" && row.equipment !== eq) continue;
      if (lv !== "همه" && row.level !== lv) continue;
      if (term && !`${row.name} ${row.en} ${row.muscle} ${row.equipment}`.toLowerCase().includes(term)) continue;
      for (const gid of groupIdsForMuscleLabel(row.muscle)) {
        acc[gid] = (acc[gid] ?? 0) + 1;
      }
    }
    return acc;
  }, [rows, origin, eq, lv, q]);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    const list = rows.filter((row) => {
      if (tab === "mine" && !row.custom) return false;
      if (showOrigin && origin === "standard" && row.custom) return false;
      if (showOrigin && origin === "custom" && !row.custom) return false;
      if (tab === "muscles") {
        if (mapGroup && !groupIdsForMuscleLabel(row.muscle).includes(mapGroup)) return false;
      } else if (muscle !== "همه" && row.muscle !== muscle) {
        return false;
      }
      if (eq !== "همه" && row.equipment !== eq) return false;
      if (lv !== "همه" && row.level !== lv) return false;
      if (term && !`${row.name} ${row.en} ${row.muscle} ${row.equipment}`.toLowerCase().includes(term)) return false;
      return true;
    });
    return list.sort((a, b) => {
      if (sort === "muscle") return a.muscle.localeCompare(b.muscle, "fa") || a.name.localeCompare(b.name, "fa");
      if (sort === "level") return LEVEL_ORDER[a.level] - LEVEL_ORDER[b.level] || a.name.localeCompare(b.name, "fa");
      return a.name.localeCompare(b.name, "fa");
    });
  }, [rows, q, muscle, mapGroup, eq, lv, origin, sort, tab, showOrigin]);

  const counts = useMemo(() => ({
    all: rows.length,
    standard: rows.filter((r) => !r.custom).length,
    custom: rows.filter((r) => r.custom).length,
    animated: EXERCISES.filter((item) => !!libraryAnimation(item.id)).length,
    groups: MUSCLE_GROUPS.length,
  }), [rows]);

  const activeMapGroup = tab === "muscles" && mapGroup ? GROUP_BY_ID.get(mapGroup) ?? null : null;
  const isFiltered =
    !!q.trim() ||
    eq !== "همه" ||
    lv !== "همه" ||
    (showOrigin && origin !== "all") ||
    (tab === "muscles" ? !!mapGroup : muscle !== "همه");

  const reset = () => {
    setQ("");
    setMuscle("همه");
    setMapGroup(null);
    setEq("همه");
    setLv("همه");
    setOrigin("all");
    setSort("name");
  };

  const openOnMap = (muscleLabel?: string) => {
    if (muscleLabel && muscleLabel !== "همه") {
      const first = groupIdsForMuscleLabel(muscleLabel)[0] ?? null;
      setMapGroup(first);
    }
    setTab("muscles");
  };

  const startDelete = async (row: MoveRow) => {
    const custom = row.source;
    if (!custom) return;
    if (!confirm(`«${custom.name}» حذف شود؟`)) return;
    if (custom.imageMediaId) await deleteBlob(custom.imageMediaId);
    if (custom.videoMediaId) await deleteBlob(custom.videoMediaId);
    removeCoachExercise(custom.id);
    onToast(localizeStatic("حذف شد"), custom.name);
  };

  return (
    <div data-guide-page={`moves-${tab}`} className="screen-in mx-auto max-w-6xl space-y-3">
      <MovesHero counts={counts} onNew={() => setForm("new")} onStudio={() => setTab("studio")} tab={tab} onTab={setTab} />

      {tab === "studio" ? (
        <AnimationStudio onToast={onToast} />
      ) : (
        <>
          {tab === "muscles" && (
            <MuscleMapPanel
              gender={mapGender}
              onGender={setMapGender}
              selected={mapGroup}
              onSelect={setMapGroup}
              counts={mapCounts}
            />
          )}

          {activeMapGroup && (
            <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-[#c9f31c]/30 bg-[#c9f31c]/[0.07] px-3.5 py-2.5">
              <Target size={15} className="shrink-0 text-[#c9f31c]" />
              <b className="text-[12.5px]">{localize(activeMapGroup.fa)}</b>
              <span className="text-[10.5px] text-[var(--color-mute)]" dir="ltr">{activeMapGroup.en}</span>
              <span className="tnum rounded-full bg-[var(--color-bg)] px-2.5 py-0.5 text-[10.5px] font-black">
                {localize(fa(filtered.length))} {localizeStatic("حرکت")}
              </span>
              <span className="text-[10.5px] text-[var(--color-mute)]">
                {localizeStatic(
                  activeMapGroup.views.length === 2
                    ? "در نمای روبه‌رو و پشت مشخص می‌شود"
                    : activeMapGroup.views[0] === "front"
                      ? "در نمای روبه‌رو مشخص می‌شود"
                      : "در نمای پشت مشخص می‌شود",
                )}
              </span>
              <button
                type="button"
                onClick={() => setMapGroup(null)}
                className="press mr-auto inline-flex items-center gap-1 rounded-full bg-[var(--color-bg)] px-3 py-1 text-[10.5px] font-black text-[#c9f31c] hover:bg-white/[0.06]"
              >
                <RotateCcw size={11} />
                {localizeStatic("همه‌ی عضلات")}
              </button>
            </div>
          )}

          <Toolbar
            {...{ q, setQ, muscle, setMuscle, eq, setEq, lv, setLv, origin, setOrigin, sort, setSort, view, setView, isFiltered, reset }}
            showOrigin={showOrigin}
            hideMuscleChips={tab === "muscles"}
            onOpenMap={() => openOnMap(muscle)}
            result={filtered.length}
            total={tab === "mine" ? counts.custom : counts.all}
          />

          {filtered.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-[var(--color-line)] py-12 text-center">
              <Search size={22} className="mx-auto text-[var(--color-mute)]" />
              <b className="mt-2 block text-[13px]">
                {localizeStatic(
                  tab === "mine"
                    ? "هنوز حرکت اختصاصی نساخته‌ای"
                    : tab === "muscles"
                      ? "حرکتی برای این عضله پیدا نشد"
                      : "حرکتی با این مشخصات پیدا نشد",
                )}
              </b>
              <p className="mt-1 text-[11.5px] text-[var(--color-mute)]">
                {localizeStatic(
                  tab === "mine"
                    ? "با دکمهٔ «حرکت جدید» ویدیو و تنظیمات حرکت خودت را بساز."
                    : tab === "muscles"
                      ? "عضلهٔ دیگری را از روی بدن انتخاب کن یا فیلترها را پاک کن."
                      : "فیلترها را تغییر بده یا همه را پاک کن.",
                )}
              </p>
              <div className="mt-3 flex flex-wrap justify-center gap-2">
                {isFiltered && (
                  <button onClick={reset} className="press rounded-full bg-[#e9e400] px-4 py-2 text-[11.5px] font-black text-black">
                    {localizeStatic(tab === "muscles" ? "همه‌ی عضلات" : "نمایش همه حرکات")}
                  </button>
                )}
                {tab === "mine" && (
                  <button onClick={() => setForm("new")} className="press rounded-full border border-[var(--color-line)] px-4 py-2 text-[11.5px] font-black">
                    <Plus size={13} className="mr-1 inline" />{localizeStatic(" حرکت جدید")}
                  </button>
                )}
              </div>
            </div>
          ) : (
            <>
              <div data-guide="moves-results" className={view === "grid" ? "grid grid-cols-2 gap-2.5 sm:grid-cols-3 sm:gap-3 lg:grid-cols-4" : "space-y-2"}>
                {filtered.slice(0, limit).map((row) => (
                  <MoveCard
                    key={row.id}
                    row={row}
                    view={view}
                    data={data}
                    onOpen={() => setDetail(row)}
                    onEdit={() => row.source && setForm(row.source)}
                    onDelete={() => startDelete(row)}
                    onAssign={() => setAssign(row)}
                  />
                ))}
              </div>
              {limit < filtered.length && (
                <button
                  onClick={() => setLimit((value) => value + PAGE)}
                  className="press flex w-full items-center justify-center gap-1.5 rounded-2xl border border-dashed border-[#e9e400]/40 py-3 text-[12.5px] font-black text-[#e9e400]"
                >
                  <Plus size={14} />
                  {localizeStatic("نمایش حرکات بیشتر")}
                  <span className="tnum">({localize(fa(filtered.length - limit))})</span>
                </button>
              )}
            </>
          )}

          <div className="flex items-start gap-2 rounded-2xl bg-[var(--color-card)] p-3 text-[10.5px] leading-5 text-[var(--color-mute)]">
            <Info size={14} className="mt-0.5 shrink-0 text-[#e9e400]" />
            <p>
              {localizeStatic(
                tab === "muscles"
                  ? "روی هر عضله در نمای روبه‌رو یا پشت بدن کلیک کن تا حرکات استاندارد و اختصاصی همان گروه نمایش داده شود؛ با دکمهٔ «به شاگرد» مستقیماً حرکت را به برنامه اضافه کن."
                  : "حرکات اختصاصی تو بالای فهرست و با برچسب «من» نشان داده می‌شوند. برای دادن حرکت با ست و تکرار دلخواه، دکمهٔ «به شاگرد» را بزن.",
              )}
            </p>
          </div>

          {tab === "muscles" && <MuscleMapCredit />}
        </>
      )}

      {form && (
        <MoveForm
          key={form === "new" ? "new" : form.id}
          initial={form === "new" ? null : form}
          onClose={() => setForm(null)}
          onSave={(saved) => {
            saveCoachExercise(saved);
            setForm(null);
            setTab("mine");
            onToast(localizeStatic("ذخیره شد"), `«${saved.name}» در حرکات تو ذخیره شد`);
          }}
          onToast={onToast}
        />
      )}

      <Modal open={!!detail} onClose={() => setDetail(null)} title={localize(detail?.name ?? "")} wide>
        {detail && (
          <MoveDetail
            row={detail}
            data={data}
            mapGender={mapGender}
            onAssign={() => { setAssign(detail); setDetail(null); }}
            onEdit={() => { if (detail.source) { setForm(detail.source); setDetail(null); } }}
            onShowOnMap={() => {
              const targetMuscle = detail.muscle;
              setDetail(null);
              openOnMap(targetMuscle);
            }}
          />
        )}
      </Modal>

      {assign && (
        <AssignMove
          key={assign.id}
          target={asTarget(assign)}
          onClose={() => setAssign(null)}
          onToast={onToast}
        />
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* hero + tabs                                                         */
/* ------------------------------------------------------------------ */

function MovesHero({
  counts, onNew, onStudio, tab, onTab,
}: {
  counts: { all: number; standard: number; custom: number; animated: number; groups: number };
  onNew: () => void;
  onStudio: () => void;
  tab: MovesTab;
  onTab: (tab: MovesTab) => void;
}) {
  const TABS: { id: MovesTab; label: string; icon: typeof Library }[] = [
    { id: "library", label: "کتابخانه حرکات", icon: Library },
    { id: "muscles", label: "نقشهٔ عضلات", icon: PersonStanding },
    { id: "mine", label: "حرکات من", icon: Dumbbell },
    { id: "studio", label: "استودیو انیمیشن", icon: Clapperboard },
  ];
  return (
    <section data-reveal className="library-hero relative overflow-hidden rounded-3xl border border-[var(--color-line)] p-4 sm:p-5">
      <div className="pointer-events-none absolute -left-16 -top-20 h-56 w-56 rounded-full bg-[#e9e400]/15 blur-[80px]" />
      <div className="relative flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <span className="flex items-center gap-1.5 text-[11px] font-black text-[#e9e400]">
            <Sparkles size={13} />{localizeStatic(" مرکز یکپارچه حرکات و آناتومی")}
          </span>
          <h2 className="mt-1 text-[21px] font-black sm:text-[25px]">{localizeStatic("حرکات")}</h2>
          <p className="mt-1 max-w-xl text-[12px] leading-6 text-[var(--color-mute)]">
            {localizeStatic("کتابخانهٔ استاندارد، نقشهٔ تعاملی عضلات آقایان و بانوان، حرکات اختصاصی خودت و استودیو سه‌بعدی در یک بخش.")}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            data-guide="moves-create"
            onClick={onNew}
            className="press flex h-11 items-center gap-2 rounded-2xl bg-[#e9e400] px-4 text-[12.5px] font-black text-black shadow-[0_12px_30px_-12px_rgba(233,228,0,0.75)]"
          >
            <Plus size={15} />{localizeStatic(" حرکت جدید")}
          </button>
          {tab !== "studio" && (
            <button onClick={onStudio} className="press glass flex h-11 items-center gap-2 rounded-2xl border border-[var(--color-line)] px-4 text-[12.5px] font-black">
              <Clapperboard size={15} />{localizeStatic(" استودیو")}
            </button>
          )}
        </div>
      </div>

      <div className="glass relative mt-4 grid grid-cols-2 gap-2 rounded-2xl p-2.5 sm:grid-cols-4">
        <HeroStat icon={<Library size={14} />} value={counts.standard} label={localizeStatic("حرکت استاندارد")} />
        <HeroStat icon={<Dumbbell size={14} />} value={counts.custom} label={localizeStatic("حرکت اختصاصی من")} />
        <HeroStat icon={<PersonStanding size={14} />} value={counts.groups} label={localizeStatic("گروه عضلانی نقشه")} />
        <HeroStat icon={<Camera size={14} />} value={counts.animated} label={localizeStatic("انیمیشن سه‌بعدی")} />
      </div>

      <div data-guide="moves-tabs" className="relative mt-3 grid grid-cols-2 gap-1 rounded-2xl border border-[var(--color-line)] bg-[var(--color-bg)] p-1 sm:flex" role="tablist" aria-label={localizeStatic("بخش حرکات")}>
        {TABS.map((item) => {
          const Icon = item.icon;
          const active = tab === item.id;
          return (
            <button
              key={item.id}
              role="tab"
              aria-selected={active}
              onClick={() => onTab(item.id)}
              className={`press flex min-h-[42px] flex-1 items-center justify-center gap-1.5 rounded-xl px-2 text-[11.5px] font-black transition sm:text-[12.5px] ${
                active ? "bg-[#e9e400] text-black shadow-[0_10px_24px_-14px_rgba(233,228,0,0.9)]" : "text-[var(--color-mute)] hover:text-[var(--color-ink)]"
              }`}
            >
              <Icon size={15} />
              <span className="truncate">{localizeStatic(item.label)}</span>
            </button>
          );
        })}
      </div>
    </section>
  );
}

function HeroStat({ icon, value, label }: { icon: React.ReactNode; value: number; label: string }) {
  return (
    <div className="flex items-center gap-2 rounded-xl bg-[var(--color-bg)] px-2.5 py-2">
      <span className="text-[#e9e400]">{icon}</span>
      <span className="min-w-0">
        <b className="tnum block text-[15px] leading-5">{localize(fa(value))}</b>
        <span className="block truncate text-[9.5px] text-[var(--color-mute)]">{localize(label)}</span>
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* toolbar                                                             */
/* ------------------------------------------------------------------ */

interface ToolbarProps {
  q: string; setQ: (v: string) => void;
  muscle: string; setMuscle: (v: string) => void;
  eq: string; setEq: (v: string) => void;
  lv: string; setLv: (v: string) => void;
  origin: "all" | "standard" | "custom"; setOrigin: (v: "all" | "standard" | "custom") => void;
  sort: "name" | "muscle" | "level"; setSort: (v: "name" | "muscle" | "level") => void;
  view: "grid" | "list"; setView: (v: "grid" | "list") => void;
  isFiltered: boolean; reset: () => void;
  showOrigin: boolean;
  hideMuscleChips?: boolean;
  onOpenMap?: () => void;
  result: number; total: number;
}

function Toolbar(props: ToolbarProps) {
  const { q, setQ, muscle, setMuscle, eq, setEq, lv, setLv, origin, setOrigin, sort, setSort, view, setView, isFiltered, reset, showOrigin, hideMuscleChips, onOpenMap, result, total } = props;
  return (
    <section data-guide="moves-filters" data-reveal className="sticky top-0 z-20 space-y-2.5 rounded-2xl border border-[var(--color-line)] bg-[var(--color-bg2)]/92 p-3 shadow-[0_14px_30px_-24px_rgba(0,0,0,0.75)] backdrop-blur-xl">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <div className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-[var(--color-line)] bg-[var(--color-card)] px-3 py-2.5">
          <Search size={16} className="shrink-0 text-[var(--color-mute)]" />
          <input
            value={q}
            onChange={(event) => setQ(event.target.value)}
            placeholder={localizeStatic("نام فارسی یا انگلیسی، عضله یا وسیله…")}
            className="min-w-0 flex-1 bg-transparent text-[12.5px] outline-none"
            aria-label={localizeStatic("جستجوی حرکت")}
          />
          {localize(q && <button onClick={() => setQ("")} aria-label={localizeStatic("پاک کردن جستجو")}><X size={14} className="text-[var(--color-mute)]" /></button>)}
        </div>
        <div className="grid grid-cols-2 gap-2 sm:flex">
          {showOrigin && (
            <select aria-label={localizeStatic("منبع حرکت")} className={`${inputCls} h-10 min-w-0 text-[11.5px] sm:w-32`} value={origin} onChange={(event) => setOrigin(event.target.value as typeof origin)}>
              <option value="all">{localizeStatic("همه حرکات")}</option>
              <option value="standard">{localizeStatic("استاندارد")}</option>
              <option value="custom">{localizeStatic("اختصاصی من")}</option>
            </select>
          )}
          <select aria-label={localizeStatic("فیلتر وسیله")} className={`${inputCls} h-10 min-w-0 text-[11.5px] sm:w-32`} value={eq} onChange={(event) => setEq(event.target.value)}>
            <option value="همه">{localizeStatic("همه")}</option>
            {localize(EQUIPMENT.map((item) => <option key={item} value={item}>{localize(item)}</option>))}
          </select>
          <select aria-label={localizeStatic("فیلتر سطح")} className={`${inputCls} h-10 min-w-0 text-[11.5px] sm:w-28`} value={lv} onChange={(event) => setLv(event.target.value)}>
            <option value="همه">{localizeStatic("همه")}</option>
            <option value="مبتدی">{localizeStatic("مبتدی")}</option>
            <option value="متوسط">{localizeStatic("متوسط")}</option>
            <option value="پیشرفته">{localizeStatic("پیشرفته")}</option>
          </select>
          <select aria-label={localizeStatic("مرتب‌سازی")} className={`${inputCls} h-10 min-w-0 text-[11.5px] sm:w-32`} value={sort} onChange={(event) => setSort(event.target.value as typeof sort)}>
            <option value="name">{localizeStatic("ترتیب نام")}</option>
            <option value="muscle">{localizeStatic("گروه عضلانی")}</option>
            <option value="level">{localizeStatic("سطح سختی")}</option>
          </select>
        </div>
      </div>

      {!hideMuscleChips && (
        <div className="noscroll flex items-center gap-1.5 overflow-x-auto pb-0.5">
          {onOpenMap && (
            <button
              type="button"
              onClick={onOpenMap}
              className="press flex shrink-0 items-center gap-1 rounded-full border border-[#c9f31c]/40 bg-[#c9f31c]/10 px-3 py-1.5 text-[11px] font-black text-[#c9f31c] hover:bg-[#c9f31c]/20"
            >
              <PersonStanding size={13} />
              {localizeStatic("نقشهٔ بدن")}
            </button>
          )}
          {localize(["همه", ...MUSCLES].map((item) => (
            <button
              key={item}
              onClick={() => setMuscle(item)}
              className={`press shrink-0 rounded-full px-3 py-1.5 text-[11px] font-black transition ${
                muscle === item ? "bg-[#e9e400] text-black" : "bg-[var(--color-card)] text-[var(--color-mute)] hover:text-[var(--color-ink)]"
              }`}
            >
              {localize(item)}
            </button>
          )))}
          {localize(isFiltered && (
            <button onClick={reset} className="press mr-auto flex shrink-0 items-center gap-1 rounded-full border border-red-500/20 px-3 py-1.5 text-[10.5px] font-bold text-red-400">
              <RotateCcw size={12} />{localizeStatic(" پاک کردن فیلترها")}
            </button>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between gap-2 border-t border-[var(--color-line)] pt-2">
        <p className="tnum flex items-center gap-1.5 text-[11.5px] text-[var(--color-mute)]">
          <SlidersHorizontal size={12} className="text-[#e9e400]" />
          {localizeStatic("نمایش ")}<b className="text-[var(--color-ink)]">{localize(fa(result))}</b>
          {localizeStatic(" از ")}{localize(fa(total))}{localizeStatic(" حرکت")}
        </p>
        <div className="flex items-center gap-2">
          {hideMuscleChips && isFiltered && (
            <button onClick={reset} className="press flex shrink-0 items-center gap-1 rounded-full border border-red-500/20 px-2.5 py-1 text-[10.5px] font-bold text-red-400">
              <RotateCcw size={11} />{localizeStatic("پاک کردن فیلترها")}
            </button>
          )}
          <div className="flex rounded-xl border border-[var(--color-line)] bg-[var(--color-card)] p-1" aria-label={localizeStatic("نوع نمایش")}>
            <button onClick={() => setView("grid")} aria-label={localizeStatic("نمای شبکه‌ای")} aria-pressed={view === "grid"} className={`press flex h-7 w-8 items-center justify-center rounded-lg ${view === "grid" ? "bg-[#e9e400] text-black" : "text-[var(--color-mute)]"}`}><Grid2X2 size={14} /></button>
            <button onClick={() => setView("list")} aria-label={localizeStatic("نمای فهرستی")} aria-pressed={view === "list"} className={`press flex h-7 w-8 items-center justify-center rounded-lg ${view === "list" ? "bg-[#e9e400] text-black" : "text-[var(--color-mute)]"}`}><List size={15} /></button>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* card                                                                */
/* ------------------------------------------------------------------ */

function MoveCard({
  row, view, data, onOpen, onEdit, onDelete, onAssign,
}: {
  row: MoveRow;
  view: "grid" | "list";
  data: AppData;
  onOpen: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onAssign: () => void;
}) {
  if (view === "list") {
    return (
      <div data-reveal className="library-card glass group flex w-full items-center gap-3 rounded-[20px] p-2">
        <button onClick={onOpen} className="press flex min-w-0 flex-1 items-center gap-3 text-right">
          <ExThumb exerciseId={row.id} data={data} className="h-14 w-14 shrink-0 rounded-xl object-cover" />
          <span className="min-w-0 flex-1">
            <b className="block truncate text-[13px] sm:text-[13.5px]">
              {localize(row.name)}
              {row.custom && <span className="mr-1.5 rounded-full bg-[#e9e400]/15 px-1.5 py-0.5 text-[8.5px] font-black text-[#e9e400]">{localizeStatic("من")}</span>}
            </b>
            {currentLanguage() === "en" && row.en && <span className="block truncate text-left text-[9px] text-[var(--color-mute)]" dir="ltr">{row.en}</span>}
            <span className="mt-1.5 flex flex-wrap gap-1">
              <Pill tone="brand">{localize(row.muscle)}</Pill>
              <Pill>{localize(row.equipment)}</Pill>
              <Pill tone="info">{localize(row.level)}</Pill>
            </span>
          </span>
        </button>
        <div className="flex shrink-0 flex-col gap-1">
          <CardAction icon={<Send size={13} />} label={localizeStatic("به شاگرد")} onClick={onAssign} primary />
          {row.custom && <CardAction icon={<Pencil size={13} />} label={localizeStatic("ویرایش")} onClick={onEdit} />}
          {row.custom && <CardAction icon={<Trash2 size={13} />} label={localizeStatic("حذف")} onClick={onDelete} danger />}
        </div>
      </div>
    );
  }

  return (
    <div data-reveal className="library-card glass group overflow-hidden rounded-[20px]">
      <button onClick={onOpen} className="press relative block w-full text-right">
        <span className="relative block h-32 sm:h-36">
          <ExThumb exerciseId={row.id} data={data} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.04]" />
          <span className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
          <span className="absolute bottom-2 left-2 flex h-9 w-9 items-center justify-center rounded-full bg-[#e9e400] shadow-[0_8px_20px_-8px_rgba(233,228,0,0.9)]">
            <Play size={15} className="text-black" fill="currentColor" />
          </span>
          {row.custom && <span className="absolute right-2 top-2"><Pill tone="brand">{localizeStatic("اختصاصی من")}</Pill></span>}
          <span className="absolute bottom-2 right-2 max-w-[70%] truncate text-[12px] font-black text-white">{localize(row.name)}</span>
        </span>
      </button>
      <div className="p-2.5">
        <span className="flex flex-wrap gap-1">
          <Pill tone="brand">{localize(row.muscle)}</Pill>
          <Pill>{localize(row.equipment)}</Pill>
        </span>
        <div className="mt-2 grid grid-cols-2 gap-1.5">
          <CardAction icon={<Send size={12.5} />} label={localizeStatic("به شاگرد")} onClick={onAssign} primary block />
          <CardAction icon={<Info size={12.5} />} label={localizeStatic("جزئیات")} onClick={onOpen} block />
        </div>
        {row.custom && (
          <div className="mt-1.5 grid grid-cols-2 gap-1.5">
            <CardAction icon={<Pencil size={12.5} />} label={localizeStatic("ویرایش")} onClick={onEdit} block />
            <CardAction icon={<Trash2 size={12.5} />} label={localizeStatic("حذف")} onClick={onDelete} danger block />
          </div>
        )}
      </div>
    </div>
  );
}

function CardAction({
  icon, label, onClick, primary, danger, block,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  primary?: boolean;
  danger?: boolean;
  block?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`press flex items-center justify-center gap-1 rounded-xl py-2 text-[11px] font-black transition ${
        primary ? "bg-[#e9e400] text-black hover:brightness-105" : danger ? "bg-red-500/10 text-red-400 hover:bg-red-500/20" : "bg-[var(--color-bg)] text-[var(--color-ink)] hover:bg-white/[0.06]"
      } ${block ? "w-full" : "px-2.5"}`}
    >
      {icon}{localize(label)}
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* detail                                                              */
/* ------------------------------------------------------------------ */

function MoveDetail({
  row, data, mapGender, onAssign, onEdit, onShowOnMap,
}: {
  row: MoveRow;
  data: AppData;
  mapGender: MapGender;
  onAssign: () => void;
  onEdit: () => void;
  onShowOnMap: () => void;
}) {
  const standard = row.custom ? null : EXERCISES.find((item) => item.id === row.id);
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div>
        <ExVideo exerciseId={row.id} data={data} posterClass="aspect-[4/3] w-full rounded-2xl object-cover sm:aspect-video" />
        <div className="mt-2 flex flex-wrap gap-1.5">
          <Pill tone="brand">{localize(row.muscle)}</Pill>
          <Pill>{localize(row.equipment)}</Pill>
          <Pill tone="info">{localize(row.level)}</Pill>
          {row.custom && <Pill tone="ok">{localizeStatic("اختصاصی من")}</Pill>}
        </div>
        <MuscleMiniMap muscleLabel={row.muscle} gender={mapGender} className="mt-2.5" />
        <button
          type="button"
          onClick={onShowOnMap}
          className="press mt-2 flex w-full items-center justify-center gap-1.5 rounded-xl border border-[#c9f31c]/35 bg-[#c9f31c]/10 py-2 text-[11.5px] font-black text-[#c9f31c] hover:bg-[#c9f31c]/20"
        >
          <PersonStanding size={14} />
          {localizeStatic("مشاهدهٔ این عضله روی نقشهٔ کامل")}
        </button>
      </div>

      <div className="space-y-3 text-[12.5px] leading-7">
        {row.source && (
          <div className="rounded-2xl border border-[#e9e400]/25 bg-[#e9e400]/[0.06] p-3">
            <b className="text-[11.5px] text-[#e9e400]">{localizeStatic("پیش‌فرض پیشنهادی")}</b>
            <p className="tnum mt-1 font-black">
              {localize(fa(row.source.defaultSets))}{localizeStatic(" ست × ")}{localize(row.source.defaultReps)}
              {localizeStatic(" • وزن ")}{localize(row.source.defaultWeight)}
              {localizeStatic(" • استراحت ")}{localize(fa(row.source.defaultRest))}{localizeStatic(" ثانیه • RPE ")}{localize(fa(row.source.defaultRpe))}
            </p>
          </div>
        )}

        {standard && (
          <>
            <div>
              <b className="text-[11px] font-black tracking-wider text-[#e9e400]">{localizeStatic("نحوه اجرا")}</b>
              <p className="mt-1 text-[var(--color-mute)]">{localize(standard.how)}</p>
            </div>
            <div>
              <b className="text-[12px]">{localizeStatic("مراحل حرکت")}</b>
              <ol className="mt-2 space-y-2">
                {localize(standard.steps.map((step, index) => (
                  <li key={step} className="flex items-start gap-2 rounded-xl bg-[var(--color-bg)] p-2.5">
                    <span className="tnum flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#e9e400] text-[10px] font-black text-black">{localize(fa(index + 1))}</span>
                    <span className="text-[var(--color-mute)]">{localize(step)}</span>
                  </li>
                )))}
              </ol>
            </div>
            <div className="rounded-2xl border border-red-500/15 bg-red-500/[0.06] p-3">
              <b className="text-[12px] text-red-400">{localizeStatic("اشتباهات رایج")}</b>
              <ul className="mt-1 list-disc pr-5 text-[var(--color-mute)]">{localize(standard.mistakes.map((item) => <li key={item}>{localize(item)}</li>))}</ul>
            </div>
            <div className="rounded-2xl border border-[#e9e400]/20 bg-[#e9e400]/[0.06] p-3">
              <b className="text-[12px] text-[#e9e400]">{localizeStatic("نکته مربی")}</b>
              <p className="mt-1 text-[var(--color-mute)]">{localize(standard.tips)}</p>
            </div>
            <p className="text-[11.5px] text-[var(--color-mute)]">
              <b className="text-[var(--color-ink)]">{localizeStatic("حرکات جایگزین: ")}</b>{localize(standard.alternatives.join("، "))}
            </p>
          </>
        )}

        {row.source && (
          <>
            {localize(row.source.how && <p className="text-[var(--color-mute)]">{localize(row.source.how)}</p>)}
            {localize(row.source.tips && (
              <div className="rounded-2xl border border-[#e9e400]/20 bg-[#e9e400]/[0.06] p-3">
                <b className="text-[12px] text-[#e9e400]">{localizeStatic("نکته مربی")}</b>
                <p className="mt-1 text-[var(--color-mute)]">{localize(row.source.tips)}</p>
              </div>
            ))}
            <p className="text-[11px] text-[var(--color-mute)]">{localizeStatic("ساخته شده در ")}{localize(formatJalaliDate(row.source.createdAt))}</p>
          </>
        )}

        <div className="flex flex-wrap gap-2 pt-1">
          <BrandBtn onClick={onAssign}><Send size={15} />{localizeStatic(" دادن به شاگرد")}</BrandBtn>
          {row.custom && (
            <button onClick={onEdit} className="press flex h-11 items-center gap-2 rounded-full border border-[var(--color-line)] px-5 text-[13px] font-extrabold">
              <Pencil size={14} />{localizeStatic(" ویرایش")}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* create / edit                                                       */
/* ------------------------------------------------------------------ */

function blankMove(coachId: string): CoachExercise {
  return {
    id: uid("cx"), coachId, name: "", en: "", muscle: "سینه", equipment: "وزن بدن", level: "مبتدی",
    imageUrl: "", imageMediaId: "", videoUrl: "", videoMediaId: "", how: "", tips: "",
    defaultSets: 3, defaultReps: "۱۰", defaultWeight: "وزن بدن", defaultRest: 60, defaultRpe: 7,
    defaultTempo: "۳-۰-۱", createdAt: nowIso(),
  };
}

function MoveForm({
  initial, onClose, onSave, onToast,
}: {
  initial: CoachExercise | null;
  onClose: () => void;
  onSave: (c: CoachExercise) => void;
  onToast: (t: string, d: string) => void;
}) {
  const { session } = useStore();
  const [m, setM] = useState<CoachExercise>(() => initial ?? blankMove(session?.userId ?? ""));
  const [imgTab, setImgTab] = useState<"url" | "upload">(m.imageMediaId ? "upload" : "url");
  const [vidTab, setVidTab] = useState<"url" | "upload">(m.videoMediaId ? "upload" : "url");
  const [busy, setBusy] = useState(false);
  const imgRef = useRef<HTMLInputElement>(null);
  const vidRef = useRef<HTMLInputElement>(null);
  const imgPreview = useMediaUrl(imgTab === "upload" ? m.imageMediaId || null : null);
  const vidPreview = useMediaUrl(vidTab === "upload" ? m.videoMediaId || null : null);

  const set = (patch: Partial<CoachExercise>) => setM((value) => ({ ...value, ...patch }));

  const pickImage = async (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) return onToast(localizeStatic("فایل معتبر نیست"), localizeStatic("یک عکس انتخاب کن"));
    setBusy(true);
    try {
      const id = uid("media");
      await saveBlob(id, file);
      if (m.imageMediaId) await deleteBlob(m.imageMediaId);
      set({ imageMediaId: id, imageUrl: "" });
      onToast(localizeStatic("عکس ذخیره شد"), localizeStatic("روی همین دستگاه می‌ماند"));
    } catch {
      onToast(localizeStatic("ذخیره نشد"), localizeStatic("دوباره تلاش کن"));
    } finally {
      setBusy(false);
    }
  };

  const pickVideo = async (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("video/")) return onToast(localizeStatic("فایل معتبر نیست"), localizeStatic("یک ویدیو انتخاب کن"));
    if (file.size > 200 * 1024 * 1024) return onToast(localizeStatic("حجم زیاد است"), localizeStatic("ویدیو کمتر از ۲۰۰ مگابایت بگذار"));
    setBusy(true);
    try {
      const id = uid("media");
      await saveBlob(id, file);
      if (m.videoMediaId) await deleteBlob(m.videoMediaId);
      set({ videoMediaId: id, videoUrl: "" });
      onToast(localizeStatic("ویدیو ذخیره شد"), localizeStatic("حتی بعد از بستن اپ هم پخش می‌شود"));
    } catch {
      onToast(localizeStatic("ذخیره نشد"), localizeStatic("دوباره تلاش کن"));
    } finally {
      setBusy(false);
    }
  };

  const save = () => {
    if (!m.name.trim()) return onToast(localizeStatic("نام لازم است"), localizeStatic("اسم حرکت را بنویس"));
    onSave({ ...m, name: m.name.trim(), coachId: session?.userId ?? m.coachId });
  };

  return (
    <Modal open onClose={onClose} title={localize(initial ? "ویرایش حرکت من" : "حرکت جدید من")} wide>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label={localizeStatic("نام حرکت *")}>
          <input className={inputCls} value={m.name} onChange={(event) => set({ name: event.target.value })} placeholder={localizeStatic("مثلاً پرس سینه اختصاصی")} />
        </Field>
        <Field label={localizeStatic("نام انگلیسی")}>
          <input className={inputCls} value={m.en} onChange={(event) => set({ en: event.target.value })} dir="ltr" placeholder={localizeStatic("My Bench Press")} />
        </Field>
        <Field label={localizeStatic("عضله")}>
          <select className={inputCls} value={m.muscle} onChange={(event) => set({ muscle: event.target.value })}>
            {localize(MUSCLES.map((item) => <option key={item} value={item}>{localize(item)}</option>))}
          </select>
        </Field>
        <Field label={localizeStatic("وسیله")}>
          <select className={inputCls} value={m.equipment} onChange={(event) => set({ equipment: event.target.value })}>
            {localize(EQUIPMENT.map((item) => <option key={item} value={item}>{localize(item)}</option>))}
          </select>
        </Field>
        <Field label={localizeStatic("سطح")}>
          <select className={inputCls} value={m.level} onChange={(event) => set({ level: event.target.value as Level })}>
            <option value="مبتدی">{localizeStatic("مبتدی")}</option>
            <option value="متوسط">{localizeStatic("متوسط")}</option>
            <option value="پیشرفته">{localizeStatic("پیشرفته")}</option>
          </select>
        </Field>
        <Field label={localizeStatic("نحوه اجرا")}>
          <input className={inputCls} value={m.how} onChange={(event) => set({ how: event.target.value })} placeholder={localizeStatic("یک خط توضیح برای شاگرد")} />
        </Field>
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <div className="rounded-2xl bg-[var(--color-bg)] p-3">
          <div className="mb-2 flex items-center justify-between">
            <b className="flex items-center gap-1.5 text-[13px]"><ImageIcon size={15} className="text-[#e9e400]" />{localizeStatic(" عکس حرکت")}</b>
            <div className="flex gap-1">
              <TabBtn active={imgTab === "url"} onClick={() => setImgTab("url")}>{localizeStatic("لینک")}</TabBtn>
              <TabBtn active={imgTab === "upload"} onClick={() => setImgTab("upload")}>{localizeStatic("آپلود")}</TabBtn>
            </div>
          </div>
          {localize(imgTab === "url" ? (
            <input className={inputCls} value={m.imageUrl} onChange={(event) => set({ imageUrl: event.target.value, imageMediaId: "" })} placeholder={localizeStatic("https://…")} dir="ltr" />
          ) : (
            <>
              <input ref={imgRef} type="file" accept="image/*" className="hidden" onChange={(event) => pickImage(event.target.files?.[0])} />
              <button onClick={() => imgRef.current?.click()} disabled={busy} className="press flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-[var(--color-line)] py-3 text-[12.5px] font-bold disabled:opacity-50">
                <Upload size={15} /> {localize(m.imageMediaId ? "تعویض عکس" : "انتخاب عکس از گوشی / کامپیوتر")}
              </button>
              {localize((imgPreview || m.imageMediaId) && <p className="mt-1 flex items-center gap-1 text-[11px] text-emerald-400"><CheckCircle2 size={12} />{localizeStatic(" عکس آپلود شده و ذخیره است")}</p>)}
            </>
          ))}
          {localize((imgPreview || m.imageUrl) && <img src={imgPreview || m.imageUrl} alt="" className="mt-2 h-28 w-full rounded-xl object-cover" />)}
        </div>

        <div className="rounded-2xl bg-[var(--color-bg)] p-3">
          <div className="mb-2 flex items-center justify-between">
            <b className="flex items-center gap-1.5 text-[13px]"><Video size={15} className="text-[#e9e400]" />{localizeStatic(" ویدیو حرکت")}</b>
            <div className="flex gap-1">
              <TabBtn active={vidTab === "url"} onClick={() => setVidTab("url")}>{localizeStatic("لینک")}</TabBtn>
              <TabBtn active={vidTab === "upload"} onClick={() => setVidTab("upload")}>{localizeStatic("آپلود")}</TabBtn>
            </div>
          </div>
          {localize(vidTab === "url" ? (
            <>
              <input className={inputCls} value={m.videoUrl} onChange={(event) => set({ videoUrl: event.target.value, videoMediaId: "" })} placeholder={localizeStatic("mp4 / یوتیوب / آپارات…")} dir="ltr" />
              <p className="mt-1 flex items-center gap-1 text-[10.5px] text-[var(--color-mute)]"><LinkIcon size={11} />{localizeStatic(" لینک مستقیم mp4، یوتیوب و آپارات پخش می‌شود")}</p>
            </>
          ) : (
            <>
              <input ref={vidRef} type="file" accept="video/*" className="hidden" onChange={(event) => pickVideo(event.target.files?.[0])} />
              <button onClick={() => vidRef.current?.click()} disabled={busy} className="press flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-[var(--color-line)] py-3 text-[12.5px] font-bold disabled:opacity-50">
                <Upload size={15} /> {localize(m.videoMediaId ? "تعویض ویدیو" : "انتخاب ویدیو از گوشی / کامپیوتر")}
              </button>
              {localize((vidPreview || m.videoMediaId) && <p className="mt-1 flex items-center gap-1 text-[11px] text-emerald-400"><CheckCircle2 size={12} />{localizeStatic(" ویدیو آپلود و ذخیره شد")}</p>)}
              {localize(vidPreview && <video src={vidPreview} className="mt-2 h-28 w-full rounded-xl bg-black object-cover" controls />)}
            </>
          ))}
        </div>
      </div>

      <div className="mt-3 rounded-2xl border border-[#e9e400]/25 bg-[#e9e400]/[0.05] p-3">
        <b className="flex items-center gap-1.5 text-[13px]"><Dumbbell size={15} className="text-[#e9e400]" />{localizeStatic(" پیش‌فرض ست و تکرار برای شاگرد")}</b>
        <p className="mt-1 text-[11.5px] text-[var(--color-mute)]">{localizeStatic("موقع دادن به شاگرد می‌توانی همین‌ها را تغییر بدهی.")}</p>
        <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
          <Field label={localizeStatic("ست")}>
            <input className={inputCls} type="number" min={1} max={12} value={m.defaultSets} onChange={(event) => set({ defaultSets: Math.max(1, Number(event.target.value) || 1) })} />
          </Field>
          <Field label={localizeStatic("تکرار")}>
            <input className={inputCls} value={m.defaultReps} onChange={(event) => set({ defaultReps: event.target.value })} />
          </Field>
          <Field label={localizeStatic("وزن")}>
            <input className={inputCls} value={m.defaultWeight} onChange={(event) => set({ defaultWeight: event.target.value })} />
          </Field>
          <Field label={localizeStatic("استراحت (ثانیه)")}>
            <input className={inputCls} type="number" value={m.defaultRest} onChange={(event) => set({ defaultRest: Number(event.target.value) || 0 })} />
          </Field>
          <Field label={localizeStatic("RPE")}>
            <input className={inputCls} type="number" min={1} max={10} value={m.defaultRpe} onChange={(event) => set({ defaultRpe: Math.min(10, Math.max(1, Number(event.target.value) || 7)) })} />
          </Field>
          <Field label={localizeStatic("Tempo")}>
            <input className={inputCls} value={m.defaultTempo} onChange={(event) => set({ defaultTempo: event.target.value })} dir="ltr" />
          </Field>
        </div>
      </div>

      <Field label={localizeStatic("نکته مربی")}>
        <input className={inputCls} value={m.tips} onChange={(event) => set({ tips: event.target.value })} placeholder={localizeStatic("مثلاً کمر را صاف نگه دار")} />
      </Field>

      <BrandBtn className="mt-4 w-full" onClick={save} type="button">{localizeStatic("ذخیره حرکت")}</BrandBtn>
    </Modal>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full px-2.5 py-1 text-[11px] font-black transition ${active ? "bg-[#e9e400] text-black" : "bg-white/10 text-white/70 hover:bg-white/20"}`}
    >
      {localize(children)}
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* assign to student                                                   */
/* ------------------------------------------------------------------ */

function AssignMove({
  target, onClose, onToast,
}: {
  target: AssignTarget;
  onClose: () => void;
  onToast: (t: string, d: string) => void;
}) {
  const { data, userById, addProgramItem, saveProgram } = useStore();

  const [sid, setSid] = useState(data.students[0]?.id ?? "");
  const progs = data.programs.filter((program) => program.studentId === sid);
  const [pid, setPid] = useState("");
  const program = progs.find((item) => item.id === pid) ?? progs[0];
  const [dayId, setDayId] = useState("");
  const [sets, setSets] = useState(target.defaultSets);
  const [reps, setReps] = useState(target.defaultReps);
  const [weight, setWeight] = useState(target.defaultWeight);
  const [rest, setRest] = useState(target.defaultRest);
  const [rpe, setRpe] = useState(target.defaultRpe);
  const [tempo, setTempo] = useState(target.defaultTempo);
  const [notes, setNotes] = useState("");

  const day = program?.days.find((item) => item.id === (dayId || program.days[0]?.id));

  const createProgram = () => {
    if (!sid) return onToast(localizeStatic("شاگرد انتخاب کن"), localizeStatic("اول یک شاگرد انتخاب کن"));
    const created: WorkoutProgram = {
      id: uid("pr"), studentId: sid, name: `برنامه ${target.name}`, goal: "عمومی", weeks: 4,
      startDate: dayKey(), endDate: dayKey(addDays(new Date(), 28)), createdAt: nowIso(), status: "فعال",
      days: WEEK.slice(0, 3).map((weekday) => ({ id: uid("d"), weekday, focus: "تمرین", items: [] })),
    };
    saveProgram(created);
    setPid(created.id);
    onToast(localizeStatic("برنامه ساخته شد"), localizeStatic("حالا روز را انتخاب کن"));
  };

  const submit = () => {
    if (!sid) return onToast(localizeStatic("شاگرد انتخاب کن"), localizeStatic("اول یک شاگرد انتخاب کن"));
    if (!program || !day) return onToast(localizeStatic("برنامه و روز لازم است"), localizeStatic("یک برنامه و روز انتخاب کن"));
    const item: ProgramSet = { id: uid("it"), exerciseId: target.id, sets, reps, weight, rest, tempo, rpe, notes };
    addProgramItem(program.id, day.id, item);
    onToast(localizeStatic("به شاگرد داده شد"), `${target.name} • ${fa(sets)}×${reps}`);
    onClose();
  };

  return (
    <Modal open onClose={onClose} title={localize(`دادن «${target.name}» به شاگرد`)} wide>
      <div className="mb-3 flex items-center gap-3 rounded-2xl bg-[var(--color-bg)] p-2.5">
        <ExThumb exerciseId={target.id} data={data} className="h-14 w-14 rounded-xl object-cover" />
        <div className="min-w-0 flex-1">
          <b className="block truncate text-[13.5px]">{localize(target.name)}</b>
          <span className="text-[11.5px] text-[var(--color-mute)]">{localize(target.muscle)} • {localize(target.equipment)}</span>
        </div>
        <button onClick={onClose} aria-label={localizeStatic("بستن")} className="text-[var(--color-mute)]"><X size={16} /></button>
      </div>

      {data.students.length === 0 ? (
        <Empty text="هنوز شاگردی نداری. اول از بخش شاگردان اضافه کن." />
      ) : (
        <>
          <div className="grid gap-2 sm:grid-cols-3">
            <Field label={localizeStatic("شاگرد")}>
              <select className={inputCls} value={sid} onChange={(event) => { setSid(event.target.value); setPid(""); setDayId(""); }}>
                {data.students.map((student) => (
                  <option key={student.id} value={student.id}>{userById(student.userId)?.name ?? "—"}</option>
                ))}
              </select>
            </Field>
            <Field label={localizeStatic("برنامه")}>
              <select className={inputCls} value={program?.id ?? ""} onChange={(event) => { setPid(event.target.value); setDayId(""); }}>
                {localize(progs.map((item) => <option key={item.id} value={item.id}>{item.name}</option>))}
              </select>
            </Field>
            <Field label={localizeStatic("روز")}>
              <select className={inputCls} value={day?.id ?? ""} onChange={(event) => setDayId(event.target.value)}>
                {localize((program?.days ?? []).map((item) => <option key={item.id} value={item.id}>{localize(item.weekday)} — {localize(item.focus)}</option>))}
              </select>
            </Field>
          </div>
          {localize(progs.length === 0 && (
            <button onClick={createProgram} className="press mt-2 w-full rounded-xl border border-dashed border-[#e9e400]/40 py-2.5 text-[12.5px] font-black text-[#e9e400]">
              {localizeStatic("این شاگرد برنامه ندارد — ساخت برنامه جدید")}
            </button>
          ))}

          <div className="mt-3 rounded-2xl bg-[var(--color-bg)] p-3">
            <b className="text-[13px]">{localizeStatic("تنظیم ست و تکرار برای این شاگرد")}</b>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
              <Field label={localizeStatic("تعداد ست")}>
                <input className={inputCls} type="number" min={1} max={12} value={sets} onChange={(event) => setSets(Math.max(1, Number(event.target.value) || 1))} />
              </Field>
              <Field label={localizeStatic("تکرار هر ست")}>
                <input className={inputCls} value={reps} onChange={(event) => setReps(event.target.value)} />
              </Field>
              <Field label={localizeStatic("وزن")}>
                <input className={inputCls} value={weight} onChange={(event) => setWeight(event.target.value)} />
              </Field>
              <Field label={localizeStatic("استراحت (ثانیه)")}>
                <input className={inputCls} type="number" value={rest} onChange={(event) => setRest(Number(event.target.value) || 0)} />
              </Field>
              <Field label={localizeStatic("RPE")}>
                <input className={inputCls} type="number" min={1} max={10} value={rpe} onChange={(event) => setRpe(Math.min(10, Math.max(1, Number(event.target.value) || 7)))} />
              </Field>
              <Field label={localizeStatic("Tempo")}>
                <input className={inputCls} value={tempo} onChange={(event) => setTempo(event.target.value)} dir="ltr" />
              </Field>
            </div>
            <div className="mt-2">
              <Field label={localizeStatic("توضیح برای شاگرد")}>
                <input className={inputCls} value={notes} onChange={(event) => setNotes(event.target.value)} placeholder={localizeStatic("مثلاً آرنج نزدیک بدن بماند")} />
              </Field>
            </div>
          </div>

          <BrandBtn className="mt-3 w-full" onClick={submit}>{localizeStatic("افزودن به برنامه")}</BrandBtn>
        </>
      )}
    </Modal>
  );
}

/* ------------------------------------------------------------------ */
