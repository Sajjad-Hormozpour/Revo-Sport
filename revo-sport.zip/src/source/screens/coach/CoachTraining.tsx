import { localize, localizeStatic } from "../../../i18n";
import { useState } from "react";
import { Plus, ChevronUp, ChevronDown, Trash2, Pencil, CloudCheck, Sparkles } from "lucide-react";
import { useStore } from "../../lib/store";
import { libraryFor } from "../../data/library";
import { readGender } from "../../lib/gender";
import type { WorkoutProgram, ProgramSet } from "../../data/types";
import { fa, uid, WEEK } from "../../lib/core";
import { addDays, dayKey, nowIso } from "../../lib/time";
import { ExThumb, ExVideo, resolveExercise } from "../../components/exercise";
import { SessionExerciseCard } from "../../components/session-view";
import { BrandBtn, Empty, Field, Modal, Pill, SearchBox, inputCls } from "../../components/ui";

export default function CoachTraining({ onToast }: { onToast: (t: string, d: string) => void }) {
  return <Programs onToast={onToast} />;
}


function Programs({ onToast }: { onToast: (t: string, d: string) => void }) {
  const { data, session, userById, saveProgram, removeProgram, addProgramItem, updateProgramItem, moveItem, removeItem, saveWorkoutTemplate, deleteWorkoutTemplate } = useStore();
  const [sid, setSid] = useState(data.students[0]?.id ?? "");
  const [pid, setPid] = useState<string | null>(null);
  const [picker, setPicker] = useState<string | null>(null);
  const [pickerTab, setPickerTab] = useState<"lib" | "mine">("lib");
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState<{ dayId: string; item: ProgramSet } | null>(null);
  const [guide, setGuide] = useState<string | null>(null);

  const list = data.programs.filter((p) => !sid || p.studentId === sid);
  const program = data.programs.find((p) => p.id === pid) ?? list[0];
  const mine = data.coachExercises.filter((c) => !c.coachId || c.coachId === session?.userId);

  const createDraft = () => {
    if (!sid) { onToast("شاگرد نیست", "اول از بخش شاگردان یک نفر اضافه کن"); return; }
    const p: WorkoutProgram = {
      id: uid("pr"),
      studentId: sid,
      name: "برنامه جدید",
      goal: "عمومی",
      weeks: 8,
      startDate: dayKey(),
      endDate: dayKey(addDays(new Date(), 56)),
      createdAt: nowIso(),
      status: "فعال",
      days: WEEK.slice(0, 4).map((w, i) => ({ id: uid("d"), weekday: w, focus: i % 2 ? "بالاتنه" : "پایین‌تنه", items: [] })),
    };
    saveProgram(p);
    setPid(p.id);
    onToast("برنامه ساخته و ذخیره شد", "هر تغییری خودکار برای شاگرد ذخیره می‌شود");
  };

  const suggest = () => {
    const st = data.students.find((s) => s.id === sid);
    const days = st?.assessment.daysPerWeek ?? 4;
    if (!sid) { onToast("شاگرد نیست", "اول شاگرد اضافه کن"); return; }
    const p: WorkoutProgram = {
      id: uid("pr"),
      studentId: sid,
      name: `پیشنهاد هوشمند — ${st?.goal ?? "فیتنس"}`,
      goal: st?.goal ?? "فیتنس",
      weeks: 8,
      startDate: dayKey(),
      endDate: dayKey(addDays(new Date(), 56)),
      createdAt: nowIso(),
      status: "فعال",
      days: WEEK.slice(0, days).map((w, i) => ({
        id: uid("d"),
        weekday: w,
        focus: ["سینه + پشت بازو", "پشت + جلو بازو", "پا + باسن", "شانه + شکم", "تمام بدن"][i % 5],
        items: [
          { id: uid("it"), exerciseId: ["ex-bench", "ex-lat", "ex-squat", "ex-ohp", "ex-pushup"][i % 5], sets: 4, reps: "۱۰", weight: "RPE ۸", rest: 90, tempo: "۳-۰-۱", rpe: 8, notes: "پیشنهاد AI — قابل ویرایش" },
          { id: uid("it"), exerciseId: ["ex-incline-db", "ex-row", "ex-rdl", "ex-latraise", "ex-plank"][i % 5], sets: 3, reps: "۱۲", weight: "متوسط", rest: 75, tempo: "۲-۰-۱", rpe: 7, notes: "" },
        ],
      })),
    };
    saveProgram(p);
    setPid(p.id);
    onToast("برنامه پیشنهادی ذخیره شد", "هر تغییری خودکار ذخیره می‌شود");
  };

  return (
    <div className="screen-in grid gap-3 lg:grid-cols-[280px_1fr]">
      <div data-guide="program-athlete">
        <Field label={localizeStatic("شاگرد")}>
          <select className={inputCls} value={sid} onChange={(e) => { setSid(e.target.value); setPid(null); }}>
            {data.students.map((s) => <option key={s.id} value={s.id}>{userById(s.userId)?.name}</option>)}
          </select>
        </Field>
        <div className="mt-3 flex gap-2">
          <BrandBtn className="flex-1 text-[12px]" onClick={createDraft}><Plus size={14} />{localizeStatic(" برنامه")}</BrandBtn>
          <button onClick={suggest} className="press flex h-11 flex-1 items-center justify-center gap-1 rounded-full border border-[#e9e400]/40 text-[12px] font-black text-[#e9e400]"><Sparkles size={14} />{localizeStatic(" پیشنهاد AI")}</button>
        </div>
        <div className="mt-3 space-y-2">
          {localize(list.map((p) => {
            const active = program?.id === p.id;
            const exCount = p.days.reduce((a, d) => a + d.items.length, 0);
            return (
              <div key={p.id} className={`flex items-center gap-1 rounded-2xl border p-2 ${active ? "border-[#e9e400] bg-[#e9e400]/10" : "border-[var(--color-line)] bg-[var(--color-card)]"}`}>
                <button onClick={() => setPid(p.id)} className="press min-w-0 flex-1 text-right">
                  <b className="block truncate text-[13px]">{p.name}</b>
                  <span className="tnum text-[11px] text-[var(--color-mute)]">{localize(p.status)} • {localize(fa(p.days.length))}{localizeStatic(" روز • ")}{localize(fa(exCount))}{localizeStatic(" حرکت")}</span>
                </button>
                <button
                  onClick={() => {
                    if (!confirm(`برنامه «${p.name}» برای همیشه حذف شود؟ شاگرد دیگر آن را نمی‌بیند.`)) return;
                    removeProgram(p.id);
                    if (pid === p.id) setPid(null);
                    onToast("برنامه حذف شد", p.name);
                  }}
                  className="press flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-red-400 hover:bg-red-500/10"
                  aria-label={localizeStatic("حذف برنامه")}
                  title={localizeStatic("حذف برنامه")}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            );
          }))}
          {localize(list.length === 0 && <Empty text="برنامه‌ای نیست" />)}
        </div>
        <div data-guide="program-templates" className="mt-4 space-y-2 rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-3">
          <b className="text-[12px]">{localizeStatic("قالب‌های تمرینی من")}</b>
          {localize(data.workoutTemplates.length === 0 && <p className="text-[11px] text-[var(--color-mute)]">{localizeStatic("از یک برنامه ساخته‌شده، قالب ذخیره کن و دوباره استفاده کن.")}</p>)}
          {localize(data.workoutTemplates.map((template) => <div key={template.id} className="flex items-center gap-1 rounded-xl bg-[var(--color-bg)] p-2 text-[11px]"><span className="min-w-0 flex-1 truncate">{template.name} • {localize(fa(template.days.length))}{localizeStatic(" روز")}</span><button title={localizeStatic("ساخت برنامه از قالب")} className="text-[#e9e400]" onClick={() => { if (!sid) return onToast("شاگرد انتخاب کن", ""); const p: WorkoutProgram = {id:uid('pr'),studentId:sid,name:template.name,goal:'عمومی',weeks:8,startDate:dayKey(),endDate:dayKey(addDays(new Date(),56)),createdAt:nowIso(),status:'فعال',days:structuredClone(template.days).map((d) => ({...d,id:uid('d'),items:d.items.map((it) => ({...it,id:uid('it')}))}))};saveProgram(p);setPid(p.id);onToast("برنامه از قالب ساخته شد",template.name); }}>{localizeStatic("استفاده")}</button><button title={localizeStatic("حذف قالب")} className="text-red-400" onClick={() => { if(confirm('قالب حذف شود؟')) deleteWorkoutTemplate(template.id); }}><Trash2 size={13}/></button></div>))}
        </div>
      </div>

      {localize(program ? (
        <div>
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <input className={`${inputCls} max-w-xs`} value={program.name} onChange={(e) => saveProgram({ ...program, name: e.target.value })} />
            <Pill tone={program.status === "فعال" ? "ok" : program.status === "پیش‌نویس" ? "info" : "warn"}>{localize(program.status)}</Pill>
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1.5 text-[11px] font-bold text-emerald-400">
              <CloudCheck size={13} />{localizeStatic(" ذخیره خودکار")}</span>
            <button className="rounded-full border border-[var(--color-line)] px-3 py-1.5 text-[11px]" onClick={() => { saveWorkoutTemplate({id:uid('template'),coachId:session?.userId || '',name:program.name,days:structuredClone(program.days),createdAt:nowIso()});onToast('قالب ذخیره شد',program.name); }}>{localizeStatic("ذخیره به‌عنوان قالب")}</button>
            <button
              onClick={() => {
                if (!confirm(`برنامه «${program.name}» برای همیشه حذف شود؟`)) return;
                removeProgram(program.id);
                setPid(null);
                onToast("برنامه حذف شد", program.name);
              }}
              className="press mr-auto flex items-center gap-1.5 rounded-full border border-red-500/30 px-3 py-1.5 text-[11.5px] font-bold text-red-400 hover:bg-red-500/10"
            >
              <Trash2 size={13} />{localizeStatic(" حذف برنامه")}</button>
          </div>
          <div data-guide="program-days" className="space-y-3">
            {localize(program.days.map((day) => (
              <div key={day.id} className="rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-3">
                <div className="mb-2 flex flex-wrap items-center gap-2">
                  <select
                    className="h-9 rounded-xl border border-[var(--color-line)] bg-[var(--color-bg)] px-2 text-[12.5px] font-black outline-none"
                    value={day.weekday}
                    onChange={(e) => saveProgram({ ...program, days: program.days.map((x) => (x.id === day.id ? { ...x, weekday: e.target.value } : x)) })}
                    aria-label={localizeStatic("روز هفته")}
                  >
                    {localize(WEEK.map((w) => <option key={w} value={w}>{localize(w)}</option>))}
                  </select>
                  <input
                    className="h-9 min-w-0 flex-1 rounded-xl border border-[var(--color-line)] bg-[var(--color-bg)] px-2.5 text-[12.5px] outline-none"
                    value={day.focus}
                    onChange={(e) => saveProgram({ ...program, days: program.days.map((x) => (x.id === day.id ? { ...x, focus: e.target.value } : x)) })}
                    placeholder={localizeStatic("تمرکز روز (مثلاً سینه + پشت بازو)")}
                  />
                  <button onClick={() => setPicker(day.id)} className="press flex items-center gap-1 rounded-full bg-[#e9e400] px-3 py-1.5 text-[11px] font-black text-black"><Plus size={12} />{localizeStatic(" حرکت")}</button>
                  <button
                    onClick={() => { if (confirm("این روز از برنامه حذف شود؟")) saveProgram({ ...program, days: program.days.filter((x) => x.id !== day.id) }); }}
                    className="press text-red-400"
                    aria-label={localizeStatic("حذف روز")}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
                {localize(day.items.length > 0 && (
                  <div className="mb-2 flex items-center justify-between rounded-xl bg-[var(--color-bg)] px-2.5 py-1.5">
                    <span className="text-[10.5px] font-bold text-[var(--color-mute)]">
                      {localizeStatic("جلسه ")}
                      {localize(day.weekday)}
                      {localizeStatic(" • ")}
                      {localize(fa(day.items.length))}
                      {localizeStatic(" حرکت • ")}
                      {localize(fa(day.items.reduce((sum, item) => sum + item.sets, 0)))}
                      {localizeStatic(" ست")}
                    </span>
                    <span className="tnum text-[10px] font-black text-[#e9e400]">
                      {localize(fa(day.items.length))}
                      <span className="mx-0.5 text-white/25">/</span>
                      {localize(fa(day.items.reduce((sum, item) => sum + item.sets, 0)))}
                    </span>
                  </div>
                ))}
                <div className="space-y-2.5">
                  {localize(day.items.map((it, idx) => {
                    const e = resolveExercise(it.exerciseId, data);
                    const rir = String(Math.max(0, Math.min(5, 10 - (it.rpe || 7))));
                    const values = Array.from({ length: it.sets }).map(() => ({ weight: it.weight, reps: it.reps, rir }));
                    return (
                      <SessionExerciseCard
                        key={it.id}
                        index={idx + 1}
                        exerciseId={it.exerciseId}
                        name={e.name}
                        muscle={e.muscle}
                        equipment={e.equipment}
                        data={data}
                        sets={it.sets}
                        reps={it.reps}
                        rir={rir}
                        note={it.notes || e.tips}
                        values={values}
                        done={values.map(() => false)}
                        activeSet={0}
                        mode="prescribe"
                        onEditSet={() => setEditing({ dayId: day.id, item: { ...it } })}
                        onGuide={() => setGuide(it.exerciseId)}
                        menuItems={[
                          { label: "تنظیم ست، تکرار و استراحت", icon: <Pencil size={14} />, onClick: () => setEditing({ dayId: day.id, item: { ...it } }) },
                          { label: "حرکت بالاتر", icon: <ChevronUp size={14} />, onClick: () => moveItem(program.id, day.id, idx, -1) },
                          { label: "حرکت پایین‌تر", icon: <ChevronDown size={14} />, onClick: () => moveItem(program.id, day.id, idx, 1) },
                          { label: "حذف حرکت", icon: <Trash2 size={14} />, danger: true, onClick: () => removeItem(program.id, day.id, it.id) },
                        ]}
                        extra={(
                          <div className="flex flex-wrap items-center gap-1.5 px-0.5">
                            <span className="rounded-full bg-white/[0.05] px-2 py-1 text-[9.5px] font-bold text-[#9aa1aa]">
                              {localizeStatic("استراحت ")}{localize(fa(it.rest))}{localizeStatic(" ثانیه")}
                            </span>
                            <span className="rounded-full bg-white/[0.05] px-2 py-1 text-[9.5px] font-bold text-[#9aa1aa]" dir="ltr">
                              Tempo {localize(it.tempo)}
                            </span>
                            <span className="rounded-full bg-white/[0.05] px-2 py-1 text-[9.5px] font-bold text-[#9aa1aa]">
                              RPE {localize(fa(it.rpe))}
                            </span>
                            <button
                              type="button"
                              onClick={() => setEditing({ dayId: day.id, item: { ...it } })}
                              className="mr-auto inline-flex items-center gap-1 rounded-full bg-[#e9e400]/10 px-2.5 py-1 text-[9.5px] font-black text-[#e9e400] transition hover:bg-[#e9e400]/20"
                            >
                              <Pencil size={10.5} />
                              {localizeStatic("ویرایش ست‌ها")}
                            </button>
                          </div>
                        )}
                      />
                    );
                  }))}
                </div>
                {localize(day.items.length === 0 && <p className="py-2 text-center text-[11.5px] text-[var(--color-mute)]">{localizeStatic("حرکتی نیست — دکمه «حرکت» را بزن")}</p>)}
              </div>
            )))}
            <button
              onClick={() => {
                const used = new Set(program.days.map((d) => d.weekday));
                const wd = WEEK.find((w) => !used.has(w)) ?? WEEK[0];
                saveProgram({ ...program, days: [...program.days, { id: uid("d"), weekday: wd, focus: "تمرین", items: [] }] });
              }}
              className="press flex w-full items-center justify-center gap-1.5 rounded-2xl border border-dashed border-[#e9e400]/40 py-3 text-[12.5px] font-black text-[#e9e400]"
            >
              <Plus size={14} />{localizeStatic(" افزودن روز تمرین")}</button>
          </div>
          {localize(!!program.revisions?.length && <details className="mt-3 rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-3">
            <summary className="cursor-pointer text-[12px] font-bold">{localizeStatic("نسخه‌های پیشین برنامه (")}{localize(fa(program.revisions.length))})</summary>
            <div className="mt-2 space-y-1.5">{localize([...program.revisions].reverse().map((revision) => <div key={`${revision.version}-${revision.at}`} className="flex items-center justify-between gap-2 rounded-xl bg-[var(--color-bg)] p-2 text-[11px]"><span>{localizeStatic("نسخه ")}{localize(fa(revision.version))} • {revision.name} • {localize(fa(revision.days.length))}{localizeStatic(" روز")}</span><button className="text-[#e9e400]" onClick={() => { if (confirm("نسخه قبلی روی برنامه فعلی اعمال شود؟ نسخه فعلی در تاریخچه باقی می‌ماند.")) saveProgram({ ...program, name: revision.name, days: structuredClone(revision.days) }); }}>{localizeStatic("بازیابی")}</button></div>))}</div>
          </details>)}
        </div>
      ) : (
        <Empty text="یک برنامه انتخاب کن یا بساز" />
      ))}

      <Modal open={!!picker} onClose={() => setPicker(null)} title={localizeStatic("افزودن حرکت به برنامه")} wide>
        <div className="mb-2 flex gap-2">
          <button onClick={() => setPickerTab("lib")} className={`press rounded-full px-4 py-2 text-[12px] font-black ${pickerTab === "lib" ? "bg-[#e9e400] text-black" : "bg-[var(--color-bg)]"}`}>{localizeStatic("کتابخانه عمومی")}</button>
          <button onClick={() => setPickerTab("mine")} className={`press rounded-full px-4 py-2 text-[12px] font-black ${pickerTab === "mine" ? "bg-[#e9e400] text-black" : "bg-[var(--color-bg)]"}`}>{localizeStatic("حرکات من (")}{localize(fa(mine.length))})
          </button>
        </div>
        <SearchBox value={q} onChange={setQ} placeholder={localizeStatic("جستجو حرکت…")} />
        <div className="mt-3 grid max-h-[50vh] gap-2 overflow-y-auto sm:grid-cols-2">
          {localize(pickerTab === "lib" &&
            libraryFor(readGender()).filter((e) => !q || e.name.includes(q)).map((e) => (
              <button
                key={e.id}
                onClick={() => {
                  if (!program || !picker) return;
                  const item: ProgramSet = { id: uid("it"), exerciseId: e.id, sets: 3, reps: "۱۰", weight: "—", rest: 90, tempo: "۳-۰-۱", rpe: 7, notes: "" };
                  addProgramItem(program.id, picker, item);
                  setPicker(null);
                  setEditing({ dayId: picker, item });
                }}
                className="press flex items-center gap-2 rounded-xl bg-[var(--color-bg)] p-2 text-right"
              >
                <img src={e.image} className="h-10 w-10 rounded-lg object-cover" alt="" />
                <span className="flex-1"><b className="block text-[12.5px]">{localize(e.name)}</b><span className="text-[11px] text-[var(--color-mute)]">{localize(e.muscle)}</span></span>
              </button>
            )))}
          {localize(pickerTab === "mine" && mine.length === 0 && (
            <p className="col-span-2 rounded-xl bg-[var(--color-bg)] p-4 text-center text-[12px] text-[var(--color-mute)]">{localizeStatic("هنوز حرکتی نساختی. از منوی «حرکات و ویدیوهای من» بساز.")}</p>
          ))}
          {localize(pickerTab === "mine" &&
            mine.filter((e) => !q || e.name.includes(q)).map((e) => (
              <button
                key={e.id}
                onClick={() => {
                  if (!program || !picker) return;
                  const item: ProgramSet = {
                    id: uid("it"),
                    exerciseId: e.id,
                    sets: e.defaultSets,
                    reps: e.defaultReps,
                    weight: e.defaultWeight,
                    rest: e.defaultRest,
                    tempo: e.defaultTempo,
                    rpe: e.defaultRpe,
                    notes: "",
                  };
                  addProgramItem(program.id, picker, item);
                  setPicker(null);
                  setEditing({ dayId: picker, item });
                }}
                className="press flex items-center gap-2 rounded-xl border border-[#e9e400]/25 bg-[var(--color-bg)] p-2 text-right"
              >
                <ExThumb exerciseId={e.id} data={data} />
                <span className="flex-1">
                  <b className="block text-[12.5px]">{localize(e.name)}</b>
                  <span className="tnum text-[11px] text-[var(--color-mute)]">{localize(e.muscle)} • {localize(fa(e.defaultSets))}×{localize(e.defaultReps)}</span>
                </span>
              </button>
            )))}
        </div>
      </Modal>

      <Modal open={!!guide} onClose={() => setGuide(null)} title={localize(guide ? resolveExercise(guide, data).name : "")} wide>
        {localize(guide && (
          <div className="grid gap-4 lg:grid-cols-2">
            <div>
              <ExVideo exerciseId={guide} posterClass="aspect-[4/3] w-full rounded-2xl object-cover sm:aspect-video" />
              <div className="mt-2 flex flex-wrap gap-1.5">
                <Pill tone="brand">{localize(resolveExercise(guide, data).muscle)}</Pill>
                <Pill>{localize(resolveExercise(guide, data).equipment)}</Pill>
                <Pill tone="info">{localize(resolveExercise(guide, data).level)}</Pill>
              </div>
            </div>
            <div className="space-y-3 text-[12px] leading-7">
              <div>
                <b className="text-[11px] text-[#e9e400]">{localizeStatic("نحوه اجرا")}</b>
                <p className="mt-1 text-[var(--color-mute)]">{localize(resolveExercise(guide, data).how)}</p>
              </div>
              <div className="rounded-2xl border border-[#e9e400]/20 bg-[#e9e400]/[0.06] p-3">
                <b className="text-[11px] text-[#e9e400]">{localizeStatic("نکته مربی")}</b>
                <p className="mt-1 text-[var(--color-mute)]">{localize(resolveExercise(guide, data).tips)}</p>
              </div>
            </div>
          </div>
        ))}
      </Modal>

      <Modal open={!!editing} onClose={() => setEditing(null)} title={localizeStatic("تنظیم ست و تکرار")}>
        {localize(editing && program && (
          <ItemEditor
            name={resolveExercise(editing.item.exerciseId, data).name}
            item={editing.item}
            onChange={(item) => setEditing({ ...editing, item })}
            onSave={() => {
              updateProgramItem(program.id, editing.dayId, editing.item);
              setEditing(null);
              onToast("ذخیره شد", `${fa(editing.item.sets)} ست × ${editing.item.reps}`);
            }}
          />
        ))}
      </Modal>
    </div>
  );
}

function ItemEditor({
  name, item, onChange, onSave,
}: {
  name: string;
  item: ProgramSet;
  onChange: (item: ProgramSet) => void;
  onSave: () => void;
}) {
  const set = (p: Partial<ProgramSet>) => onChange({ ...item, ...p });
  return (
    <div>
      <p className="mb-3 rounded-2xl bg-[var(--color-bg)] p-3 text-[13px] font-black">{localize(name)}</p>
      <div className="grid grid-cols-3 gap-2">
        <Field label={localizeStatic("تعداد ست")}>
          <input className={inputCls} type="number" min={1} max={12} value={item.sets} onChange={(e) => set({ sets: Math.max(1, Number(e.target.value) || 1) })} />
        </Field>
        <Field label={localizeStatic("تکرار هر ست")}>
          <input className={inputCls} value={item.reps} onChange={(e) => set({ reps: e.target.value })} />
        </Field>
        <Field label={localizeStatic("وزن")}>
          <input className={inputCls} value={item.weight} onChange={(e) => set({ weight: e.target.value })} />
        </Field>
        <Field label={localizeStatic("استراحت (ثانیه)")}>
          <input className={inputCls} type="number" value={item.rest} onChange={(e) => set({ rest: Number(e.target.value) || 0 })} />
        </Field>
        <Field label={localizeStatic("RPE")}>
          <input className={inputCls} type="number" min={1} max={10} value={item.rpe} onChange={(e) => set({ rpe: Number(e.target.value) || 7 })} />
        </Field>
        <Field label={localizeStatic("Tempo")}>
          <input className={inputCls} value={item.tempo} onChange={(e) => set({ tempo: e.target.value })} dir="ltr" />
        </Field>
      </div>
      <div className="mt-2">
        <Field label={localizeStatic("توضیح برای شاگرد")}>
          <input className={inputCls} value={item.notes} onChange={(e) => set({ notes: e.target.value })} />
        </Field>
      </div>
      <BrandBtn className="mt-3 w-full" onClick={onSave}>{localizeStatic("ذخیره در برنامه")}</BrandBtn>
    </div>
  );
}
