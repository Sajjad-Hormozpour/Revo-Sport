import { readGender, type Gender } from "../lib/gender";

/**
 * منابع رسانه‌ای و توضیحات اختصاصی هر جنسیت.
 * تصاویر بانوان به‌صورت جداگانه برای همین پروژه تولید شده‌اند و از همان
 * پالت نوری تصاویر آقایان (سالن تیره، نور کلیدی، فضای سینمایی) پیروی می‌کنند.
 */
import femaleBench from "../../auth/reel-female/bench.jpg";
import femaleCurl from "../../auth/reel-female/curl.jpg";
import femaleSquat from "../../auth/reel-female/squat.jpg";
import femaleHipThrust from "../../auth/reel-female/hip-thrust.jpg";
import femaleLunge from "../../auth/reel-female/lunge.jpg";
import femaleLatPulldown from "../../auth/reel-female/lat-pulldown.jpg";
import femaleAbs from "../../auth/reel-female/abs.jpg";
import maleSquat from "../../auth/reel/squat-portrait.jpg";
import maleCurl from "../../auth/reel/curl-tank.jpg";

export interface GenderExerciseOverride {
  image?: string;
  name?: string;
  how?: string;
  tips?: string;
}

export const FEMALE_EXERCISE_MEDIA: Record<string, string> = {
  "ex-bench": femaleBench,
  "ex-incline-db": femaleBench,
  "ex-curl": femaleCurl,
  "ex-squat": femaleSquat,
  "ex-rdl": femaleHipThrust,
  "ex-lunge": femaleLunge,
  "ex-hip": femaleHipThrust,
  "ex-lat": femaleLatPulldown,
  "ex-pullup": femaleLatPulldown,
  "ex-crunch": femaleAbs,
  "ex-plank": femaleAbs,
  "ex-glute-bridge": femaleHipThrust,
  "ex-cable-kickback": femaleHipThrust,
  "ex-wall-sit": femaleSquat,
};

/** راهنمای اجرای اختصاصی بانوان برای حرکات اصلی */
export const FEMALE_EXERCISE_OVERRIDES: Record<string, GenderExerciseOverride> = {
  "ex-squat": {
    name: "اسکوات باسن‌محور",
    how: "تمرکز روی درگیری باسن: پاها کمی بازتر از لگن، پنجه کمی به بیرون و کنترل کامل در فاز پایین.",
    tips: "زانوها در راستای پنجه حرکت کنند؛ در پایین حرکت یک مکث کوتاه برای درگیری بهتر باسن داشته باش.",
  },
  "ex-hip": {
    name: "هیپ‌تراست (محوریت باسن)",
    how: "کتف‌ها روی نیمکت ثابت، هالتر روی لگن و تا اوج باز شدن لگن بالا بیاور.",
    tips: "چانه را به سینه نزدیک نگه دار تا کمر درگیر نشود و باسن بیشترین فشار را تحمل کند.",
  },
  "ex-lunge": {
    name: "لانج دمبل",
    how: "قدم بلند و کنترل‌شده؛ زانوی جلو پشت پنجه بماند.",
    tips: "برای تمرکز بیشتر روی باسن، تنه را کمی به جلو خم کن.",
  },
  "ex-cable-kickback": {
    name: "کیک‌بک کابل",
    how: "پنجه روی دستگیره کابل، حرکت کامل باسن بدون چرخش کمر.",
    tips: "در اوج حرکت باسن را دو ثانیه نگه دار.",
  },
  "ex-glute-bridge": {
    name: "پل باسن",
    how: "از روی زمین باسن را تا خط شانه بالا بیاور و در اوج منقبض کن.",
    tips: "کمر قوس زیاد نگیر؛ حرکت از باسن انجام شود.",
  },
};

export const MALE_EXERCISE_OVERRIDES: Record<string, GenderExerciseOverride> = {
  "ex-squat": {
    name: "اسکوات هالتر",
    how: "پادشاه حرکات پایین‌تنه. چهارسر، باسن و مرکز بدن.",
    tips: "نفس را قبل از پایین رفتن حبس کن (بریس). زانو در جهت پنجه.",
  },
};

export function exerciseOverride(exerciseId: string, gender: Gender = readGender()): GenderExerciseOverride {
  const base = gender === "female" ? FEMALE_EXERCISE_OVERRIDES[exerciseId] : MALE_EXERCISE_OVERRIDES[exerciseId];
  const image = gender === "female" ? FEMALE_EXERCISE_MEDIA[exerciseId] : undefined;
  return { ...base, image };
}

/** تصویر پیش‌فرض جنسیتی برای زمانی که رسانه‌ای برای حرکت تعریف نشده است */
export const GENDER_FALLBACK_IMAGE: Record<Gender, string> = {
  female: femaleSquat,
  male: maleSquat,
};

export const GENDER_INTRO_IMAGE: Record<Gender, string> = {
  female: femaleLunge,
  male: maleCurl,
};
