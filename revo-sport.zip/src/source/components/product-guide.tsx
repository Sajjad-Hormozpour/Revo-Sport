import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ArrowLeft, ArrowRight, Check, CircleHelp, Compass, X } from "lucide-react";
import { useLang } from "../lib/i18n";
import { placeGuidePanel, readGuideProgress, saveGuideProgress, type GuideRect } from "../lib/guide-state";
import { getGuideSpec, type GuideRole, type GuideSpec, type GuideStep } from "./guide-content";
import "./product-guide.css";

const REPLAY_EVENT = "revo:guide:replay";

function guideRoot(role: GuideRole): HTMLElement | null {
  return document.querySelector<HTMLElement>(`[data-guide-scope="${role}"]`);
}

function pageIn(root: HTMLElement, fallback: string): string {
  return root.querySelector<HTMLElement>("[data-guide-page]")?.dataset.guidePage || fallback;
}

// Hidden mobile drawers and disabled services must never become spotlight targets.
function findTarget(root: HTMLElement, selector?: string): HTMLElement | null {
  if (!selector) return null;
  for (const element of root.querySelectorAll<HTMLElement>(selector)) {
    const box = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    if (box.width < 2 || box.height < 2 || style.display === "none" || style.visibility === "hidden") continue;
    if (box.right < 8 || box.left > window.innerWidth - 8 || element.closest('[aria-hidden="true"]')) continue;
    if (box.height > (window.visualViewport?.height ?? window.innerHeight) * 0.42) {
      const detail = element.querySelector<HTMLElement>("[data-guide-detail]");
      if (detail && detail.getBoundingClientRect().height > 0) return detail;
    }
    return element;
  }
  return null;
}

function revealTarget(element: HTMLElement | null): void {
  if (!element) return;
  let parent = element.parentElement;
  while (parent && parent !== document.body) {
    if (/auto|scroll/.test(getComputedStyle(parent).overflowY) && parent.scrollHeight > parent.clientHeight + 1) {
      const target = element.getBoundingClientRect();
      const bounds = parent.getBoundingClientRect();
      if (target.top < bounds.top + 12 || target.bottom > bounds.bottom - 12) {
        // Native scrollIntoView can ignore descendants of an inert app on resize.
        const delta = target.height > parent.clientHeight - 24
          ? target.top - bounds.top - 12
          : target.bottom - bounds.bottom + 12;
        parent.scrollTop = Math.max(0, Math.min(parent.scrollHeight - parent.clientHeight, parent.scrollTop + delta));
      }
    }
    parent = parent.parentElement;
  }
}

function viewportBox() {
  const v = window.visualViewport;
  return {
    left: v?.offsetLeft ?? 0,
    top: v?.offsetTop ?? 0,
    width: v?.width ?? window.innerWidth,
    height: v?.height ?? window.innerHeight,
  };
}

function visibleRect(element: HTMLElement): GuideRect | null {
  const box = element.getBoundingClientRect();
  const viewport = viewportBox();
  let left = Math.max(viewport.left + 8, box.left - 7);
  let top = Math.max(viewport.top + 8, box.top - 7);
  let right = Math.min(viewport.left + viewport.width - 8, box.right + 7);
  let bottom = Math.min(viewport.top + viewport.height - 8, box.bottom + 7);
  let parent = element.parentElement;
  while (parent && parent !== document.body) {
    const style = getComputedStyle(parent);
    const bounds = parent.getBoundingClientRect();
    if (/auto|scroll|hidden|clip/.test(style.overflowY)) {
      top = Math.max(top, bounds.top);
      bottom = Math.min(bottom, bounds.bottom);
    }
    if (/auto|scroll|hidden|clip/.test(style.overflowX)) {
      left = Math.max(left, bounds.left);
      right = Math.min(right, bounds.right);
    }
    parent = parent.parentElement;
  }
  if (right - left < 6 || bottom - top < 6) return null;
  return { left, top, width: right - left, height: bottom - top };
}

export function GuideHelpButton({ role }: { role: GuideRole }) {
  const { lang } = useLang();
  const label = lang === "fa" ? "راهنمای این بخش" : "Guide to this section";
  return (
    <button
      type="button"
      data-guide="guide-help"
      className="revo-guide-help"
      aria-label={label}
      title={label}
      onClick={() => window.dispatchEvent(new CustomEvent(REPLAY_EVENT, { detail: { role } }))}
    >
      <CircleHelp size={18} strokeWidth={1.8} />
    </button>
  );
}

interface GuideRun {
  owner: string;
  page: string;
  spec: GuideSpec;
  steps: GuideStep[];
  index: number;
}

export function ProductGuide({
  role, userId, section, enabled = true,
}: {
  role: GuideRole;
  userId: string;
  section: string;
  enabled?: boolean;
}) {
  const [page, setPage] = useState(section);
  const [run, setRun] = useState<GuideRun | null>(null);
  const currentRun = useRef(run);
  currentRun.current = run;
  const owner = `${role}:${userId}`;

  // Internal tabs and the first real workout have their own first-visit guides.
  useLayoutEffect(() => {
    const root = guideRoot(role);
    if (!root || !enabled) return;
    const sync = () => {
      const next = pageIn(root, section);
      setPage((previous) => previous === next ? previous : next);
    };
    sync();
    const observer = new MutationObserver(sync);
    observer.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ["data-guide-page"] });
    return () => observer.disconnect();
  }, [role, section, enabled]);

  const start = useCallback((replay = false): boolean => {
    const root = guideRoot(role);
    if (!root || !enabled || !userId) return true;
    const currentPage = pageIn(root, section);
    if (!replay && currentRun.current?.owner === owner && currentRun.current.page === currentPage) return true;
    const spec = getGuideSpec(role, currentPage);
    const progress = readGuideProgress(role, userId)[spec.id];
    if (!replay && progress && progress.status !== "in-progress") return true;

    // Do not interrupt typing, a payment dialog, a rest timer, or hidden tabs.
    const typing = document.activeElement?.matches("input, textarea, select, [contenteditable='true']");
    if (document.visibilityState === "hidden" || typing || document.querySelector("[data-workout-overlay]") || root.querySelector(".overlay-in.fixed, [aria-modal='true']")) return false;

    const steps = spec.steps.filter((item) => !item.optional || findTarget(root, item.target));
    if (!steps.length) return true;
    const resumeIndex = replay ? 0 : Math.max(0, steps.findIndex((item) => item.id === progress?.step));
    setRun({ owner, page: currentPage, spec, steps, index: resumeIndex });
    return true;
  }, [enabled, owner, role, section, userId]);

  useEffect(() => {
    setRun((current) => current?.owner === owner && current.page === page && enabled ? current : null);
    if (!enabled || !userId) return;
    let timer = 0;
    const tryStart = () => {
      if (!start()) timer = window.setTimeout(tryStart, 800);
    };
    timer = window.setTimeout(tryStart, 950);
    return () => window.clearTimeout(timer);
  }, [enabled, owner, page, start, userId]);

  useEffect(() => {
    const replay = (event: Event) => {
      if ((event as CustomEvent<{ role?: GuideRole }>).detail?.role === role) start(true);
    };
    window.addEventListener(REPLAY_EVENT, replay);
    return () => window.removeEventListener(REPLAY_EVENT, replay);
  }, [role, start]);

  const persist = (status: "in-progress" | "completed" | "skipped", index: number) => {
    if (!run) return;
    saveGuideProgress(role, userId, run.spec.id, {
      status, step: run.steps[index]?.id ?? "", updatedAt: new Date().toISOString(),
    });
  };

  const close = (completed: boolean) => {
    if (!run) return;
    persist(completed ? "completed" : "skipped", run.index);
    setRun(null);
  };

  const move = (direction: -1 | 1) => {
    if (!run) return;
    const next = run.index + direction;
    if (next >= run.steps.length) return close(true);
    if (next < 0) return;
    persist("in-progress", next);
    setRun({ ...run, index: next });
  };

  const root = guideRoot(role);
  if (!root || !run || run.owner !== owner || run.page !== page || !enabled) return null;
  return createPortal(
    <GuideOverlay
      key={`${owner}:${run.spec.id}`}
      root={root}
      run={run}
      role={role}
      onPrevious={() => move(-1)}
      onNext={() => move(1)}
      onDismiss={() => close(false)}
    />,
    document.body,
  );
}

function GuideOverlay({
  root, run, role, onPrevious, onNext, onDismiss,
}: {
  root: HTMLElement;
  run: GuideRun;
  role: GuideRole;
  onPrevious: () => void;
  onNext: () => void;
  onDismiss: () => void;
}) {
  const { lang, dir } = useLang();
  const panelRef = useRef<HTMLElement>(null);
  const nextRef = useRef<HTMLButtonElement>(null);
  const returnFocus = useRef(document.activeElement instanceof HTMLElement ? document.activeElement : null);
  const id = useId().replace(/:/g, "");
  const step = run.steps[run.index];
  const isLast = run.index === run.steps.length - 1;
  const [layout, setLayout] = useState<{
    rect: GuideRect | null;
    position: ReturnType<typeof placeGuidePanel>;
    viewport: ReturnType<typeof viewportBox>;
  } | null>(null);
  const callbacks = useRef({ onPrevious, onNext, onDismiss });
  callbacks.current = { onPrevious, onNext, onDismiss };
  const indexRef = useRef(run.index);
  indexRef.current = run.index;
  const tx = (fa: string, en: string) => lang === "fa" ? fa : en;

  useLayoutEffect(() => {
    const target = findTarget(root, step.target);
    revealTarget(target);
    let frame = 0;
    const measure = () => {
      const viewport = viewportBox();
      const currentTarget = findTarget(root, step.target);
      revealTarget(currentTarget);
      const rect = currentTarget ? visibleRect(currentTarget) : null;
      const panel = panelRef.current;
      if (!panel) return;
      const size = { width: panel.offsetWidth, height: panel.offsetHeight };
      const position = placeGuidePanel(rect, viewport, size);
      setLayout((previous) => {
        const next = { rect, position, viewport };
        return JSON.stringify(previous) === JSON.stringify(next) ? previous : next;
      });
    };
    const schedule = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(measure);
    };
    const reflow = () => {
      schedule();
    };
    measure();
    schedule();
    const resize = typeof ResizeObserver !== "undefined" ? new ResizeObserver(schedule) : null;
    if (target) resize?.observe(target);
    if (panelRef.current) resize?.observe(panelRef.current);
    window.addEventListener("resize", reflow);
    window.addEventListener("scroll", schedule, true);
    window.visualViewport?.addEventListener("resize", reflow);
    window.visualViewport?.addEventListener("scroll", schedule);
    nextRef.current?.focus({ preventScroll: true });
    return () => {
      cancelAnimationFrame(frame);
      resize?.disconnect();
      window.removeEventListener("resize", reflow);
      window.removeEventListener("scroll", schedule, true);
      window.visualViewport?.removeEventListener("resize", reflow);
      window.visualViewport?.removeEventListener("scroll", schedule);
    };
  }, [root, step]);

  useEffect(() => {
    const previousFocus = returnFocus.current;
    const wasInert = root.inert;
    root.inert = true;
    const keydown = (event: KeyboardEvent) => {
      if (event.repeat && event.key !== "Tab") return;
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopImmediatePropagation();
        callbacks.current.onDismiss();
      } else if (event.key === "Tab") {
        const buttons = [...(panelRef.current?.querySelectorAll<HTMLButtonElement>("button:not(:disabled)") ?? [])];
        if (!buttons.length) return;
        const current = buttons.indexOf(document.activeElement as HTMLButtonElement);
        const next = event.shiftKey ? (current <= 0 ? buttons.length - 1 : current - 1) : (current + 1) % buttons.length;
        event.preventDefault();
        buttons[next]?.focus({ preventScroll: true });
      } else if (event.key === (dir === "rtl" ? "ArrowLeft" : "ArrowRight")) {
        event.preventDefault();
        callbacks.current.onNext();
      } else if (event.key === (dir === "rtl" ? "ArrowRight" : "ArrowLeft") && indexRef.current > 0) {
        event.preventDefault();
        callbacks.current.onPrevious();
      }
    };
    const focusin = (event: FocusEvent) => {
      if (!panelRef.current?.contains(event.target as Node)) nextRef.current?.focus({ preventScroll: true });
    };
    const scrollGuard = (event: Event) => {
      if (!panelRef.current?.contains(event.target as Node)) event.preventDefault();
    };
    document.addEventListener("keydown", keydown, true);
    document.addEventListener("focusin", focusin);
    document.addEventListener("wheel", scrollGuard, { passive: false });
    document.addEventListener("touchmove", scrollGuard, { passive: false });
    nextRef.current?.focus({ preventScroll: true });
    return () => {
      root.inert = wasInert;
      document.removeEventListener("keydown", keydown, true);
      document.removeEventListener("focusin", focusin);
      document.removeEventListener("wheel", scrollGuard);
      document.removeEventListener("touchmove", scrollGuard);
      if (previousFocus?.isConnected && !previousFocus.closest("[inert]")) previousFocus.focus({ preventScroll: true });
    };
  }, [dir, root]);

  const rect = layout?.rect;
  return (
    <div className="revo-guide-layer" dir={dir} data-testid="product-guide">
      <svg className="revo-guide-dimmer" aria-hidden="true" width="100%" height="100%">
        <defs>
          <mask id={`${id}-spotlight`}>
            <rect width="100%" height="100%" fill="white" />
            {rect && <rect x={rect.left} y={rect.top} width={rect.width} height={rect.height} rx="22" fill="black" />}
          </mask>
        </defs>
        <rect width="100%" height="100%" fill="rgba(4,7,10,0.82)" mask={`url(#${id}-spotlight)`} />
      </svg>
      {rect && (
        <div
          aria-hidden="true"
          className="revo-guide-spotlight"
          style={{ left: rect.left, top: rect.top, width: rect.width, height: rect.height }}
        />
      )}
      <section
        ref={panelRef}
        className="revo-guide-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby={`${id}-title`}
        aria-describedby={`${id}-body`}
        style={{
          left: layout?.position.left ?? 16,
          top: layout?.position.top ?? 16,
          width: layout ? Math.min(420, layout.viewport.width - 32) : undefined,
          visibility: layout ? "visible" : "hidden",
          maxHeight: Math.max(140, (layout?.viewport.height ?? window.innerHeight) - 32),
        }}
      >
        <div className="revo-guide-kicker">
          <span className="revo-guide-symbol"><Compass size={17} strokeWidth={1.8} /></span>
          <span>{run.spec.label[lang]}</span>
          <span className="revo-guide-role">{role === "coach" ? tx("مربی", "Coach") : tx("شاگرد", "Athlete")}</span>
        </div>
        <button className="revo-guide-close" type="button" onClick={onDismiss} aria-label={tx("بستن راهنما", "Close guide")}>
          <X size={21} strokeWidth={1.7} />
        </button>
        <div className="revo-guide-copy" key={step.id} aria-live="polite" aria-atomic="true">
          <h2 id={`${id}-title`}>{step.title[lang]}</h2>
          <p id={`${id}-body`}>{step.body[lang]}</p>
        </div>
        <div className="revo-guide-footer">
          <div className="revo-guide-progress" aria-label={tx(`مرحله ${run.index + 1} از ${run.steps.length}`, `Step ${run.index + 1} of ${run.steps.length}`)}>
            <span className="revo-guide-dots" aria-hidden="true">
              {run.steps.map((item, i) => <i key={item.id} className={i === run.index ? "is-current" : i < run.index ? "is-done" : ""} />)}
            </span>
            <span>{(run.index + 1).toLocaleString(lang === "fa" ? "fa-IR" : "en-US")} / {run.steps.length.toLocaleString(lang === "fa" ? "fa-IR" : "en-US")}</span>
          </div>
          <div className="revo-guide-actions">
            {run.index > 0 && <button type="button" className="revo-guide-previous" onClick={onPrevious}>{tx("قبلی", "Back")}</button>}
            <button type="button" className="revo-guide-skip" onClick={onDismiss}>{tx("رد کردن", "Skip")}</button>
            <button type="button" className="revo-guide-next" ref={nextRef} onClick={onNext}>
              {isLast ? tx("بزن بریم", "Let's go") : tx("بعدی", "Next")}
              {isLast ? <Check size={16} strokeWidth={2.6} /> : dir === "rtl" ? <ArrowLeft size={16} /> : <ArrowRight size={16} />}
            </button>
          </div>
        </div>
        <p className="revo-guide-hint">{tx("از علامت سؤال بالای صفحه، دوباره راهنما را ببین.", "Replay this guide with the question mark at the top of the page.")}</p>
      </section>
    </div>
  );
}