import { currentLanguage, localize, localizeStatic } from "../../i18n";
import { useMemo, useState } from "react";
import {
  CalendarDays, Check, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight,
  Clock, Flame, ListFilter, RotateCcw, Search, Sparkles, Trophy, X, Zap,
} from "lucide-react";
import type { AppData, WorkoutLog, WorkoutProgram } from "../data/types";
import { fa } from "../lib/core";
import {
  JMONTHS, WEEK_S, dayKey, formatDateTime, formatTime, fromJalali,
  jalaliMonthLength, parseDate, toJalali, weekdayIdx, weekdayName,
} from "../lib/time";
import { workoutStreak } from "../lib/metrics";
import { trainingAnalytics } from "../lib/training";
import { ExThumb, resolveExercise } from "./exercise";

/** تبدیل به ارقام فارسی برای نمایش اصیل تقویم شمسی */
function toFaDigits(v: number | string): string {
  const s = String(v);
  if (currentLanguage() === "en") return fa(s);
  return fa(s).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);
}

const EN_JMONTHS = [
  "Farvardin", "Ordibehesht", "Khordad", "Tir", "Mordad", "Shahrivar",
  "Mehr", "Aban", "Azar", "Dey", "Bahman", "Esfand",
];
const EN_WEEK_S = ["Sa", "Su", "Mo", "Tu", "We", "Th", "Fr"];

interface LogSummary {
  log: WorkoutLog;
  isProgram: boolean;
  sessionTitle: string;
  programName: string;
  doneSets: number;
  allSets: number;
  totalReps: number;
  volumeKg: number;
  muscles: string[];
}

function summarizeLog(log: WorkoutLog, data: AppData): LogSummary {
  const prog = data.programs.find((p) => p.id === log.programId);
  const day = prog?.days.find((d) => d.id === log.dayId);
  const isProgram = Boolean(log.programId && prog);

  let doneSets = 0;
  let allSets = 0;
  let totalReps = 0;
  let volumeKg = 0;
  const muscleSet = new Set<string>();

  for (const item of log.items) {
    const ex = resolveExercise(item.exerciseId, data);
    if (ex.muscle) muscleSet.add(ex.muscle);
    for (const s of item.sets) {
      allSets++;
      if (s.done) {
        doneSets++;
        totalReps += s.reps || 0;
        volumeKg += (s.weight || 0) * (s.reps || 0);
      }
    }
  }

  const sessionTitle = day
    ? `${day.focus}`
    : isProgram
      ? prog!.name
      : "تمرین آزاد";

  return {
    log,
    isProgram,
    sessionTitle,
    programName: prog?.name ?? "",
    doneSets,
    allSets,
    totalReps,
    volumeKg: Math.round(volumeKg),
    muscles: [...muscleSet],
  };
}

function logDayKey(log: WorkoutLog): string {
  if (log.date && /^\d{4}-\d{2}-\d{2}$/.test(log.date)) return log.date;
  const parsed = parseDate(log.at || log.date);
  return parsed ? dayKey(parsed) : "";
}

export function StudentWorkoutHistory({
  stId,
  data,
  onGoWorkout,
}: {
  stId: string;
  data: AppData;
  onGoWorkout?: () => void;
}) {
  const today = useMemo(() => new Date(), []);
  const todayKeyStr = useMemo(() => dayKey(today), [today]);
  const todayJalali = useMemo(() => toJalali(today), [today]);

  const [mode, setMode] = useState<"calendar" | "list">("calendar");
  const [jy, setJy] = useState(todayJalali.jy);
  const [jm, setJm] = useState(todayJalali.jm);
  const [selectedKey, setSelectedKey] = useState<string>(todayKeyStr);
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  // List filters
  const [listQuery, setListQuery] = useState("");
  const [listFilter, setListFilter] = useState<"all" | "program" | "free">("all");

  // All student logs sorted newest first
  const allSummaries = useMemo(() => {
    const raw = data.logs
      .filter((l) => l.studentId === stId)
      .sort((a, b) => (b.at || b.date || "").localeCompare(a.at || a.date || ""));
    return raw.map((l) => summarizeLog(l, data));
  }, [data, stId]);

  // Group logs by YYYY-MM-DD
  const logsByDay = useMemo(() => {
    const map = new Map<string, LogSummary[]>();
    for (const item of allSummaries) {
      const k = logDayKey(item.log);
      if (!k) continue;
      const arr = map.get(k);
      if (arr) arr.push(item);
      else map.set(k, [item]);
    }
    return map;
  }, [allSummaries]);

  // Active student program for showing scheduled weekdays subtly
  const activeProgram: WorkoutProgram | undefined = useMemo(() => {
    const progs = data.programs.filter((p) => p.studentId === stId);
    return progs.find((p) => p.status === "فعال") ?? progs[0];
  }, [data.programs, stId]);

  const scheduledWeekdays = useMemo(() => {
    const set = new Set<string>();
    activeProgram?.days.forEach((d) => {
      if (d.items.length > 0) set.add(d.weekday);
    });
    return set;
  }, [activeProgram]);

  // Personal records & streak
  const analytics = useMemo(() => trainingAnalytics(data, stId), [data, stId]);
  const streak = useMemo(() => workoutStreak(data, stId), [data, stId]);

  // PR lookup by exerciseId + weight for highlighting PR sets
  const prSet = useMemo(() => {
    const set = new Set<string>();
    for (const r of analytics.records) {
      set.add(`${r.exerciseId}:${r.weight}`);
    }
    return set;
  }, [analytics.records]);

  // Build current Jalali month cells
  const monthDays = useMemo(() => {
    const len = jalaliMonthLength(jy, jm);
    const firstDate = fromJalali(jy, jm, 1);
    const startOffset = weekdayIdx(firstDate); // 0 = شنبه ... 6 = جمعه

    const days: {
      jd: number;
      date: Date;
      key: string;
      weekday: string;
      logs: LogSummary[];
      hasProgramLog: boolean;
      hasFreeLog: boolean;
      isToday: boolean;
      isFuture: boolean;
      isScheduled: boolean;
      totalVolume: number;
    }[] = [];

    for (let d = 1; d <= len; d++) {
      const gDate = fromJalali(jy, jm, d);
      const k = dayKey(gDate);
      const dayLogs = logsByDay.get(k) ?? [];
      const wName = weekdayName(gDate);
      const isFuture = k > todayKeyStr;
      days.push({
        jd: d,
        date: gDate,
        key: k,
        weekday: wName,
        logs: dayLogs,
        hasProgramLog: dayLogs.some((x) => x.isProgram),
        hasFreeLog: dayLogs.some((x) => !x.isProgram),
        isToday: k === todayKeyStr,
        isFuture,
        isScheduled: scheduledWeekdays.has(wName),
        totalVolume: dayLogs.reduce((s, x) => s + x.volumeKg, 0),
      });
    }

    return { startOffset, days, len };
  }, [jy, jm, logsByDay, todayKeyStr, scheduledWeekdays]);

  // Month stats ("ماه در یک نگاه")
  const monthStats = useMemo(() => {
    let sessions = 0;
    let activeDays = 0;
    let minutes = 0;
    let sets = 0;
    let volume = 0;
    const muscleFreq = new Map<string, number>();

    for (const cell of monthDays.days) {
      if (cell.logs.length > 0) activeDays++;
      for (const s of cell.logs) {
        sessions++;
        minutes += s.log.durationMin || 0;
        sets += s.doneSets;
        volume += s.volumeKg;
        for (const m of s.muscles) {
          muscleFreq.set(m, (muscleFreq.get(m) ?? 0) + 1);
        }
      }
    }

    const topMuscles = [...muscleFreq.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 4);

    // Weekly consistency bars (up to 5 weeks in month)
    const weeklyCounts: number[] = [];
    for (let i = 0; i < monthDays.days.length; i += 7) {
      const slice = monthDays.days.slice(i, i + 7);
      weeklyCounts.push(slice.reduce((acc, c) => acc + c.logs.length, 0));
    }

    return { sessions, activeDays, minutes, sets, volume, topMuscles, weeklyCounts };
  }, [monthDays.days]);

  // Selected day details
  const selectedCell = useMemo(() => {
    const inMonth = monthDays.days.find((c) => c.key === selectedKey);
    if (inMonth) return inMonth;
    const parsed = parseDate(selectedKey);
    if (!parsed) return null;
    const j = toJalali(parsed);
    const dayLogs = logsByDay.get(selectedKey) ?? [];
    const wName = weekdayName(parsed);
    return {
      jd: j.jd,
      date: parsed,
      key: selectedKey,
      weekday: wName,
      logs: dayLogs,
      hasProgramLog: dayLogs.some((x) => x.isProgram),
      hasFreeLog: dayLogs.some((x) => !x.isProgram),
      isToday: selectedKey === todayKeyStr,
      isFuture: selectedKey > todayKeyStr,
      isScheduled: scheduledWeekdays.has(wName),
      totalVolume: dayLogs.reduce((s, x) => s + x.volumeKg, 0),
    };
  }, [monthDays.days, selectedKey, logsByDay, todayKeyStr, scheduledWeekdays]);

  const selectedJalali = useMemo(
    () => (selectedCell ? toJalali(selectedCell.date) : todayJalali),
    [selectedCell, todayJalali],
  );

  const scheduledDayPlan = useMemo(() => {
    if (!selectedCell || !activeProgram) return null;
    return activeProgram.days.find((d) => d.weekday === selectedCell.weekday) ?? null;
  }, [selectedCell, activeProgram]);

  // Month navigation
  const isCurrentMonth = jy === todayJalali.jy && jm === todayJalali.jm;

  const goPrevMonth = () => {
    let nextM = jm - 1;
    let nextY = jy;
    if (nextM < 1) {
      nextM = 12;
      nextY -= 1;
    }
    setJy(nextY);
    setJm(nextM);
    const first = fromJalali(nextY, nextM, 1);
    setSelectedKey(dayKey(first));
  };

  const goNextMonth = () => {
    let nextM = jm + 1;
    let nextY = jy;
    if (nextM > 12) {
      nextM = 1;
      nextY += 1;
    }
    setJy(nextY);
    setJm(nextM);
    if (nextY === todayJalali.jy && nextM === todayJalali.jm) {
      setSelectedKey(todayKeyStr);
    } else {
      setSelectedKey(dayKey(fromJalali(nextY, nextM, 1)));
    }
  };

  const jumpToToday = () => {
    setJy(todayJalali.jy);
    setJm(todayJalali.jm);
    setSelectedKey(todayKeyStr);
  };

  // Filtered list for "فهرست" mode
  const filteredList = useMemo(() => {
    const q = listQuery.trim().toLowerCase();
    return allSummaries.filter((item) => {
      if (listFilter === "program" && !item.isProgram) return false;
      if (listFilter === "free" && item.isProgram) return false;
      if (!q) return true;
      const exNames = item.log.items
        .map((i) => resolveExercise(i.exerciseId, data).name.toLowerCase())
        .join(" ");
      return (
        item.sessionTitle.toLowerCase().includes(q) ||
        item.programName.toLowerCase().includes(q) ||
        item.muscles.join(" ").toLowerCase().includes(q) ||
        exNames.includes(q)
      );
    });
  }, [allSummaries, listFilter, listQuery, data]);

  const monthName = currentLanguage() === "en" ? EN_JMONTHS[jm - 1] : JMONTHS[jm - 1];
  const weekHeaders = currentLanguage() === "en" ? EN_WEEK_S : WEEK_S;

  return (
    <div className="screen-in space-y-3.5 pb-5">
      {/* Top Dual Segmented Pill Switcher: فهرست | تقویم (matching reference screenshot) */}
      <div data-guide="history-tabs" className="grid grid-cols-2 gap-2.5 pt-1" role="tablist" aria-label={localizeStatic("نمای تاریخچه تمرین")}>
        <button
          type="button"
          role="tab"
          aria-selected={mode === "list"}
          onClick={() => setMode("list")}
          className={`press flex h-[48px] items-center justify-center gap-2 rounded-full border text-[14px] transition-all duration-200 ${
            mode === "list"
              ? "border-white/[0.14] bg-[#171814] font-black text-white shadow-[0_10px_28px_-14px_rgba(0,0,0,0.9)]"
              : "border-white/[0.07] bg-[#101110] font-bold text-[#8b94a3] hover:border-white/[0.12] hover:text-white/80"
          }`}
        >
          {localizeStatic("فهرست")}
          {allSummaries.length > 0 && (
            <span className={`rounded-full px-2 py-0.5 text-[10.5px] font-black ${mode === "list" ? "bg-[#c9f31c]/15 text-[#c9f31c]" : "bg-white/[0.06] text-[#8b94a3]"}`}>
              {toFaDigits(allSummaries.length)}
            </span>
          )}
        </button>

        <button
          type="button"
          role="tab"
          aria-selected={mode === "calendar"}
          onClick={() => setMode("calendar")}
          className={`press flex h-[48px] items-center justify-center gap-2 rounded-full border text-[14px] transition-all duration-200 ${
            mode === "calendar"
              ? "border-white/[0.14] bg-[#171814] font-black text-white shadow-[0_10px_28px_-14px_rgba(0,0,0,0.9)]"
              : "border-white/[0.07] bg-[#101110] font-bold text-[#8b94a3] hover:border-white/[0.12] hover:text-white/80"
          }`}
        >
          {localizeStatic("تقویم")}
        </button>
      </div>

      {mode === "calendar" ? (
        <>
          {/* Main Jalali Calendar Card */}
          <section data-guide="history-calendar" className="relative overflow-hidden rounded-[28px] border border-white/[0.08] bg-[#0a0b0a] px-3.5 pb-4 pt-4 shadow-[0_26px_65px_-35px_rgba(0,0,0,0.95)] sm:px-5">
            {/* Subtle ambient glow when month has workouts */}
            {monthStats.sessions > 0 && (
              <div
                className="pointer-events-none absolute -top-20 left-1/2 h-40 w-64 -translate-x-1/2 rounded-full bg-[#c9f31c]/[0.06] blur-3xl"
                aria-hidden="true"
              />
            )}

            {/* Month Navigation Header */}
            <div className="relative flex items-center justify-between px-0.5">
              {/* Previous Month Button (Right side in RTL -> points right >) */}
              <button
                type="button"
                onClick={goPrevMonth}
                aria-label={localizeStatic("ماه قبل")}
                className="press flex h-11 w-11 items-center justify-center rounded-full border border-white/[0.07] bg-[#1c1d18] text-white/85 transition hover:border-white/[0.15] hover:bg-[#232420] hover:text-white"
              >
                <ChevronRight size={19} strokeWidth={2.3} />
              </button>

              {/* Center Month + Year Title + Jump to Today */}
              <div className="flex flex-col items-center">
                <button
                  type="button"
                  onClick={jumpToToday}
                  title={localizeStatic("بازگشت به ماه جاری")}
                  className="press flex items-center gap-2 rounded-xl px-2.5 py-1 text-[18px] font-black tracking-tight text-white transition hover:bg-white/[0.04]"
                >
                  <span>{monthName}</span>
                  <span>{toFaDigits(jy)}</span>
                </button>
                {!isCurrentMonth && (
                  <button
                    type="button"
                    onClick={jumpToToday}
                    className="mt-0.5 inline-flex items-center gap-1 rounded-full bg-[#c9f31c]/15 px-2.5 py-0.5 text-[10px] font-black text-[#c9f31c] transition hover:bg-[#c9f31c]/25"
                  >
                    <RotateCcw size={10} />
                    {localizeStatic("امروز")}
                  </button>
                )}
              </div>

              {/* Next Month Button (Left side in RTL -> points left <) */}
              <button
                type="button"
                onClick={goNextMonth}
                aria-label={localizeStatic("ماه بعد")}
                className="press flex h-11 w-11 items-center justify-center rounded-full border border-white/[0.07] bg-[#1c1d18] text-white/85 transition hover:border-white/[0.15] hover:bg-[#232420] hover:text-white"
              >
                <ChevronLeft size={19} strokeWidth={2.3} />
              </button>
            </div>

            {/* Weekday Initials Row: ش ی د س چ پ ج */}
            <div className="mt-5 grid grid-cols-7 text-center">
              {weekHeaders.map((w, idx) => (
                <span
                  key={w}
                  className={`py-1 text-[12px] font-bold ${idx === 6 ? "text-[#c9f31c]" : "text-[#8b95a5]"}`}
                >
                  {w}
                </span>
              ))}
            </div>

            {/* Days Grid */}
            <div className="mt-2 grid grid-cols-7 gap-y-2 text-center">
              {Array.from({ length: monthDays.startOffset }).map((_, idx) => (
                <span key={`empty-${idx}`} aria-hidden="true" className="h-[46px]" />
              ))}

              {monthDays.days.map((cell) => {
                const isSelected = cell.key === selectedKey;
                const hasWorkout = cell.logs.length > 0;
                const multiSession = cell.logs.length > 1;
                const isFriday = cell.weekday === "جمعه" || cell.weekday === "Friday";

                return (
                  <button
                    key={cell.key}
                    type="button"
                    onClick={() => {
                      setSelectedKey(cell.key);
                      if (cell.logs[0]) setExpandedLogId(cell.logs[0].log.id);
                    }}
                    aria-label={`${toFaDigits(cell.jd)} ${monthName}`}
                    aria-pressed={isSelected}
                    className={`press relative mx-auto flex h-[50px] w-[46px] flex-col items-center justify-center rounded-[16px] transition-all duration-200 ${
                      isSelected
                        ? hasWorkout
                          ? "bg-[#c9f31c] font-black text-black shadow-[0_10px_26px_-8px_rgba(201,243,28,0.65)]"
                          : "bg-white font-black text-black shadow-[0_8px_20px_-8px_rgba(255,255,255,0.45)]"
                        : hasWorkout
                          ? "bg-[#c9f31c]/[0.14] font-extrabold text-[#d8f96a] ring-1 ring-inset ring-[#c9f31c]/25 hover:bg-[#c9f31c]/[0.22]"
                          : cell.isToday
                            ? "border border-[#c9f31c]/60 bg-[#c9f31c]/[0.08] font-black text-white"
                            : cell.isFuture
                              ? "font-medium text-[#5c6675] hover:bg-white/[0.04] hover:text-[#8e99a8]"
                              : isFriday
                                ? "font-semibold text-[#c9a35c] hover:bg-white/[0.05] hover:text-[#e0c07a]"
                                : "font-semibold text-[#9aa5b4] hover:bg-white/[0.05] hover:text-white"
                    }`}
                  >
                    <span className="text-[15px] leading-none">
                      {toFaDigits(cell.jd)}
                    </span>

                    {/* Status Dots Row */}
                    <span className="mt-1.5 flex h-[6px] items-center justify-center gap-1" aria-hidden="true">
                      {cell.hasProgramLog && (
                        <span className={`h-[6px] w-[6px] rounded-full ${isSelected ? "bg-black" : "bg-[#c9f31c] shadow-[0_0_6px_rgba(201,243,28,0.9)]"}`} />
                      )}
                      {cell.hasFreeLog && (
                        <span className={`h-[6px] w-[6px] rounded-full ${isSelected ? "bg-black/70" : "bg-white"}`} />
                      )}
                      {multiSession && (
                        <span className={`h-[5px] w-[5px] rounded-full ${isSelected ? "bg-black/50" : "bg-sky-400"}`} />
                      )}
                      {!hasWorkout && cell.isScheduled && !cell.isFuture && (
                        <span className="h-[5px] w-[5px] rounded-full border border-[#c9f31c]/50" />
                      )}
                      {!hasWorkout && cell.isScheduled && cell.isFuture && (
                        <span className="h-[5px] w-[5px] rounded-full bg-white/20" />
                      )}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Bottom Legend matching reference screenshot */}
            <div className="mt-5 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 border-t border-white/[0.06] pt-3.5 text-[11.5px] font-bold text-[#9aa5b4]">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-[#c9f31c] shadow-[0_0_8px_rgba(201,243,28,0.75)]" />
                {localizeStatic("برنامه")}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-white/90" />
                {localizeStatic("آزاد")}
              </span>
              {scheduledWeekdays.size > 0 && (
                <span className="inline-flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full border border-[#c9f31c]/55" />
                  {localizeStatic("روز تمرین")}
                </span>
              )}
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-[#c9a35c]" />
                {localizeStatic("جمعه")}
              </span>
            </div>
          </section>

          {/* Selected Day Interactive Inspection Card */}
          {selectedCell && (
            <SelectedDayDetailCard
              cell={selectedCell}
              jalali={selectedJalali}
              data={data}
              prSet={prSet}
              scheduledDayPlan={scheduledDayPlan}
              expandedLogId={expandedLogId}
              onToggleLog={(id) => setExpandedLogId((cur) => (cur === id ? null : id))}
              onGoWorkout={onGoWorkout}
            />
          )}

          {/* Monthly Overview Card: «[ماه] در یک نگاه» */}
          <section className="rounded-[26px] border border-white/[0.08] bg-[#0a0b0a] p-4 shadow-[0_20px_50px_-32px_rgba(0,0,0,0.9)] sm:p-5">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-[14px] font-black text-white">
                {monthName} {localizeStatic("در یک نگاه")}
              </h3>
              {streak > 0 && (
                <span className="inline-flex items-center gap-1 rounded-full bg-[#c9f31c]/12 px-2.5 py-1 text-[10.5px] font-black text-[#c9f31c]">
                  <Flame size={12} />
                  {toFaDigits(streak)} {localizeStatic("روز متوالی")}
                </span>
              )}
            </div>

            {monthStats.sessions === 0 ? (
              <p className="mt-2.5 text-[13.5px] font-bold text-white/90">
                {localizeStatic("این ماه تمرینی ثبت نشده است.")}
              </p>
            ) : (
              <div className="mt-3.5 space-y-3.5">
                <div className="grid grid-cols-4 gap-2 text-center">
                  <OverviewMetric
                    value={toFaDigits(monthStats.sessions)}
                    label={localizeStatic("جلسه")}
                    accent
                  />
                  <OverviewMetric
                    value={toFaDigits(monthStats.minutes)}
                    label={localizeStatic("دقیقه")}
                  />
                  <OverviewMetric
                    value={toFaDigits(monthStats.sets)}
                    label={localizeStatic("ست موفق")}
                  />
                  <OverviewMetric
                    value={
                      monthStats.volume >= 1000
                        ? `${toFaDigits((monthStats.volume / 1000).toFixed(1))}t`
                        : toFaDigits(monthStats.volume)
                    }
                    label={monthStats.volume >= 1000 ? localizeStatic("تن حجم") : localizeStatic("کیلو حجم")}
                  />
                </div>

                {/* Muscle Focus Distribution in Month */}
                {monthStats.topMuscles.length > 0 && (
                  <div className="rounded-2xl bg-[#101110] p-3">
                    <span className="block text-[10.5px] font-bold text-[#9aa5b4]">
                      {localizeStatic("عضلات کارشده در")} {monthName}
                    </span>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {monthStats.topMuscles.map(([muscle, count]) => (
                        <span
                          key={muscle}
                          className="inline-flex items-center gap-1.5 rounded-full border border-white/[0.07] bg-[#171814] px-2.5 py-1 text-[11px] font-bold text-white/90"
                        >
                          <span>{localize(muscle)}</span>
                          <span className="rounded-full bg-[#c9f31c]/15 px-1.5 py-0.2 text-[9.5px] font-black text-[#c9f31c]">
                            {toFaDigits(count)}×
                          </span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Weekly Rhythm Mini Bar Chart */}
                <div className="rounded-2xl bg-[#101110] p-3">
                  <div className="flex items-center justify-between text-[10.5px] font-bold text-[#9aa5b4]">
                    <span>{localizeStatic("ریتم هفتگی این ماه")}</span>
                    <span className="text-white/85">
                      {toFaDigits(monthStats.activeDays)} {localizeStatic("روز فعال")}
                    </span>
                  </div>
                  <div className="mt-2.5 grid grid-cols-5 gap-2">
                    {monthStats.weeklyCounts.slice(0, 5).map((cnt, idx) => {
                      const maxCnt = Math.max(3, ...monthStats.weeklyCounts);
                      const pct = Math.min(100, Math.round((cnt / maxCnt) * 100));
                      return (
                        <div key={idx} className="flex flex-col items-center gap-1">
                          <div className="flex h-10 w-full items-end overflow-hidden rounded-lg bg-white/[0.04] p-0.5">
                            <div
                              className={`w-full rounded-md transition-all duration-500 ${
                                cnt > 0 ? "bg-[#c9f31c]" : "bg-white/10"
                              }`}
                              style={{ height: `${cnt > 0 ? Math.max(22, pct) : 10}%` }}
                            />
                          </div>
                          <span className="text-[9.5px] font-bold text-[#7f8a9a]">
                            {localizeStatic("هفته")} {toFaDigits(idx + 1)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </section>

          {/* Personal Records Highlight Card (if any) */}
          {analytics.records.length > 0 && (
            <section className="rounded-[26px] border border-[#c9f31c]/25 bg-[#0a0b0a] p-4">
              <div className="flex items-center justify-between">
                <b className="flex items-center gap-1.5 text-[13px] font-black text-white">
                  <Trophy size={15} className="text-[#c9f31c]" />
                  {localizeStatic("رکوردهای شخصی ثبت‌شده")}
                </b>
                <span className="rounded-full bg-[#c9f31c]/15 px-2 py-0.5 text-[10px] font-black text-[#c9f31c]">
                  {toFaDigits(analytics.records.length)} PR
                </span>
              </div>
              <div className="mt-2.5 space-y-1.5">
                {analytics.records.slice(0, 5).map((r, i) => (
                  <div
                    key={`${r.exerciseId}-${i}`}
                    className="flex items-center justify-between gap-2 rounded-xl bg-[#101110] px-3 py-2 text-[11.5px]"
                  >
                    <span className="truncate font-bold text-white/90">
                      {localize(resolveExercise(r.exerciseId, data).name)}
                    </span>
                    <b className="shrink-0 font-black text-[#c9f31c]">
                      {toFaDigits(r.previous)} ← {toFaDigits(r.weight)} kg × {toFaDigits(r.reps)}
                    </b>
                  </div>
                ))}
              </div>
            </section>
          )}
        </>
      ) : (
        /* ================= LIST MODE («فهرست») ================= */
        <div data-guide="history-list" className="space-y-3">
          {/* Lifetime Quick Summary Strip */}
          <div className="grid grid-cols-4 gap-2">
            <OverviewMetric
              value={toFaDigits(allSummaries.length)}
              label={localizeStatic("کل جلسات")}
              accent
            />
            <OverviewMetric
              value={toFaDigits(allSummaries.reduce((a, s) => a + (s.log.durationMin || 0), 0))}
              label={localizeStatic("کل دقیقه")}
            />
            <OverviewMetric
              value={toFaDigits(streak)}
              label={localizeStatic("روز متوالی")}
            />
            <OverviewMetric
              value={toFaDigits(
                Math.round(allSummaries.reduce((a, s) => a + s.volumeKg, 0) / 1000 * 10) / 10,
              )}
              label={localizeStatic("تن حجم کل")}
            />
          </div>

          {/* Search & Type Filter Bar */}
          <div className="rounded-[22px] border border-white/[0.08] bg-[#0a0b0a] p-2.5">
            <div className="flex items-center gap-2 rounded-xl bg-[#101110] px-3 py-2">
              <Search size={15} className="shrink-0 text-[#9aa5b4]" />
              <input
                value={listQuery}
                onChange={(e) => setListQuery(e.target.value)}
                placeholder={localizeStatic("جستجو نام حرکت، عضله یا جلسه…")}
                className="min-w-0 flex-1 bg-transparent text-[12.5px] font-semibold text-white placeholder:text-[#6e7787] outline-none"
              />
              {listQuery && (
                <button
                  type="button"
                  onClick={() => setListQuery("")}
                  aria-label={localizeStatic("پاک کردن")}
                  className="text-[#7f8a9a] hover:text-white"
                >
                  <X size={14} />
                </button>
              )}
            </div>

            <div className="mt-2 flex items-center gap-1.5">
              <ListFilter size={13} className="mr-1 text-[#9aa5b4]" />
              {(
                [
                  { id: "all", label: "همه جلسات" },
                  { id: "program", label: "برنامه مربی" },
                  { id: "free", label: "تمرین آزاد" },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setListFilter(tab.id)}
                  className={`press rounded-full px-3 py-1 text-[11px] font-bold transition ${
                    listFilter === tab.id
                      ? "bg-[#c9f31c] font-black text-black"
                      : "bg-[#101110] text-[#8b95a5] hover:text-white"
                  }`}
                >
                  {localizeStatic(tab.label)}
                </button>
              ))}
            </div>
          </div>

          {filteredList.length === 0 ? (
            <div className="rounded-[26px] border border-dashed border-white/[0.1] bg-[#0a0b0a]/60 py-12 text-center">
              <CalendarDays size={26} className="mx-auto text-[#9aa5b4]" />
              <b className="mt-2.5 block text-[13.5px] text-white">
                {allSummaries.length === 0
                  ? localizeStatic("هنوز تمرینی ثبت نشده است")
                  : localizeStatic("جلسه‌ای با این جستجو پیدا نشد")}
              </b>
              <p className="mt-1 text-[11.5px] text-[#9aa5b4]">
                {allSummaries.length === 0
                  ? localizeStatic("پس از پایان هر جلسه، جزئیات کامل حرکات و وزنه‌هایت اینجا ذخیره می‌شود.")
                  : localizeStatic("عبارت دیگری را امتحان کن یا فیلتر را تغییر بده.")}
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredList.map((summary) => (
                <WorkoutLogDetailCard
                  key={summary.log.id}
                  summary={summary}
                  data={data}
                  prSet={prSet}
                  showFullDate
                  open={expandedLogId === summary.log.id}
                  onToggle={() =>
                    setExpandedLogId((cur) => (cur === summary.log.id ? null : summary.log.id))
                  }
                  onJumpToCalendar={() => {
                    const parsed = parseDate(summary.log.at || summary.log.date);
                    if (parsed) {
                      const j = toJalali(parsed);
                      setJy(j.jy);
                      setJm(j.jm);
                      setSelectedKey(dayKey(parsed));
                      setExpandedLogId(summary.log.id);
                      setMode("calendar");
                    }
                  }}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Selected Day Inspection Panel                                       */
/* ------------------------------------------------------------------ */

function SelectedDayDetailCard({
  cell,
  jalali,
  data,
  prSet,
  scheduledDayPlan,
  expandedLogId,
  onToggleLog,
  onGoWorkout,
}: {
  cell: {
    jd: number;
    date: Date;
    key: string;
    weekday: string;
    logs: LogSummary[];
    isToday: boolean;
    isFuture: boolean;
    isScheduled: boolean;
    totalVolume: number;
  };
  jalali: { jy: number; jm: number; jd: number };
  data: AppData;
  prSet: Set<string>;
  scheduledDayPlan: { weekday: string; focus: string; items: { id: string; exerciseId: string; sets: number; reps: string; weight: string }[] } | null;
  expandedLogId: string | null;
  onToggleLog: (id: string) => void;
  onGoWorkout?: () => void;
}) {
  const mName = currentLanguage() === "en" ? EN_JMONTHS[jalali.jm - 1] : JMONTHS[jalali.jm - 1];

  return (
    <section data-guide="history-day" className="rounded-[26px] border border-white/[0.08] bg-[#0a0b0a] p-4 shadow-[0_20px_50px_-32px_rgba(0,0,0,0.9)]">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <span
            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl text-[14px] font-black ${
              cell.logs.length > 0
                ? "bg-[#c9f31c] text-black shadow-[0_8px_20px_-8px_rgba(201,243,28,0.8)]"
                : "bg-[#1c1d18] text-white/85"
            }`}
          >
            {toFaDigits(jalali.jd)}
          </span>
          <div>
            <div className="flex items-center gap-1.5">
              <b className="text-[14px] font-black text-white">
                {localize(cell.weekday)} {toFaDigits(jalali.jd)} {mName}
              </b>
              {cell.isToday && (
                <span className="rounded-full bg-[#c9f31c]/15 px-2 py-0.5 text-[9.5px] font-black text-[#c9f31c]">
                  {localizeStatic("امروز")}
                </span>
              )}
            </div>
            <span className="block text-[11px] font-semibold text-[#9aa5b4]">
              {cell.logs.length > 0
                ? `${toFaDigits(cell.logs.length)} ${localizeStatic("جلسه تمرین ثبت‌شده")} • ${toFaDigits(cell.totalVolume)} kg`
                : cell.isScheduled
                  ? localizeStatic("جلسه در برنامه هفتگی داری")
                  : localizeStatic("روز استراحت / بدون تمرین ثبت‌شده")}
            </span>
          </div>
        </div>

        {cell.isToday && cell.logs.length === 0 && onGoWorkout && (
          <button
            type="button"
            onClick={onGoWorkout}
            className="press inline-flex items-center gap-1.5 rounded-xl bg-[#c9f31c] px-3.5 py-2 text-[11.5px] font-black text-black shadow-[0_10px_24px_-10px_rgba(201,243,28,0.8)]"
          >
            <Zap size={13} fill="currentColor" />
            {localizeStatic("شروع تمرین امروز")}
          </button>
        )}
      </div>

      {/* Logged Workouts on Selected Date */}
      {cell.logs.length > 0 ? (
        <div className="mt-3.5 space-y-2.5">
          {cell.logs.map((summary, idx) => (
            <WorkoutLogDetailCard
              key={summary.log.id}
              summary={summary}
              data={data}
              prSet={prSet}
              open={expandedLogId ? expandedLogId === summary.log.id : idx === 0}
              onToggle={() => onToggleLog(summary.log.id)}
            />
          ))}
        </div>
      ) : scheduledDayPlan && scheduledDayPlan.items.length > 0 ? (
        /* Preview of scheduled exercises when not logged yet */
        <div className="mt-3.5 rounded-2xl border border-white/[0.06] bg-[#101110] p-3">
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 text-[11.5px] font-black text-[#c9f31c]">
              <Sparkles size={13} />
              {localizeStatic("برنامه")} {localize(scheduledDayPlan.weekday)}: {localize(scheduledDayPlan.focus)}
            </span>
            <span className="text-[10.5px] font-bold text-[#9aa5b4]">
              {toFaDigits(scheduledDayPlan.items.length)} {localizeStatic("حرکت")}
            </span>
          </div>
          <div className="mt-2.5 space-y-1.5">
            {scheduledDayPlan.items.slice(0, 5).map((it) => {
              const ex = resolveExercise(it.exerciseId, data);
              return (
                <div key={it.id} className="flex items-center gap-2.5 rounded-xl bg-[#171814] px-2.5 py-2">
                  <ExThumb exerciseId={it.exerciseId} data={data} className="h-8 w-8 shrink-0 rounded-lg object-cover" />
                  <span className="min-w-0 flex-1 truncate text-[12px] font-bold text-white/90">
                    {localize(ex.name)}
                  </span>
                  <span className="shrink-0 text-[11px] font-bold text-[#9aa5b4]">
                    {toFaDigits(it.sets)} × {toFaDigits(it.reps)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      ) : null}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Rich Workout Log Card (Exercises, Sets, Weights, Reps, RIR, PRs)    */
/* ------------------------------------------------------------------ */

function WorkoutLogDetailCard({
  summary,
  data,
  prSet,
  open,
  onToggle,
  showFullDate = false,
  onJumpToCalendar,
}: {
  summary: LogSummary;
  data: AppData;
  prSet: Set<string>;
  open: boolean;
  onToggle: () => void;
  showFullDate?: boolean;
  onJumpToCalendar?: () => void;
}) {
  const { log, isProgram, sessionTitle, programName, doneSets, allSets, totalReps, volumeKg, muscles } = summary;
  const timeText = log.at ? formatTime(log.at, false) : "";

  return (
    <div className="overflow-hidden rounded-[22px] border border-white/[0.08] bg-[#101110] transition-colors">
      {/* Header Row */}
      <button
        type="button"
        onClick={onToggle}
        className="press flex w-full items-center gap-3 p-3.5 text-right"
      >
        <span
          className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${
            isProgram
              ? "bg-[#c9f31c]/15 text-[#c9f31c]"
              : "bg-white/[0.08] text-white"
          }`}
        >
          <CheckCircle2 size={20} />
        </span>

        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-1.5">
            <b className="truncate text-[14px] font-black text-white">
              {localize(sessionTitle)}
            </b>
            <span
              className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[9.5px] font-black ${
                isProgram
                  ? "bg-[#c9f31c]/15 text-[#c9f31c]"
                  : "bg-white/10 text-white/85"
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${isProgram ? "bg-[#c9f31c]" : "bg-white"}`} />
              {localizeStatic(isProgram ? "برنامه" : "آزاد")}
            </span>
          </span>

          <span className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] font-semibold text-[#9aa5b4]">
            {showFullDate ? (
              <span>{localize(formatDateTime(log.at || log.date))}</span>
            ) : (
              timeText && (
                <span className="inline-flex items-center gap-1">
                  <Clock size={11} />
                  {localizeStatic("ساعت")} {toFaDigits(timeText)}
                </span>
              )
            )}
            {programName && (
              <>
                <span className="text-white/20">•</span>
                <span className="truncate text-[#9aa5b4]">{programName}</span>
              </>
            )}
          </span>

          {/* Quick Session Metrics Chips */}
          <span className="mt-2 flex flex-wrap items-center gap-1.5 text-[10.5px] font-bold">
            <span className="rounded-lg bg-[#171814] px-2 py-0.5 text-white/90">
              {toFaDigits(log.durationMin)} {localizeStatic("دقیقه")}
            </span>
            <span className="rounded-lg bg-[#171814] px-2 py-0.5 text-white/90">
              {toFaDigits(doneSets)}/{toFaDigits(allSets)} {localizeStatic("ست")}
            </span>
            <span className="rounded-lg bg-[#171814] px-2 py-0.5 text-white/90">
              {toFaDigits(totalReps)} {localizeStatic("تکرار")}
            </span>
            <span className="rounded-lg bg-[#c9f31c]/12 px-2 py-0.5 font-black text-[#c9f31c]">
              {toFaDigits(volumeKg)} kg
            </span>
          </span>
        </span>

        <ChevronDown
          size={18}
          className={`shrink-0 text-[#9aa5b4] transition-transform duration-200 ${open ? "rotate-180 text-white" : ""}`}
        />
      </button>

      {/* Expanded Exercise & Set Breakdown */}
      {open && (
        <div className="space-y-2.5 border-t border-white/[0.07] bg-[#101110] p-3">
          {/* Muscles Worked Tags + Optional Jump to Calendar */}
          {(muscles.length > 0 || onJumpToCalendar) && (
            <div className="flex flex-wrap items-center justify-between gap-2 pb-1">
              <div className="flex flex-wrap items-center gap-1">
                {muscles.map((m) => (
                  <span
                    key={m}
                    className="rounded-full bg-white/[0.06] px-2.5 py-0.5 text-[10px] font-bold text-[#b8c1cf]"
                  >
                    {localize(m)}
                  </span>
                ))}
              </div>
              {onJumpToCalendar && (
                <button
                  type="button"
                  onClick={onJumpToCalendar}
                  className="press inline-flex items-center gap-1 rounded-full bg-[#c9f31c]/12 px-2.5 py-1 text-[10.5px] font-black text-[#c9f31c] hover:bg-[#c9f31c]/20"
                >
                  <CalendarDays size={12} />
                  {localizeStatic("نمایش در تقویم")}
                </button>
              )}
            </div>
          )}

          {log.items.length === 0 ? (
            <p className="py-2 text-center text-[12px] text-[#9aa5b4]">
              {localizeStatic("جزئیات حرکت برای این جلسه ثبت نشده است.")}
            </p>
          ) : (
            log.items.map((it, idx) => {
              const ex = resolveExercise(it.exerciseId, data);
              const exDoneSets = it.sets.filter((s) => s.done);
              const bestSet = [...exDoneSets].sort((a, b) => b.weight - a.weight || b.reps - a.reps)[0];
              const exVol = exDoneSets.reduce((s, x) => s + (x.weight || 0) * (x.reps || 0), 0);
              const isPr = bestSet ? prSet.has(`${it.exerciseId}:${bestSet.weight}`) && bestSet.weight > 0 : false;

              return (
                <div
                  key={`${it.exerciseId}-${idx}`}
                  className="rounded-2xl border border-white/[0.06] bg-[#171814] p-3"
                >
                  {/* Exercise Header */}
                  <div className="flex items-center gap-2.5">
                    <ExThumb
                      exerciseId={it.exerciseId}
                      data={data}
                      className="h-11 w-11 shrink-0 rounded-xl object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <b className="truncate text-[13px] font-black text-white">
                          <span className="ml-1 text-[#9aa5b4]">{toFaDigits(idx + 1)}.</span>
                          {localize(ex.name)}
                        </b>
                        {isPr && (
                          <span className="inline-flex shrink-0 items-center gap-0.5 rounded-full bg-[#c9f31c] px-1.5 py-0.5 text-[9px] font-black text-black">
                            <Trophy size={9} />
                            PR
                          </span>
                        )}
                      </div>
                      <span className="mt-0.5 flex flex-wrap items-center gap-2 text-[10.5px] font-semibold text-[#9aa5b4]">
                        <span>{localize(ex.muscle)}</span>
                        {bestSet && (
                          <>
                            <span className="text-white/20">•</span>
                            <span className="text-white/80">
                              {localizeStatic("بهترین ست:")} {toFaDigits(bestSet.weight)} kg × {toFaDigits(bestSet.reps)}
                            </span>
                          </>
                        )}
                        {exVol > 0 && (
                          <>
                            <span className="text-white/20">•</span>
                            <span className="text-[#c9f31c]">{toFaDigits(Math.round(exVol))} kg</span>
                          </>
                        )}
                      </span>
                    </div>
                  </div>

                  {/* Set-by-Set Table */}
                  <div className="mt-2.5 rounded-xl bg-[#0c0d0c] px-2.5 py-2">
                    <div className="grid grid-cols-[32px_1fr_1fr_46px_34px] items-center gap-1 border-b border-white/[0.06] pb-1.5 text-center text-[10px] font-bold text-[#9aa5b4]">
                      <span>{localizeStatic("ست")}</span>
                      <span>{localizeStatic("وزن (kg)")}</span>
                      <span>{localizeStatic("تکرار")}</span>
                      <span>RIR</span>
                      <span>{localizeStatic("ثبت")}</span>
                    </div>

                    <div className="divide-y divide-white/[0.05]">
                      {it.sets.map((st) => {
                        const rirVal = typeof st.rpe === "number" ? Math.max(0, 10 - st.rpe) : null;
                        return (
                          <div
                            key={st.set}
                            className={`grid grid-cols-[32px_1fr_1fr_46px_34px] items-center gap-1 py-1.5 text-center text-[12px] ${
                              st.done ? "font-bold text-white" : "text-[#646e7d] line-through opacity-60"
                            }`}
                          >
                            <span className="text-[11.5px] font-black text-[#9aa5b4]">
                              {toFaDigits(st.set)}
                            </span>
                            <span>
                              {st.weight > 0 ? `${toFaDigits(st.weight)}` : localizeStatic("وزن بدن")}
                            </span>
                            <span>{toFaDigits(st.reps)}</span>
                            <span className="text-[11px] text-[#9aa5b4]">
                              {rirVal !== null ? toFaDigits(rirVal) : "—"}
                            </span>
                            <span className="flex justify-center">
                              {st.done ? (
                                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#c9f31c]/20 text-[#c9f31c]">
                                  <Check size={12} strokeWidth={3} />
                                </span>
                              ) : (
                                <span className="text-[11px] text-[#646e7d]">—</span>
                              )}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}

function OverviewMetric({
  value,
  label,
  accent = false,
}: {
  value: string;
  label: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-2xl border border-white/[0.06] bg-[#101110] px-2 py-2.5 text-center">
      <b className={`block text-[16px] font-black leading-5 ${accent ? "text-[#c9f31c]" : "text-white"}`}>
        {value}
      </b>
      <span className="mt-1 block truncate text-[10px] font-bold text-[#9aa5b4]">
        {label}
      </span>
    </div>
  );
}
