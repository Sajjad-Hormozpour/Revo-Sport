export type GuideRole = "coach" | "student";
export type GuideCopy = { fa: string; en: string };

export interface GuideStep {
  id: string;
  title: GuideCopy;
  body: GuideCopy;
  target?: string;
  optional?: boolean;
}

export interface GuideSpec {
  id: string;
  label: GuideCopy;
  steps: GuideStep[];
}

const text = (fa: string, en: string): GuideCopy => ({ fa, en });
const step = (id: string, title: GuideCopy, body: GuideCopy, target?: string, optional = false): GuideStep =>
  ({ id, title, body, target, optional });
const at = (name: string) => `[data-guide="${name}"]`;
const content = at("page-content");

const student: Record<string, GuideSpec> = {
  home: {
    id: "home", label: text("شروع همراهی با رِوو", "Your Revo introduction"), steps: [
      step("welcome", text("به فضای تمرین خودت خوش آمدی", "Welcome to your training space"), text("این راهنمای کوتاه کمک می‌کند بخش‌های پنلت را بشناسی. هر صفحه را که برای اولین بار باز کنی، همان‌جا روش استفاده‌اش را توضیح می‌دهیم؛ بدون تغییر در اطلاعاتت.", "This short tour introduces your workspace. The first time you visit a section, its guide explains the controls without changing any of your data.")),
      step("today", text("برنامهٔ امروزت اینجاست", "Your workout for today"), text("نام جلسه، تعداد حرکات و ست‌های تعیین‌شده را اینجا ببین. روی این قسمت بزن تا وارد تمرین امروز شوی. اگر برنامه‌ای نداری، ابتدا با کد مربی به او متصل شو.", "See today's session, exercises and prescribed sets here. Tap it to open today's workout. If you have no plan, connect using your coach's code first."), at("student-today")),
      step("coach", text("ارتباط با مربی", "Stay connected to your coach"), text("مربی متصل به حسابت را اینجا می‌بینی. از بخش پیام‌ها می‌توانی سؤال بپرسی؛ اگر هنوز متصل نیستی، کد مربی را در پروفایل وارد کن.", "Your connected coach appears here. Use Messages for questions, or enter a coach code in Profile if you aren't connected yet."), at("student-coach"), true),
      step("training", text("از اینجا تمرین را شروع کن", "Start training here"), text("در «تمرین»، حرکات برنامهٔ روز را مرحله‌به‌مرحله ببین، وزن و تکرار واقعی را وارد کن و هر ست انجام‌شده را تیک بزن. در پایان، جلسه را ذخیره کن.", "Workout guides you through today's exercises. Enter the weight and reps you actually performed, check completed sets, then save the session."), at("student-nav-workout")),
      step("history", text("هیچ تمرینی گم نمی‌شود", "Your workout history"), text("در «سوابق»، روزهای تمرین را روی تقویم پیدا کن و جزئیات حرکات، وزنه‌ها و تکرارهای هر جلسه را ببین. «پیشرفت» هم برای ثبت وزن، هدف‌ها و خواب توست.", "In History, select a calendar day to see its exercises, weights and reps. Progress is where you record body measurements, goals and sleep."), at("student-nav-history")),
      step("help", text("هر وقت خواستی، راهنما اینجاست", "Help is always here"), text("دکمهٔ علامت سؤال، راهنمای همین صفحه را دوباره نمایش می‌دهد. از «پیام‌ها» با مربی صحبت کن و با لمس تصویرت، پروفایل و تنظیماتت را باز کن.", "The question-mark button replays the current page's guide. Use Messages to contact your coach and tap your avatar for Profile and Settings."), at("guide-help")),
    ],
  },
  "workout-session": {
    id: "workout-session", label: text("راهنمای تمرین روزانه", "Your daily workout"), steps: [
      step("session", text("برنامهٔ امروز، در یک نگاه", "Today's session at a glance"), text("عنوان جلسه و تعداد حرکات و ست‌ها را اینجا ببین. با «شروع تمرین» وارد نمای تمام‌صفحه می‌شوی؛ اگر جلسه را نیمه‌کاره رها کنی، با «ادامهٔ تمرین» برمی‌گردی.", "See today's exercises and sets here. Start workout opens the fullscreen view. If you leave midway, Continue workout picks up where you left off."), at("workout-header")),
      step("exercise", text("آموزش و نکته‌ها، بدون شلوغی", "Guidance without the clutter"), text("برای آموزش، روی نام حرکت در این فهرست بزن. هنگام تمرین هم لمس نام حرکت در نوار پایین، نکتهٔ مربی، استراحت، RIR و دکمهٔ پایان جلسه را باز می‌کند.", "Tap an exercise name here for its guide. During training, tap the exercise name in the footer for coach notes, rest, RIR and the Finish session button."), at("exercise-heading")),
      step("sets", text("بنویس، تیک بزن، استراحت کن", "Enter, check, rest"), text("در نمای تمرین فقط وزن، تکرار و تیک هر ست را می‌بینی. نقطهٔ نارنجی ست فعال و تیک سبز ست انجام‌شده است. بعد از هر ست، استراحت باز می‌شود؛ با شماره‌های پایین بین حرکات برو و در پایان خلاصهٔ جلسه را تأیید کن.", "The workout view shows only weight, reps and a check for each set. Orange marks the active set; green means complete. Rest follows each set. Use the footer numbers to switch exercises and confirm the summary when finished."), at("workout-start")),
    ],
  },
  workout: {
    id: "workout", label: text("برنامهٔ تمرین تو", "Your workout plan"), steps: [
      step("plan", text("تمرین هر روز طبق برنامهٔ مربی", "Your coach's daily plan"), text("اینجا برنامهٔ روز، روز استراحت یا نتیجهٔ تمرین ثبت‌شده را می‌بینی. اگر هنوز برنامه نداری، از پروفایل کد مربی را وارد کن یا از پیام‌ها از او برنامه بخواه.", "This page shows today's plan, a rest day or your saved result. If you have no plan, enter a coach code in Profile or ask your coach in Messages."), content),
      step("week", text("برنامهٔ هفتگی فقط برای مشاهده است", "Preview the weekly schedule"), text("در برنامهٔ هفتگی می‌توانی حرکات روزهای دیگر را ببینی. ثبت تمرین مربوط به جلسهٔ همان روز است؛ جلسات قبلی را در «سوابق» پیدا می‌کنی.", "Preview other days in the weekly schedule. Logging is tied to the current day's session; earlier sessions are in History."), at("weekly-plan"), true),
    ],
  },
  history: {
    id: "history", label: text("سوابق و تقویم تمرین", "History and workout calendar"), steps: [
      step("views", text("تقویم یا فهرست؟ انتخاب با توست", "Calendar or list? Your choice"), text("با این دو دکمه بین نمای تقویمی و فهرست جلسه‌ها جابه‌جا شو. هر دو فقط تمرین‌های ثبت‌شدهٔ خودت را نشان می‌دهند.", "Switch between a calendar and session list. Both show only your own saved workouts."), at("history-tabs")),
      step("calendar", text("روز تمرینت را پیدا کن", "Find a training day"), text("با فلش‌ها ماه را عوض کن و روی یک روز بزن تا جزئیاتش باز شود. روزهای دارای تمرین رنگی هستند و راهنمای پایین تقویم معنی علامت‌ها را توضیح می‌دهد. لمس نام ماه تو را به امروز برمی‌گرداند.", "Use the arrows to change month and select a day for details. Training days are highlighted; the legend explains the markers. Tap the month title to return to today."), at("history-calendar"), true),
      step("details", text("جزئیات هر جلسه، نه فقط تاریخ", "See more than a date"), text("کارت جلسه را باز کن تا حرکات، ست‌های انجام‌شده، وزن، تکرار و RIR را ببینی. خلاصهٔ ماه هم تعداد جلسه، زمان و حجم تمرین را نشان می‌دهد.", "Expand a session to inspect exercises, completed sets, weights, reps and RIR. The monthly summary shows session count, time and volume."), `${at("history-day")}, ${at("history-list")}`),
    ],
  },
  progress: {
    id: "progress", label: text("پیگیری پیشرفت", "Track your progress"), steps: [
      step("overview", text("پیشرفت را با داده بسنج", "Track progress with real data"), text("سطح، امتیاز تجربه و نشان‌ها با تمرین‌های ثبت‌شده به‌روز می‌شوند. تغییراتت را منظم ثبت کن تا روندت برای خودت و مربی روشن‌تر شود.", "Your level, XP and badges update from saved workouts. Log your measurements regularly so both you and your coach can follow the trend."), at("progress-overview")),
      step("measurements", text("اندازه‌ها و هدف‌هایت را ثبت کن", "Log measurements and goals"), text("وزن و دور کمر واقعی را در فرم وارد و «ثبت» را بزن. در بخش هدف‌ها می‌توانی مقدار فعلی و هدف دلخواهت را مشخص کنی.", "Enter your actual weight and waist measurement, then save. Goals lets you set a current value and a target."), at("progress-measurements")),
      step("recovery", text("ریکاوری هم بخشی از تمرین است", "Recovery is part of training"), text("ساعت خواب و بیداری را ثبت کن. در چک‌این هفتگی هم وضعیتت را گزارش بده تا مربی برای بازبینی برنامه اطلاعات دقیق‌تری داشته باشد.", "Log your sleep and wake times. Complete the weekly check-in to give your coach useful information when reviewing your plan."), at("progress-sleep")),
    ],
  },
  chat: {
    id: "chat", label: text("گفتگو با مربی", "Talk to your coach"), steps: [
      step("messages", text("سؤال‌هایت را اینجا بپرس", "Ask your questions here"), text("پیام‌های تو و مربی در این بخش می‌مانند. سؤال دربارهٔ حرکت، برنامه یا شرایط تمرینت را واضح بنویس. برای گفتگو باید ابتدا به یک مربی متصل باشی.", "Your conversation with your coach lives here. Ask clearly about exercises, your plan or how you feel. Connect to a coach first to start chatting."), content),
      step("compose", text("نوشتن و ارسال پیام", "Write and send a message"), text("پیامت را در کادر بنویس و دکمهٔ ارسال را بزن. تنظیمات ارسال با کلید Enter را می‌توانی از تنظیمات شخصی خودت تغییر بدهی.", "Write in the message box and press Send. You can change the Enter-to-send preference in your personal settings."), at("chat-composer"), true),
    ],
  },
  nutrition: {
    id: "nutrition", label: text("راهنمای تغذیه", "Your nutrition guide"), steps: [
      step("plan", text("برنامهٔ غذایی مربی", "Your coach's meal plan"), text("برنامهٔ غذایی فعال، کالری و درشت‌مغذی‌ها را اینجا ببین. برای دیدن برنامه باید مربی این خدمت را برای تو فعال کرده باشد؛ نمایش راهنما به معنی فعال‌شدن خدمت نیست.", "View your active meal plan, calories and macros here. Your coach must enable this service for you; the guide does not activate a nutrition service."), content),
      step("meals", text("وعده‌های خورده‌شده را علامت بزن", "Mark meals you've eaten"), text("بعد از مصرف هر وعده، انجام‌شدن آن را ثبت کن. مقدار غذا، جایگزین‌ها و توصیه‌های مربی را قبل از تغییر وعده بخوان؛ مصرف آب هم در همین صفحه پیگیری می‌شود.", "Mark each meal after eating it. Read portions, alternatives and your coach's guidance before making a swap. Water tracking is on this page too."), at("nutrition-meals"), true),
    ],
  },
  subscription: {
    id: "subscription", label: text("اشتراک و خدمات", "Your subscription"), steps: [
      step("subscription", text("جزئیات اشتراکت را ببین", "Review your subscription"), text("پلن‌های مربی، وضعیت اشتراک و زمان باقی‌مانده در این قسمت نمایش داده می‌شوند. پیش از انتخاب، قیمت، تعداد جلسه و خدمات هر پلن را بخوان؛ خرید نیاز به تأیید خودت دارد.", "Review your coach's plans, subscription status and remaining time here. Read the price, session count and included services before choosing. A purchase always needs your confirmation."), content),
    ],
  },
  profile: {
    id: "profile", label: text("پروفایل و تنظیمات", "Profile and settings"), steps: [
      step("profile", text("اطلاعات دقیق، برنامهٔ دقیق‌تر", "Accurate details help your coach"), text("نام، مشخصات بدنی، هدف و محدودیت‌های ورزشی را به‌روز نگه دار و تغییرات را ذخیره کن. اگر مربی نداری، کد او را در بخش اتصال وارد کن.", "Keep your name, body details, goal and training limitations up to date, then save your changes. If you have no coach, enter their code in the connection section."), at("profile-editor")),
      step("settings", text("پنلت را مطابق نیازت تنظیم کن", "Make the workspace yours"), text("تم، زبان، اعلان‌ها و تنظیمات تمرین را در همین صفحه تغییر بده. با دکمهٔ علامت سؤال در بالای هر صفحه می‌توانی راهنمای همان بخش را دوباره ببینی.", "Adjust theme, language, notifications and training preferences here. The question mark at the top of each page reopens its guide."), at("student-settings")),
    ],
  },
};

const coach: Record<string, GuideSpec> = {
  dash: {
    id: "dash", label: text("آشنایی با پنل مربی", "Coach workspace introduction"), steps: [
      step("welcome", text("به پنل مربی رِوو خوش آمدید", "Welcome to your Revo workspace"), text("از اینجا شاگردان، برنامه‌ها، حرکات و پیگیری‌ها را مدیریت می‌کنید. راهنما روی بخش‌های واقعی صفحه حرکت می‌کند؛ هیچ اطلاعاتی را تغییر نمی‌دهد و هر زمان می‌توانید آن را رد کنید.", "Manage athletes, plans, exercises and follow-ups from here. This guide highlights real controls without changing any data. You can skip it at any time.")),
      step("invite", text("اول شاگرد را به خودتان متصل کنید", "Connect your first athlete"), text("کد دائمی مربی را کپی و برای شاگرد بفرستید تا هنگام ثبت‌نام یا در پروفایل وارد کند. از بخش شاگردان هم می‌توانید شاگرد را دستی اضافه کنید.", "Copy your permanent coach code and share it with an athlete to enter during signup or in Profile. You can also add athletes manually in Athletes."), at("coach-invite"), true),
      step("actions", text("از برنامه‌ریزی تا اجرا", "From planning to training"), text("ابتدا شاگرد را انتخاب کنید، بعد برنامهٔ تمرینی یا غذایی بسازید. در «حرکات»، کتابخانه، نقشهٔ عضلات و حرکات اختصاصی کنار هم هستند.", "Choose an athlete, then create a workout or meal plan. Moves brings the library, muscle map and your custom exercises together."), at("coach-actions")),
      step("tasks", text("هر روز چه چیزی را پیگیری کنید؟", "What needs your attention today?"), text("تمرین‌های تازه، شاگردان کم‌فعال و کارهای امروز به شما کمک می‌کنند اولویت‌ها را ببینید. بازکردن پروندهٔ هر شاگرد، جزئیات تمرین و روند او را نشان می‌دهد.", "Recent workouts, inactive athletes and today's tasks help you prioritize. Open an athlete's profile for workout details and progress."), at("coach-tasks")),
      step("navigation", text("بخش‌های پنل همیشه در دسترس‌اند", "Navigate your workspace"), text("شاگردان، برنامه‌ها، حرکات، تقویم، پیام‌ها و گزارش‌ها را از این منو باز کنید. در موبایل، دکمهٔ منو همین فهرست را باز می‌کند؛ اولین بار که هر بخش را ببینید، راهنمای خودش نمایش داده می‌شود.", "Open Athletes, Workouts, Moves, Calendar, Messages and Reports here. On mobile, the menu button opens the same list. Each section has a first-visit guide."), `${at("coach-navigation")}, ${at("coach-menu")}`),
      step("help", text("راهنمای هر صفحه، همین‌جا", "Page help, right here"), text("علامت سؤال، راهنمای صفحهٔ فعلی را از ابتدا باز می‌کند. دیدن یا ردکردن راهنما برای هر حساب، در همین مرورگر ذخیره می‌شود.", "The question mark replays the current page's guide. Completion and skipping are saved separately for each account in this browser."), at("guide-help")),
    ],
  },
  students: {
    id: "students", label: text("مدیریت شاگردان", "Manage athletes"), steps: [
      step("add", text("شاگردان متصل به حساب شما", "Athletes in your workspace"), text("از «شاگرد جدید» حساب شاگرد بسازید یا کد مربی را برای او بفرستید. هر کارت فقط اطلاعات شاگردان متصل به پنل شما را نشان می‌دهد.", "Use New athlete to create an account or share your coach code. These cards show only athletes connected to your workspace."), at("coach-students-actions")),
      step("filter", text("شاگرد موردنظر را سریع پیدا کنید", "Find the right athlete"), text("نام یا هدف را جستجو کنید و فیلتر سطح و اشتراک را تغییر بدهید. برای بررسی تمرین‌های ثبت‌شده، اندازه‌ها و وضعیت کامل، کارت شاگرد را باز کنید.", "Search a name or goal and filter by level and subscription. Open an athlete's card to review workout logs, measurements and full details."), at("coach-students-filters")),
    ],
  },
  student: {
    id: "student", label: text("پروندهٔ شاگرد", "Athlete profile"), steps: [
      step("profile", text("همهٔ اطلاعات یک شاگرد", "One athlete, all the details"), text("مشخصات، ارزیابی اولیه، برنامه‌ها و تمرین‌های ثبت‌شده را اینجا بررسی کنید. از تب‌های پرونده برای دیدن روند و جزئیات استفاده کنید و قبل از تغییر برنامه، محدودیت‌های شاگرد را بخوانید.", "Review profile details, assessments, plans and saved workouts here. Use the profile tabs to inspect progress, and read the athlete's limitations before changing a plan."), content),
    ],
  },
  programs: {
    id: "programs", label: text("طراحی برنامهٔ تمرینی", "Create workout plans"), steps: [
      step("athlete", text("اول شاگرد، بعد برنامه", "Choose an athlete first"), text("شاگرد را از این فهرست انتخاب کنید. برنامه‌ها و قالب‌های او نمایش داده می‌شوند؛ با «برنامه» یک برنامهٔ تازه بسازید و عنوان و روزها را مشخص کنید.", "Select an athlete here. Their plans and templates will appear. Use Plan to create a new plan, then set its name and training days."), at("program-athlete")),
      step("days", text("حرکات هر روز را مشخص کنید", "Build each training day"), text("برای هر روز، تمرکز جلسه را بنویسید و با «حرکت» از کتابخانه یا حرکات خودتان انتخاب کنید. روی ویرایش ست‌ها بزنید تا ست، تکرار، وزن، استراحت و یادداشت را تنظیم کنید. تغییرات برنامه خودکار ذخیره می‌شوند.", "Name each day's focus and use Exercise to choose from the library or your own moves. Edit sets to prescribe sets, reps, weight, rest and notes. Plan changes save automatically."), at("program-days"), true),
      step("templates", text("برنامهٔ خوب را دوباره استفاده کنید", "Reuse a good plan"), text("قالب‌های تمرینی برای استفادهٔ دوباره‌اند. قبل از اعمال یک قالب یا پیشنهاد، آن را برای شرایط و محدودیت‌های شاگرد بازبینی کنید.", "Templates let you reuse a plan. Review any template or suggestion for the athlete's needs and limitations before using it."), at("program-templates")),
    ],
  },
  "moves-library": {
    id: "moves-library", label: text("مرکز حرکات", "Your exercise center"), steps: [
      step("tabs", text("چهار ابزار، یک بخش", "Four tools in one place"), text("کتابخانهٔ عمومی، نقشهٔ تعاملی عضلات، حرکات اختصاصی و استودیو سه‌بعدی در این تب‌ها هستند. هر کدام روش متفاوتی برای پیدا‌کردن یا ساختن حرکت در اختیار شما می‌گذارند.", "These tabs contain the library, interactive muscle map, your custom moves and the 3D studio. Each offers a different way to find or create exercises."), at("moves-tabs")),
      step("filters", text("حرکت مناسب را پیدا کنید", "Find a suitable exercise"), text("نام فارسی یا انگلیسی را بنویسید و منبع، عضله، وسیله یا سطح را فیلتر کنید. با «نقشهٔ بدن» می‌توانید به‌جای جستجوی نام، روی عضله انتخاب کنید.", "Search in Persian or English and filter by source, muscle, equipment or level. Body map lets you choose a muscle visually instead."), at("moves-filters")),
      step("cards", text("آموزش و افزودن مستقیم به برنامه", "Inspect and assign an exercise"), text("«جزئیات» آموزش و نکات را باز می‌کند. «به شاگرد» امکان انتخاب شاگرد، برنامه، روز و تنظیم ست و تکرار را می‌دهد؛ چیزی بدون تأیید شما ارسال نمی‌شود.", "Details opens the exercise guide. To athlete lets you choose an athlete, plan, day, sets and reps. Nothing is assigned without your confirmation."), at("moves-results"), true),
    ],
  },
  "moves-muscles": {
    id: "moves-muscles", label: text("نقشهٔ عضلات", "The muscle map"), steps: [
      step("anatomy", text("از روی عضله حرکت انتخاب کنید", "Find exercises by muscle"), text("آناتومی آقایان یا بانوان را انتخاب کنید؛ روی عضله در نمای جلو یا پشت بزنید تا روشن شود و حرکات مرتبط پایین صفحه فیلتر شوند. «همهٔ عضلات» انتخاب را پاک می‌کند.", "Choose male or female anatomy, then select a front or back muscle. It highlights the group and filters exercises below. All muscles clears the selection."), at("muscle-map")),
      step("assign", text("همان حرکات، با انتخاب دقیق‌تر", "The same moves, a more precise filter"), text("فیلتر وسیله و سطح را در کنار عضله استفاده کنید. از کارت حرکت می‌توانید آموزش را ببینید یا با «به شاگرد» آن را داخل برنامهٔ او قرار دهید.", "Combine a muscle selection with equipment and level filters. Exercise cards let you review the guide or assign the move to an athlete's plan."), at("moves-filters")),
    ],
  },
  "moves-mine": {
    id: "moves-mine", label: text("حرکات اختصاصی", "Your custom moves"), steps: [
      step("create", text("روش مربیگری خودتان را ذخیره کنید", "Save your own coaching material"), text("با «حرکت جدید» نام، عضله، وسیله، توضیح و عکس یا ویدیوی خودتان را وارد کنید. پیش‌فرض ست و تکرار هم قابل تنظیم است. تا «ذخیره حرکت» را نزنید، حرکت نهایی نمی‌شود.", "Use New exercise to add a name, muscle, equipment, instructions and your own photo or video. Set prescription defaults, then choose Save exercise to finish."), at("moves-create")),
      step("edit", text("ویرایش، آموزش و ارسال", "Edit, review and assign"), text("حرکات ذخیره‌شده اینجا هستند. از روی کارت می‌توانید ویرایش یا حذف کنید و حرکت را با تنظیمات دلخواه به برنامهٔ شاگرد بدهید.", "Your saved custom moves appear here. Use each card to edit, delete or assign the move with a tailored prescription."), `${at("moves-results")}, ${at("moves-tabs")}`),
    ],
  },
  "moves-studio": {
    id: "moves-studio", label: text("استودیو انیمیشن", "The animation studio"), steps: [
      step("studio", text("حرکت را از زوایای مختلف ببینید", "Inspect movement from different angles"), text("در استودیو، حرکت‌های پشتیبانی‌شده را انتخاب کنید و اجرای سه‌بعدی، زاویهٔ دوربین و عضلات درگیر را بررسی کنید. فقط حرکت‌های شناخته‌شدهٔ مجموعه، تعریف انیمیشن معتبر دارند.", "Select supported moves to review 3D execution, camera angles and target muscles. Valid animation definitions are available for recognized catalog movements."), content),
    ],
  },
  calendar: {
    id: "calendar", label: text("تقویم جلسات مربی", "Your appointment calendar"), steps: [
      step("appointments", text("جلسات را با زمان دقیق ثبت کنید", "Schedule appointments precisely"), text("شاگرد، عنوان، تاریخ، ساعت و مدت جلسه را انتخاب و رزرو را ثبت کنید. جلسات پیش رو و سوابق جدا نمایش داده می‌شوند؛ بعد از جلسه، وضعیت را به انجام‌شده یا لغو تغییر بدهید.", "Choose an athlete, title, date, time and duration, then save the appointment. Upcoming and past sessions appear separately. Afterwards, mark it complete or cancelled."), content),
    ],
  },
  chat: {
    id: "chat", label: text("ارتباط با شاگردان", "Athlete messages"), steps: [
      step("conversation", text("گفتگوی هر شاگرد، جداگانه", "A separate conversation for each athlete"), text("شاگرد را از فهرست گفتگوها انتخاب کنید تا فقط پیام‌های همان نفر باز شود. اینجا می‌توانید بازخورد تمرین و پاسخ سؤال‌های او را بفرستید.", "Select an athlete's conversation to see only their messages. Use it to send training feedback and answer questions."), content),
      step("send", text("نوشتن، بررسی، ارسال", "Write, review, send"), text("متن را در کادر وارد کنید و ارسال را بزنید. قبل از ارسال توصیهٔ مربوط به برنامه، مطمئن شوید گفتگوی شاگرد درست باز است.", "Write in the message box and press Send. Check that you're in the right athlete's conversation before sending plan advice."), at("chat-composer"), true),
    ],
  },
  nutrition: {
    id: "nutrition", label: text("برنامه‌های غذایی", "Nutrition planning"), steps: [
      step("nutrition", text("تغذیهٔ هر شاگرد را جدا مدیریت کنید", "Manage nutrition per athlete"), text("ابتدا شاگرد را انتخاب و وضعیت خدمت تغذیهٔ او را بررسی کنید. برنامه، روزها و وعده‌ها را بر اساس اطلاعات واقعی او تنظیم کنید؛ انتشار برنامه را خودتان تأیید می‌کنید.", "Choose an athlete and check their nutrition-service status. Set targets, days and meals using their actual details. You control when the plan is published."), content),
    ],
  },
  reports: {
    id: "reports", label: text("گزارش‌های مربی", "Coaching reports"), steps: [
      step("reports", text("پیگیری بر اساس تمرین‌های ثبت‌شده", "Follow up using logged activity"), text("گزارش‌ها از داده‌های شاگردان متصل به شما ساخته می‌شوند. تعداد تمرین، پایبندی و روند تغییرات را بررسی کنید؛ برای جزئیات بیشتر پروندهٔ شاگرد را باز کنید.", "Reports use data from your connected athletes. Review sessions, adherence and trends, then open an athlete's profile for details."), content),
    ],
  },
  billing: {
    id: "billing", label: text("اشتراک و پرداخت", "Plans and payments"), steps: [
      step("billing", text("پلن‌ها و پرداخت‌ها در یک قسمت", "Plans and payments together"), text("از تب‌های این بخش، پلن‌های ارائه‌شده و پرداخت‌ها را مدیریت کنید. قیمت، مدت، تعداد جلسه و خدمات را پیش از ذخیره بازبینی کنید؛ وضعیت فاکتورها هم از همین بخش قابل پیگیری است.", "Use these tabs to manage offered plans and payments. Review price, duration, session count and services before saving. Invoice status is tracked here too."), content),
    ],
  },
  settings: {
    id: "settings", label: text("تنظیمات پنل", "Workspace settings"), steps: [
      step("settings", text("ظاهر و رفتار پنل را تنظیم کنید", "Personalize your workspace"), text("تم، رنگ‌ها، زبان و اعلان‌ها را از این قسمت تنظیم کنید. برای پشتیبان‌گیری، خروجی فایل را بگیرید و در جای امن نگه دارید؛ خروج از حساب اطلاعات ذخیره‌شده را حذف نمی‌کند.", "Set your theme, colors, language and notification preferences here. Export a backup and store it safely. Signing out does not delete your saved information."), content),
      step("help", text("دوباره به راهنما نیاز داشتید؟", "Need the guide again?"), text("در بالای هر صفحه روی علامت سؤال بزنید تا راهنمای همان قسمت از ابتدا نمایش داده شود. راهنما هیچ تغییری در اطلاعات حساب یا برنامه‌ها ایجاد نمی‌کند.", "Tap the question mark at the top of any page to restart its guide. Guides never change account data or plans."), at("guide-help")),
    ],
  },
  profile: {
    id: "profile", label: text("پروفایل مربی", "Coach profile"), steps: [
      step("profile", text("هویت حرفه‌ای و امنیت حساب", "Your profile and account security"), text("تصویر، نام و اطلاعات تماس را به‌روز کنید و تغییرات را ذخیره کنید. تغییر رمز عبور بخش جداگانه دارد. کد دعوت دائمی شما با ویرایش پروفایل عوض نمی‌شود.", "Update your photo, name and contact details, then save. Password changes have their own form. Editing your profile does not change your permanent invite code."), at("profile-editor")),
    ],
  },
  admin: {
    id: "admin", label: text("مدیریت سیستم", "System administration"), steps: [
      step("admin", text("دسترسی ویژهٔ مدیریت", "Administration access"), text("این بخش فقط برای مدیر سیستم نمایش داده می‌شود. قبل از تغییر وضعیت کاربران یا اطلاعات مدیریتی، حساب و داده‌های انتخاب‌شده را با دقت بررسی کنید.", "This section is available only to system administrators. Carefully check the selected account and data before changing user status or administrative information."), content),
    ],
  },
};

export function getGuideSpec(role: GuideRole, page: string): GuideSpec {
  const catalog = role === "coach" ? coach : student;
  const alias = role === "coach"
    ? ({ moves: "moves-library", library: "moves-library", muscles: "moves-muscles", studio: "moves-studio", plans: "billing" } as Record<string, string>)[page]
    : page.startsWith("workout-") ? "workout" : undefined;
  return catalog[page] ?? catalog[alias ?? page] ?? {
    id: page,
    label: text("راهنمای این بخش", "Page guide"),
    steps: [step("intro", text("از اینجا شروع کنید", "Start here"), text("امکانات این صفحه مربوط به حساب شما هستند. برای آشنایی دوباره با هر بخش، از دکمهٔ علامت سؤال بالای صفحه استفاده کنید.", "This page contains tools for your account. Use the question-mark button at the top of a page to replay its guide."), content)],
  };
}