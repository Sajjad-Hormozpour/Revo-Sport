import { memo, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import {
  BookOpen, Calculator, Check, ChevronLeft, Clock, Copy, Disc, Dumbbell,
  History, MoreHorizontal, Pause, Play, Plus, RotateCcw, Sparkles, Timer, Trophy, Trash2, X,
} from "lucide-react";
import { localize } from "../../i18n";
import { useLang } from "../lib/i18n";
import type { AppData, ProgramSet } from "../data/types";
import { fa, formatClock } from "../lib/core";
import { isAparat, isYoutube, useMediaUrl } from "../lib/media";
import { calculatePlates, cleanWorkoutInput, estimate1RM, prescribedMetric, resolvedMetric } from "../lib/workout-values";
import { ExThumb, type ResolvedExercise } from "./exercise";
import type { SessionSetValue, SetKind } from "./session-view";
import { useWorkoutLayer } from "./workout-layer";
import benchPoster from "../../auth/reel/bench.jpg";
import squatPoster from "../../auth/reel/squat-portrait.jpg";
import curlPoster from "../../auth/reel/curl-tank.jpg";
import pullupPoster from "../../auth/reel/pullup-back.jpg";
import "./immersive-workout.css";

const FALLBACKS: Record<string, string> = {
  "ex-bench": benchPoster, "ex-squat": squatPoster,
  "ex-curl": curlPoster, "ex-pullup": pullupPoster,
};
const CIRCLE = 2 * Math.PI * 18;
const SET_KINDS: SetKind[] = ["normal", "warmup", "drop", "failure"];

export interface PreviousExerciseSummary {
  dateLabel: string;
  bestWeight: number;
  bestReps: number;
  best1RM: number;
  sets: { weight: number; reps: number }[];
}

/** ساعت زندهٔ کم‌رنگ در نوار بالا؛ ایزوله تا صحنهٔ تمرین هر ثانیه رندر نشود */
function LiveSessionBadge({ startedAt, prBanner }: { startedAt?: string | null; prBanner?: string | null }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!startedAt) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [startedAt]);

  if (prBanner) {
    return (
      <div className="iw-live-pill is-pr" role="status" aria-live="polite">
        <Trophy size={12} />
        <span>{prBanner}</span>
      </div>
    );
  }
  if (!startedAt) return <span aria-hidden="true" />;
  const secs = Math.max(0, Math.floor((now - Date.parse(startedAt)) / 1000));
  return (
    <div className="iw-live-pill" role="timer" aria-live="off">
      <i aria-hidden="true" />
      <span>{formatClock(secs)}</span>
    </div>
  );
}

const WorkoutMedia = memo(function WorkoutMedia({
  id, imageUrl, imageMediaId, videoUrl, videoMediaId, paused, onUnavailable,
}: {
  id: string; imageUrl: string; imageMediaId: string;
  videoUrl: string; videoMediaId: string; paused: boolean; onUnavailable: (unavailable?: boolean) => void;
}) {
  const uploadedVideo = useMediaUrl(videoMediaId || null);
  const uploadedImage = useMediaUrl(imageMediaId || null);
  const url = (uploadedVideo || videoUrl || "").trim();
  const videoSource = url && !isYoutube(url) && !isAparat(url) ? url : "";
  const source = uploadedImage || imageUrl || FALLBACKS[id] || "";
  const [imageFailed, setImageFailed] = useState(false);
  const [fallbackFailed, setFallbackFailed] = useState(false);
  const [videoFailed, setVideoFailed] = useState(false);
  const [videoReady, setVideoReady] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const failureRef = useRef(onUnavailable);
  failureRef.current = onUnavailable;
  const poster = imageFailed ? FALLBACKS[id] ?? "" : source;

  useEffect(() => { setImageFailed(false); setFallbackFailed(false); }, [source]);
  useEffect(() => {
    if (!videoSource && !videoMediaId) failureRef.current();
    const video = videoRef.current;
    if (!video || videoFailed) return;
    let disposed = false;
    const sync = () => {
      if (paused || document.hidden) video.pause();
      else void video.play().catch(() => { if (!disposed) failureRef.current(); });
    };
    sync();
    document.addEventListener("visibilitychange", sync);
    return () => { disposed = true; video.pause(); document.removeEventListener("visibilitychange", sync); };
  }, [paused, videoSource, videoFailed, videoMediaId]);

  return (
    <div className="iw-media" aria-hidden="true">
      {poster && !fallbackFailed ? (
        <img className="iw-poster" src={poster} alt="" decoding="async" fetchPriority="high" draggable={false}
          onError={() => imageFailed ? setFallbackFailed(true) : setImageFailed(true)} />
      ) : <div className="iw-media-empty"><Dumbbell size={48} strokeWidth={1} /></div>}
      {!!videoSource && !videoFailed && (
        <video ref={videoRef} src={videoSource} poster={poster || undefined} muted loop playsInline preload="metadata"
          className={`iw-video${videoReady ? " is-ready" : ""}`}
          onPlaying={() => { setVideoReady(true); failureRef.current(false); }} onError={() => { setVideoFailed(true); failureRef.current(); }} />
      )}
      <div className="iw-media-light" />
      <div className="iw-media-shade" />
    </div>
  );
});

export interface ImmersiveProps {
  onBack: () => void;
  onFinish: () => void;
  item: ProgramSet;
  exercise: ResolvedExercise;
  values: SessionSetValue[];
  done: boolean[];
  activeSet: number;
  onEdit: (setIndex: number, field: "weight" | "reps", value: string) => void;
  onRir?: (setIndex: number, value: string) => void;
  onTag?: (setIndex: number, tag: SetKind) => void;
  onToggleSet: (setIndex: number) => void;
  onAddSet?: () => void;
  onRemoveSet?: () => void;
  canRemoveSet?: boolean;
  onCopyToRemaining?: (fromIndex: number) => void;
  onApplyPrevious?: () => void;
  onResetExercise?: () => void;
  onStartCustomRest?: (seconds: number) => void;
  personalNote?: string;
  onPersonalNote?: (note: string) => void;
  previous?: PreviousExerciseSummary | null;
  exerciseCompleted?: boolean[];
  onJump: (exerciseIndex: number) => void;
  exerciseIndex: number;
  totalExercises: number;
  focusName: string;
  onGuide: () => void;
  startedAt?: string | null;
  sessionDone?: number;
  sessionTotal?: number;
  sessionVolume?: number;
  suspended?: boolean;
}

/** صحنهٔ تمرین مینیمال با ابزارهای حرفه‌ای زمینه‌ای و بدون شلوغی بصری */
export function ImmersiveWorkout(props: ImmersiveProps) {
  const { item, exercise, values, done, activeSet, exerciseIndex, totalExercises } = props;
  const { lang, dir } = useLang();
  const tx = (faText: string, enText: string) => lang === "fa" ? faText : enText;
  const [paused, setPaused] = useState(false);
  const [unavailable, setUnavailable] = useState(false);
  const [details, setDetails] = useState(false);
  const [editing, setEditing] = useState<{ index: number; field: "weight" | "reps" } | null>(null);
  const [prBanner, setPrBanner] = useState<string | null>(null);
  const screenRef = useRef<HTMLDivElement>(null);
  const setsRef = useRef<HTMLDivElement>(null);
  const pagerRef = useRef<HTMLElement>(null);
  const blurTimer = useRef<number>(0);
  const swipeStart = useRef<{ x: number; y: number } | null>(null);

  const totalSetCount = values.length;
  const allDone = props.sessionTotal ? props.sessionDone === props.sessionTotal : false;
  const progress = props.sessionTotal ? Math.min(1, (props.sessionDone ?? 0) / props.sessionTotal) : 0;
  const videoAvailable = !unavailable && (!!exercise.videoMediaId || (!!exercise.videoUrl && !isYoutube(exercise.videoUrl) && !isAparat(exercise.videoUrl)));
  const markUnavailable = useCallback((value = true) => setUnavailable(value), []);
  const hasNote = Boolean((item.notes || "").trim() || (props.personalNote || "").trim());

  useWorkoutLayer(screenRef, props.onBack, '[data-guide-scope="student"]');

  useEffect(() => {
    setPaused(false);
    setUnavailable(false);
    setDetails(false);
    setEditing(null);
    setPrBanner(null);
  }, [item.id]);

  useEffect(() => () => window.clearTimeout(blurTimer.current), []);

  useEffect(() => {
    const pager = pagerRef.current;
    const selected = pager?.querySelector<HTMLElement>('[aria-current="step"]');
    if (pager && selected) {
      pager.scrollLeft += selected.getBoundingClientRect().left - pager.getBoundingClientRect().left - (pager.clientWidth - selected.offsetWidth) / 2;
    }
    const sets = setsRef.current;
    const active = sets?.children[activeSet] as HTMLElement | undefined;
    if (sets && active) {
      const top = active.offsetTop - sets.offsetTop;
      if (top < sets.scrollTop || top + active.offsetHeight > sets.scrollTop + sets.clientHeight) {
        sets.scrollTop = Math.max(0, top - sets.clientHeight / 2 + active.offsetHeight / 2);
      }
    }
  }, [activeSet, item.id, totalSetCount]);

  useEffect(() => {
    const viewport = window.visualViewport;
    const screen = screenRef.current;
    if (!viewport || !screen) return;
    const fit = () => {
      screen.style.setProperty("--iw-height", `${viewport.height}px`);
      screen.style.setProperty("--iw-top", `${viewport.offsetTop}px`);
      screen.classList.toggle("is-keyboard", viewport.height < window.innerHeight * 0.75);
    };
    fit();
    viewport.addEventListener("resize", fit);
    viewport.addEventListener("scroll", fit);
    return () => { viewport.removeEventListener("resize", fit); viewport.removeEventListener("scroll", fit); };
  }, []);

  const handleToggleSet = (setIdx: number) => {
    const willComplete = !done[setIdx];
    if (willComplete && props.previous && props.previous.bestWeight > 0) {
      const w = resolvedMetric(values[setIdx]?.weight, item.weight, "weight");
      const r = resolvedMetric(values[setIdx]?.reps, item.reps, "reps");
      const e1rm = estimate1RM(w, r);
      if (w > props.previous.bestWeight || (e1rm > props.previous.best1RM && w > 0)) {
        setPrBanner(tx(`رکورد جدید • ${w} kg`, `New PR • ${w} kg`));
        window.setTimeout(() => setPrBanner(null), 3200);
      }
    }
    setEditing(null);
    props.onToggleSet(setIdx);
  };

  const adjustFocused = (delta: number) => {
    if (!editing) return;
    const curVal = values[editing.index]?.[editing.field] ?? "";
    const base = curVal.trim() !== ""
      ? Number(curVal) || 0
      : prescribedMetric(editing.field === "weight" ? item.weight : item.reps, editing.field);
    const next = Math.max(0, Math.round((base + delta) * 100) / 100);
    props.onEdit(editing.index, editing.field, String(next));
  };

  const cycleSetKind = (setIdx: number) => {
    if (!props.onTag) return;
    const current = values[setIdx]?.tag ?? "normal";
    const next = SET_KINDS[(SET_KINDS.indexOf(current) + 1) % SET_KINDS.length];
    props.onTag(setIdx, next);
  };

  const kindMeta = (kind?: SetKind) => {
    if (kind === "warmup") return { short: "W", label: tx("ست گرم‌کردن", "Warm-up set"), cls: "is-warmup" };
    if (kind === "drop") return { short: "D", label: tx("دراپ‌ست", "Drop set"), cls: "is-drop" };
    if (kind === "failure") return { short: "F", label: tx("تا ناتوانی", "To failure"), cls: "is-failure" };
    return null;
  };

  return createPortal(
    <div className="iw-layer" data-workout-overlay="true">
      <div
        className="iw-screen"
        ref={screenRef}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={tx("تمرین امروز", "Today's workout")}
        data-guide-scope="immersive-workout"
        dir={dir}
        onTouchStart={(e) => {
          const t = e.touches[0];
          if (t && t.clientY < window.innerHeight * 0.48) swipeStart.current = { x: t.clientX, y: t.clientY };
          else swipeStart.current = null;
        }}
        onTouchEnd={(e) => {
          if (!swipeStart.current || details) return;
          const t = e.changedTouches[0];
          const dx = t.clientX - swipeStart.current.x;
          const dy = t.clientY - swipeStart.current.y;
          swipeStart.current = null;
          if (Math.abs(dx) > 64 && Math.abs(dx) > Math.abs(dy) * 1.6) {
            const nextIdx = dx < 0 ? exerciseIndex : exerciseIndex - 2;
            if (nextIdx >= 0 && nextIdx < totalExercises) props.onJump(nextIdx);
          }
        }}
      >
        <WorkoutMedia key={item.id} id={exercise.id} imageUrl={exercise.imageUrl} imageMediaId={exercise.imageMediaId}
          videoUrl={exercise.videoUrl} videoMediaId={exercise.videoMediaId} paused={paused || details || !!props.suspended}
          onUnavailable={markUnavailable} />

        <div className="iw-stage">
          <header className="iw-topbar" data-guide="workout-header" dir="ltr">
            <button className="iw-round" type="button" onClick={props.onBack} aria-label={tx("بازگشت به فهرست", "Back to workout overview")}>
              <ChevronLeft size={23} strokeWidth={2} />
            </button>
            <LiveSessionBadge startedAt={props.startedAt} prBanner={prBanner} />
            <button className={`iw-round ${videoAvailable ? "iw-playback" : ""}`} type="button"
              onClick={() => videoAvailable ? setPaused((value) => !value) : setDetails(true)}
              aria-label={!videoAvailable ? tx("جزئیات و تنظیمات تمرین", "Workout details and controls") : paused ? tx("ادامه ویدیو", "Resume video") : tx("توقف ویدیو", "Pause video")}
              aria-pressed={videoAvailable ? paused : undefined}>
              {!videoAvailable ? <MoreHorizontal size={22} /> : paused ? <Play size={20} fill="currentColor" strokeWidth={0} /> : <Pause size={21} fill="currentColor" strokeWidth={0} />}
            </button>
          </header>

          <div className="iw-bottom">
            <div className="iw-sets" ref={setsRef} data-guide="exercise-sets" dir="ltr" role="group" aria-label={tx("وزن، تکرار و ثبت ست‌ها", "Set weight, repetitions and completion")}>
              {values.map((value, i) => {
                const isDone = !!done[i];
                const active = i === activeSet && !isDone;
                const weight = resolvedMetric(value.weight, item.weight, "weight");
                const reps = resolvedMetric(value.reps, item.reps, "reps");
                const tagInfo = kindMeta(value.tag);
                return (
                  <div key={`${item.id}-${i}`} className={`iw-set-row${isDone ? " is-row-done" : ""}${active ? " is-row-active" : ""}`} data-active={active} data-guide-detail={active ? "active-set" : undefined}>
                    <span
                      className={`iw-set-number ${tagInfo ? tagInfo.cls : ""}`}
                      role={props.onTag ? "button" : undefined}
                      tabIndex={props.onTag ? 0 : undefined}
                      title={tagInfo ? tagInfo.label : tx("لمس برای تغییر نوع ست (گرم‌کردن / دراپ‌ست)", "Tap to cycle set type (Warm-up / Drop / Failure)")}
                      aria-label={tagInfo ? `${tx(`ست ${i + 1}`, `Set ${i + 1}`)} — ${tagInfo.label}` : tx(`ست ${i + 1}`, `Set ${i + 1}`)}
                      onClick={props.onTag ? () => cycleSetKind(i) : undefined}
                      onKeyDown={props.onTag ? (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); cycleSetKind(i); } } : undefined}
                    >
                      {tagInfo ? tagInfo.short : active ? <span className="iw-active-dot" aria-hidden="true" /> : i + 1}
                    </span>
                    <label className="iw-value">
                      <input
                        value={value.weight}
                        placeholder={String(weight)}
                        onChange={(event) => props.onEdit(i, "weight", cleanWorkoutInput(event.target.value, true))}
                        onFocus={(event) => {
                          window.clearTimeout(blurTimer.current);
                          setEditing({ index: i, field: "weight" });
                          event.currentTarget.select();
                        }}
                        onBlur={() => {
                          blurTimer.current = window.setTimeout(() => setEditing(null), 140);
                        }}
                        onKeyDown={(event) => { if (event.key === "Enter") event.currentTarget.blur(); }}
                        inputMode="decimal" autoComplete="off" enterKeyHint="done"
                        aria-label={tx(`وزن ست ${i + 1}`, `Set ${i + 1} weight`)}
                        style={{ width: `${Math.max(1, (value.weight || String(weight)).length)}ch` }}
                      />
                      <span aria-hidden="true">kg</span>
                    </label>
                    <label className="iw-value iw-reps">
                      <input
                        value={value.reps}
                        placeholder={String(reps)}
                        onChange={(event) => props.onEdit(i, "reps", cleanWorkoutInput(event.target.value, false))}
                        onFocus={(event) => {
                          window.clearTimeout(blurTimer.current);
                          setEditing({ index: i, field: "reps" });
                          event.currentTarget.select();
                        }}
                        onBlur={() => {
                          blurTimer.current = window.setTimeout(() => setEditing(null), 140);
                        }}
                        onKeyDown={(event) => { if (event.key === "Enter") event.currentTarget.blur(); }}
                        inputMode="numeric" autoComplete="off" enterKeyHint="done"
                        aria-label={tx(`تکرار ست ${i + 1}`, `Set ${i + 1} reps`)}
                        style={{ width: `${Math.max(1, (value.reps || String(reps)).length)}ch` }}
                      />
                      <span aria-hidden="true">x</span>
                    </label>
                    <button type="button" className={`iw-check${isDone ? " is-done" : ""}`} aria-pressed={isDone}
                      aria-label={tx(isDone ? `لغو تیک ست ${i + 1}` : `تیک ست ${i + 1}`, done[i] ? `Uncheck set ${i + 1}` : `Complete set ${i + 1}`)} onClick={() => handleToggleSet(i)}>
                      <Check size={24} strokeWidth={2.6} />
                    </button>
                  </div>
                );
              })}
            </div>

            {/* نوار ابزار هوشمند زمینه‌ای: فقط هنگام ویرایش عدد ظاهر می‌شود تا صحنه همیشه خلوت بماند */}
            {editing ? (
              <div className="iw-quick-bar" dir="ltr" onMouseDown={(e) => e.preventDefault()}>
                {editing.field === "weight" ? (
                  <>
                    <button type="button" onClick={() => adjustFocused(-2.5)}>-2.5</button>
                    <button type="button" onClick={() => adjustFocused(-1.25)}>-1.25</button>
                    <button type="button" onClick={() => adjustFocused(1.25)}>+1.25</button>
                    <button type="button" onClick={() => adjustFocused(2.5)}>+2.5</button>
                  </>
                ) : (
                  <>
                    <button type="button" onClick={() => adjustFocused(-2)}>-2</button>
                    <button type="button" onClick={() => adjustFocused(-1)}>-1</button>
                    <button type="button" onClick={() => adjustFocused(1)}>+1</button>
                    <button type="button" onClick={() => adjustFocused(2)}>+2</button>
                  </>
                )}
                {props.onCopyToRemaining && totalSetCount > 1 && (
                  <button type="button" className="iw-quick-accent" onClick={() => props.onCopyToRemaining?.(editing.index)}>
                    {tx("کپی در بقیه", "Copy to rest")}
                  </button>
                )}
                {props.previous && props.onApplyPrevious && (
                  <button type="button" className="iw-quick-subtle" onClick={() => props.onApplyPrevious?.()}>
                    {tx("دفعه قبل", "Last")}
                  </button>
                )}
              </div>
            ) : (
              <div className="iw-whisper-row" dir={dir}>
                {props.onAddSet ? (
                  <div className="iw-whisper-actions">
                    <button type="button" onClick={props.onAddSet}>
                      <Plus size={12} />
                      <span>{tx("ست اضافه", "Add set")}</span>
                    </button>
                    {props.canRemoveSet && props.onRemoveSet && (
                      <button type="button" onClick={props.onRemoveSet} className="is-muted">
                        <span>{tx("حذف ست آخر", "Remove last")}</span>
                      </button>
                    )}
                  </div>
                ) : <span />}
                {props.previous ? (
                  <button type="button" className="iw-whisper-prev" onClick={() => setDetails(true)}>
                    <span>{tx("قبلی:", "Last:")}</span>
                    <b dir="ltr">{props.previous.bestWeight} kg × {props.previous.bestReps}</b>
                  </button>
                ) : item.rest > 0 ? (
                  <span className="iw-whisper-meta">{tx(`استراحت ${fa(item.rest)} ثانیه`, `Rest ${item.rest}s`)}</span>
                ) : null}
              </div>
            )}

            <footer className="iw-footer" dir="ltr">
              <span className="iw-progress" role="img" aria-label={tx(`حرکت ${exerciseIndex} از ${totalExercises}؛ ${props.sessionDone ?? 0} ست ثبت‌شده`, `Exercise ${exerciseIndex} of ${totalExercises}; ${props.sessionDone ?? 0} sets complete`)}>
                <svg viewBox="0 0 44 44" aria-hidden="true"><circle cx="22" cy="22" r="18" fill="none" stroke="#2f3033" strokeWidth="2.6" />
                  <circle className="iw-progress-fill" cx="22" cy="22" r="18" fill="none" style={{ stroke: allDone ? "#3cd070" : "var(--gender-accent, #e9e400)" }} strokeWidth="2.6" strokeLinecap="round" strokeDasharray={CIRCLE} strokeDashoffset={CIRCLE * (1 - progress)} /></svg>
                <span>{exerciseIndex}/{totalExercises}</span>
              </span>
              <button data-guide="exercise-heading" type="button" className="iw-exercise-title" dir={dir} onClick={() => setDetails(true)} aria-label={tx(`جزئیات و آموزش ${exercise.name}`, `Details and guide for ${exercise.en || exercise.name}`)}>
                <strong>
                  {lang === "en" ? exercise.en || exercise.name : exercise.name}
                  {hasNote && <i className="iw-note-dot" aria-hidden="true" />}
                </strong>
                <span>{localize(props.focusName || exercise.muscle)}</span>
              </button>
              <nav className="iw-pager" ref={pagerRef} data-guide="workout-pager" aria-label={tx("انتخاب حرکت", "Choose exercise")}>
                {Array.from({ length: totalExercises }, (_, i) => {
                  const exDone = props.exerciseCompleted?.[i] ?? false;
                  return (
                    <button
                      key={i}
                      type="button"
                      className={`iw-page${exDone ? " is-complete" : ""}`}
                      aria-current={i === exerciseIndex - 1 ? "step" : undefined}
                      aria-label={tx(`حرکت ${i + 1}`, `Exercise ${i + 1}`)}
                      onClick={() => props.onJump(i)}
                    >
                      {i + 1}
                    </button>
                  );
                })}
              </nav>
            </footer>
          </div>
        </div>
        {details && <WorkoutDetails {...props} onClose={() => setDetails(false)} />}
        <span className="iw-sr-only" role="status">{tx(`${done.filter(Boolean).length} از ${totalSetCount} ست انجام شد`, `${done.filter(Boolean).length} of ${totalSetCount} sets completed`)}</span>
      </div>
    </div>, document.body,
  );
}

function WorkoutDetails(props: ImmersiveProps & { onClose: () => void }) {
  const { lang, dir } = useLang();
  const tx = (faText: string, enText: string) => lang === "fa" ? faText : enText;
  const sheetRef = useRef<HTMLDivElement>(null);
  const [tab, setTab] = useState<"info" | "history" | "tools">("info");
  const [barWeight, setBarWeight] = useState(20);
  useWorkoutLayer(sheetRef, props.onClose, ".iw-stage");

  const currentSet = props.values[props.activeSet] ?? props.values[0];
  const note = props.item.notes || props.exercise.tips;
  const elapsed = props.startedAt ? Math.max(0, Math.floor((Date.now() - Date.parse(props.startedAt)) / 1000)) : 0;

  const activeWeight = resolvedMetric(currentSet?.weight, props.item.weight, "weight");
  const activeReps = resolvedMetric(currentSet?.reps, props.item.reps, "reps");
  const current1RM = useMemo(() => estimate1RM(activeWeight, activeReps), [activeWeight, activeReps]);
  const plateCalc = useMemo(() => calculatePlates(activeWeight, barWeight), [activeWeight, barWeight]);

  return (
    <div className="iw-sheet-backdrop" onClick={props.onClose}>
      <div className="iw-sheet" ref={sheetRef} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="iw-details-title" dir={dir} onClick={(event) => event.stopPropagation()}>
        <div className="iw-sheet-handle" aria-hidden="true" />
        <div className="iw-sheet-heading">
          <div>
            <h2 id="iw-details-title">{localize(props.exercise.name)}</h2>
            <p className="iw-sheet-sub">{localize(props.exercise.muscle)} • {localize(props.exercise.equipment)}</p>
          </div>
          <button type="button" className="iw-sheet-close" onClick={props.onClose} aria-label={tx("بستن جزئیات", "Close details")}><X size={20} /></button>
        </div>

        <div className="iw-sheet-tabs" role="tablist">
          <button type="button" role="tab" aria-selected={tab === "info"} className={tab === "info" ? "is-active" : ""} onClick={() => setTab("info")}>
            <Sparkles size={13} />{tx("جزئیات حرکت", "Exercise")}
          </button>
          <button type="button" role="tab" aria-selected={tab === "history"} className={tab === "history" ? "is-active" : ""} onClick={() => setTab("history")}>
            <History size={13} />{tx("رکورد و سوابق", "Records")}
          </button>
          <button type="button" role="tab" aria-selected={tab === "tools"} className={tab === "tools" ? "is-active" : ""} onClick={() => setTab("tools")}>
            <Calculator size={13} />{tx("ابزارها", "Tools")}
          </button>
        </div>

        {tab === "info" && (
          <div className="iw-tab-panel">
            <dl className="iw-prescription-grid">
              <div><dt>{tx("ست و تکرار", "Sets × Reps")}</dt><dd dir="ltr">{props.values.length} × {props.item.reps}</dd></div>
              <div><dt>{tx("وزن هدف", "Target")}</dt><dd>{localize(props.item.weight || "—")}</dd></div>
              <div><dt>{tx("استراحت", "Rest")}</dt><dd>{props.item.rest ? `${fa(props.item.rest)} ${tx("ث", "s")}` : "—"}</dd></div>
              <div><dt>{tx("ریتم", "Tempo")}</dt><dd dir="ltr">{props.item.tempo || "—"}</dd></div>
            </dl>

            {note && <p className="iw-coach-note">{localize(note)}</p>}

            {props.onRir && currentSet && (
              <div className="iw-rir-block">
                <label className="iw-rir-field">
                  <span>{tx(`تکرار باقی‌مانده در توانت، ست ${props.activeSet + 1}`, `Reps in reserve, set ${props.activeSet + 1}`)} <small>RIR</small></span>
                  <select aria-label={tx(`RIR ست ${props.activeSet + 1}`, `Set ${props.activeSet + 1} RIR`)} value={currentSet.rir} onChange={(event) => props.onRir?.(props.activeSet, event.target.value)}>
                    <option value="">{tx("انتخاب", "Select")}</option>
                    {[0, 1, 2, 3, 4, 5].map((n) => <option key={n} value={String(n)}>{n}</option>)}
                  </select>
                </label>
                <div className="iw-rir-pills" dir="ltr">
                  {[0, 1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      className={currentSet.rir === String(n) ? "is-selected" : ""}
                      onClick={() => props.onRir?.(props.activeSet, String(n))}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {props.onPersonalNote && (
              <label className="iw-personal-note">
                <span>{tx("یادداشت شخصی من (تنظیم صندلی، حس عضله و...)", "Personal note (seat setting, cue...)")}</span>
                <input
                  value={props.personalNote ?? ""}
                  onChange={(e) => props.onPersonalNote?.(e.target.value)}
                  placeholder={tx("مثلاً شماره صندلی ۴، مکث بالا...", "e.g. Seat pin 4, pause at top...")}
                />
              </label>
            )}

            <div className="iw-quick-grid">
              <button className="iw-detail-card" type="button" onClick={() => { props.onClose(); props.onGuide(); }}>
                <BookOpen size={16} />
                <span>{tx("آموزش تصویری و نقشهٔ عضله", "Video guide & muscle map")}</span>
              </button>
              {props.onAddSet && (
                <button className="iw-detail-card" type="button" onClick={() => props.onAddSet?.()}>
                  <Plus size={16} />
                  <span>{tx("افزودن یک ست به این حرکت", "Add an extra set")}</span>
                </button>
              )}
              {props.onResetExercise && (
                <button className="iw-detail-card is-subtle" type="button" onClick={() => { props.onResetExercise?.(); props.onClose(); }}>
                  <RotateCcw size={15} />
                  <span>{tx("پاک‌کردن تیک‌های این حرکت", "Reset sets of this exercise")}</span>
                </button>
              )}
            </div>
          </div>
        )}

        {tab === "history" && (
          <div className="iw-tab-panel">
            <div className="iw-records-grid">
              <div className="iw-record-box">
                <span><Trophy size={13} />{tx("تخمین رکورد ۱ تکرار (1RM)", "Estimated 1RM")}</span>
                <strong dir="ltr">{current1RM > 0 ? `${current1RM} kg` : "—"}</strong>
                <small>{tx("بر اساس ست فعلی", "From active set")}</small>
              </div>
              <div className="iw-record-box">
                <span><Sparkles size={13} />{tx("بهترین رکورد ثبت‌شده", "All-time best")}</span>
                <strong dir="ltr">
                  {props.previous && props.previous.bestWeight > 0
                    ? `${props.previous.bestWeight} kg × ${props.previous.bestReps}`
                    : tx("اولین ثبت", "First session")}
                </strong>
                <small>{props.previous ? props.previous.dateLabel : tx("رکورد پایه را امروز بساز", "Set your baseline today")}</small>
              </div>
            </div>

            {props.previous && props.previous.sets.length > 0 ? (
              <div className="iw-prev-box">
                <div className="iw-prev-head">
                  <span>{tx("ست‌های جلسهٔ قبل", "Last session sets")}</span>
                  <small>{props.previous.dateLabel}</small>
                </div>
                <div className="iw-prev-chips" dir="ltr">
                  {props.previous.sets.map((st, idx) => (
                    <span key={idx}>
                      <i>#{idx + 1}</i> {st.weight} kg × {st.reps}
                    </span>
                  ))}
                </div>
                {props.onApplyPrevious && (
                  <button
                    type="button"
                    className="iw-apply-prev-btn"
                    onClick={() => { props.onApplyPrevious?.(); props.onClose(); }}
                  >
                    <Copy size={14} />
                    {tx("جای‌گذاری وزن و تکرار جلسهٔ قبل", "Fill weights & reps from last session")}
                  </button>
                )}
              </div>
            ) : (
              <p className="iw-empty-hint">{tx("هنوز سابقه‌ای برای این حرکت ثبت نشده است؛ پس از ذخیرهٔ جلسه، رکوردت اینجا نمایش داده می‌شود.", "No previous log for this exercise yet. Once saved, your sets and PR appear here.")}</p>
            )}
          </div>
        )}

        {tab === "tools" && (
          <div className="iw-tab-panel">
            <div className="iw-tool-card">
              <div className="iw-tool-head">
                <span><Disc size={15} />{tx("ماشین‌حساب دیسک‌های هالتر", "Barbell plate calculator")}</span>
                <strong dir="ltr">{activeWeight} kg</strong>
              </div>
              <div className="iw-bar-selector">
                {[20, 15, 10, 0].map((bar) => (
                  <button
                    key={bar}
                    type="button"
                    className={barWeight === bar ? "is-selected" : ""}
                    onClick={() => setBarWeight(bar)}
                  >
                    {bar === 0 ? tx("بدون میله", "No bar") : <>{tx("میله", "Bar")} <bdi dir="ltr">{bar} kg</bdi></>}
                  </button>
                ))}
              </div>
              {plateCalc.plates.length > 0 ? (
                <div className="iw-plates-result">
                  <p>{tx("هر طرف میله:", "Each side:")} <b dir="ltr">{plateCalc.perSide} kg</b></p>
                  <div className="iw-plates-visual" dir="ltr">
                    {plateCalc.plates.map((plate, idx) => (
                      <span key={idx} className={`iw-plate p-${String(plate).replace(".", "_")}`}>{plate}</span>
                    ))}
                  </div>
                  {plateCalc.remainder > 0 && (
                    <small>{tx(`باقی‌مانده بدون دیسک استاندارد: ${plateCalc.remainder} کیلو در هر طرف`, `Remainder: ${plateCalc.remainder} kg per side`)}</small>
                  )}
                </div>
              ) : (
                <p className="iw-empty-hint">{tx("وزن ست بیشتر از وزن میله نیست؛ ابتدا وزن کل را وارد کنید.", "Enter a set weight heavier than the bar to see plates per side.")}</p>
              )}
            </div>

            {props.onStartCustomRest && (
              <div className="iw-tool-card">
                <div className="iw-tool-head">
                  <span><Timer size={15} />{tx("شروع تایمر استراحت دلخواه", "Start custom rest timer")}</span>
                </div>
                <div className="iw-rest-presets" dir="ltr">
                  {[30, 60, 90, 120, 180].map((sec) => (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => { props.onClose(); props.onStartCustomRest?.(sec); }}
                    >
                      {sec >= 60 && sec % 60 === 0 ? `${sec / 60}m` : `${sec}s`}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        <div className="iw-session-note">
          <span>{props.sessionDone ?? 0} / {props.sessionTotal ?? 0} {tx("ست", "sets")}{props.sessionVolume ? ` • ${Math.round(props.sessionVolume)} kg` : ""}</span>
          <time dir="ltr">{formatClock(elapsed)}</time>
        </div>
        <button className="iw-finish-action" type="button" disabled={!props.sessionDone} onClick={() => { props.onClose(); props.onFinish(); }}>
          {tx("پایان و ثبت جلسه", "Finish and save session")}
        </button>
      </div>
    </div>
  );
}

export function RestOverlay({ rest, paused, nextLabel, onSkip, onTogglePause, onAdjust }: {
  rest: { left: number; total: number } | null; paused: boolean; nextLabel?: string;
  onSkip: () => void; onTogglePause: () => void; onAdjust: (delta: number) => void;
}) {
  const { lang, dir } = useLang();
  const tx = (faText: string, enText: string) => lang === "fa" ? faText : enText;
  const panelRef = useRef<HTMLDivElement>(null);
  const [options, setOptions] = useState(false);
  useWorkoutLayer(panelRef, onSkip, document.querySelector(".iw-screen") ? ".iw-screen" : '[data-guide-scope="student"]', !!rest);
  useEffect(() => { if (!rest) setOptions(false); }, [rest]);
  if (!rest) return null;
  const length = rest.total % 60 === 0 ? `${rest.total / 60} ${tx("دقیقه", "min")}` : `${rest.total} ${tx("ثانیه", "sec")}`;
  const pct = rest.total > 0 ? Math.max(0, Math.min(100, (rest.left / rest.total) * 100)) : 0;
  return createPortal(
    <div className="rest-overlay iw-rest-layer" data-workout-overlay="true" dir={dir}>
      <div className="iw-rest-screen" ref={panelRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label={tx("تایمر استراحت", "Rest timer")}>
        <div className="iw-rest-tint" aria-hidden="true" />
        <div className="iw-rest-content">
          <p className="iw-rest-label">{paused ? tx("تایمر متوقف است", "Timer paused") : `${tx("استراحت", "Rest for")} ${length}`}</p>
          <time className="iw-countdown" dir="ltr" role="timer" aria-live="off">{formatClock(Math.max(0, rest.left)).replace(/^0(?=\d:)/, "")}</time>
          <div className="iw-rest-bar" aria-hidden="true"><span style={{ width: `${pct}%` }} /></div>
          {nextLabel && <p className="iw-up-next">{tx("بعدی: ", "Next: ")}{nextLabel}</p>}
          <button className="iw-skip" type="button" onClick={onSkip}>{tx("رد کردن", "Skip")}</button>
          <button className="iw-rest-options" type="button" aria-expanded={options} onClick={() => setOptions((value) => !value)} aria-label={tx("تنظیم زمان استراحت", "Adjust rest timer")}><MoreHorizontal size={22} /></button>
          {options && <div className="iw-rest-controls" dir="ltr">
            <button type="button" onClick={() => onAdjust(-15)} aria-label={tx("۱۵ ثانیه کمتر", "15 seconds less")}>-15s</button>
            <button type="button" onClick={onTogglePause} aria-label={paused ? tx("ادامه استراحت", "Resume rest") : tx("توقف استراحت", "Pause rest")}>{paused ? <Play size={16} fill="currentColor" /> : <Pause size={16} />}</button>
            <button type="button" onClick={() => onAdjust(15)} aria-label={tx("۱۵ ثانیه بیشتر", "15 seconds more")}>+15s</button>
          </div>}
        </div>
      </div>
    </div>, document.body,
  );
}

export interface OverviewExerciseItem {
  id: string;
  exerciseId: string;
  name: string;
  muscle: string;
  equipment: string;
  sets: number;
  doneSets: number;
  reps: string;
  rest: number;
  complete: boolean;
  lastBest?: string;
}

export function WorkoutOverview({
  title, programName, coachName, coachAvatar, data, items,
  onStart, onSelectExercise, onPreview, onFinish,
  started, doneSets, totalSets, volume, estimatedMinutes, onReset,
}: {
  title: string;
  programName: string;
  coachName?: string;
  coachAvatar?: string;
  data?: AppData;
  items: OverviewExerciseItem[];
  onStart: () => void;
  onSelectExercise: (index: number) => void;
  onPreview: (index: number) => void;
  onFinish?: () => void;
  started: boolean;
  doneSets: number;
  totalSets: number;
  volume?: number;
  estimatedMinutes: number;
  onReset: () => void;
}) {
  const { lang } = useLang();
  const tx = (faText: string, enText: string) => lang === "fa" ? faText : enText;
  const pct = totalSets > 0 ? Math.min(100, Math.round((doneSets / totalSets) * 100)) : 0;

  return (
    <section className="iw-overview">
      <div data-guide="workout-header" className="iw-overview-hero">
        {items[0] && (
          <div className="iw-overview-backdrop" aria-hidden="true">
            <ExThumb exerciseId={items[0].exerciseId} data={data} className="h-full w-full object-cover" />
            <div />
          </div>
        )}
        <div className="iw-overview-hero-body">
          <div className="iw-overview-top">
            <span className="iw-overview-badge">{programName}</span>
            {coachName && (
              <span className="iw-overview-coach">
                {coachAvatar && <img src={coachAvatar} alt="" />}
                <span>{coachName}</span>
              </span>
            )}
          </div>
          <h2>{localize(title)}</h2>
          <div className="iw-overview-stats">
            <div><b dir="ltr">{fa(items.length)}</b><span>{tx("حرکت", "Moves")}</span></div>
            <i aria-hidden="true" />
            <div><b dir="ltr">{started ? `${fa(doneSets)}/${fa(totalSets)}` : fa(totalSets)}</b><span>{tx("ست", "Sets")}</span></div>
            <i aria-hidden="true" />
            <div>
              <b dir="ltr">{started && volume && volume > 0 ? `${fa(Math.round(volume))}` : `~${fa(estimatedMinutes)}`}</b>
              <span>{started && volume && volume > 0 ? tx("کیلو حجم", "kg vol") : tx("دقیقه", "min")}</span>
            </div>
          </div>

          {started && (
            <div className="iw-overview-progress" role="status">
              <div className="iw-overview-bar"><span style={{ width: `${pct}%` }} /></div>
              <small>{fa(doneSets)} {tx("ست ثبت شده؛ ادامه از همان‌جایی که بودی.", "sets logged. Pick up where you left off.")}</small>
            </div>
          )}

          <div className="iw-overview-cta">
            <button data-guide="workout-start" className="iw-overview-start" type="button" disabled={!items.length} onClick={onStart}>
              <Play size={16} fill="currentColor" />
              {started ? tx("ادامهٔ تمرین", "Continue workout") : tx("شروع تمرین", "Start workout")}
            </button>
            {started && doneSets > 0 && onFinish && (
              <button className="iw-overview-finish" type="button" onClick={onFinish}>
                <Check size={16} strokeWidth={2.6} />
                {tx("ثبت جلسه", "Save")}
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="iw-overview-sec-head">
        <span>{tx("حرکات این جلسه", "Session exercises")}</span>
        <small>{tx("برای شروع از هر حرکت روی آن بزن", "Tap any move to jump in")}</small>
      </div>

      <ol data-guide="exercise-heading" className="iw-overview-list">
        {items.map((item, i) => (
          <li key={item.id} className={item.complete ? "is-complete" : item.doneSets > 0 ? "is-partial" : ""}>
            <button type="button" className="iw-overview-main" onClick={() => onSelectExercise(i)}>
              <span className="iw-overview-thumb">
                <ExThumb exerciseId={item.exerciseId} data={data} className="h-full w-full object-cover" />
                <em className={item.complete ? "is-complete" : ""}>
                  {item.complete ? <Check size={12} strokeWidth={3} /> : String(i + 1).padStart(2, "0")}
                </em>
              </span>
              <span className="iw-overview-info">
                <strong>{localize(item.name)}</strong>
                <small>
                  <span>{localize(item.muscle)}</span>
                  <i>•</i>
                  <span dir="ltr">{item.doneSets > 0 && !item.complete ? `${item.doneSets}/${item.sets}` : item.sets} × {item.reps}</span>
                  {item.rest > 0 && <><i>•</i><span><Clock size={10} /> {fa(item.rest)}{tx("ث", "s")}</span></>}
                </small>
                {item.lastBest && <b className="iw-overview-pr"><Trophy size={10} /> {tx("قبلی:", "Last:")} <span dir="ltr">{item.lastBest}</span></b>}
              </span>
            </button>
            <button
              type="button"
              className="iw-overview-guide"
              onClick={() => onPreview(i)}
              aria-label={tx(`آموزش ${item.name}`, `Guide: ${item.name}`)}
              title={tx("آموزش حرکت", "Exercise guide")}
            >
              <BookOpen size={15} />
            </button>
          </li>
        ))}
      </ol>

      {started && (
        <button type="button" className="iw-reset-link" onClick={onReset}>
          <Trash2 size={12} />
          {tx("بازنشانی این جلسه", "Reset this session")}
        </button>
      )}
    </section>
  );
}

export function WorkoutModal({ children, label, onClose }: { children: ReactNode; label: string; onClose: () => void }) {
  const panel = useRef<HTMLDivElement>(null);
  const { dir } = useLang();
  useWorkoutLayer(panel, onClose, document.querySelector(".iw-screen") ? ".iw-screen" : '[data-guide-scope="student"]');
  return createPortal(
    <div className="iw-modal-backdrop" dir={dir} onClick={onClose}>
      <div ref={panel} className="iw-modal-panel" role="dialog" tabIndex={-1} aria-modal="true" aria-label={label} onClick={(event) => event.stopPropagation()}>{children}</div>
    </div>, document.body,
  );
}
