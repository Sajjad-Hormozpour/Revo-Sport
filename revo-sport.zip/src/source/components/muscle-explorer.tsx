import { currentLanguage, localize, localizeStatic } from "../../i18n";
import { useMemo, useState } from "react";
import { ChevronLeft, Info, Layers, Search, Sparkles, Target, Wand2 } from "lucide-react";
import { useStore } from "../lib/store";
import { libraryFor } from "../data/library";
import { ExThumb, ExVideo } from "./exercise";
import { GROUP_BY_ID, MuscleMapCredit, MuscleMapPanel, MuscleMiniMap, groupIdsForMuscleLabel, readMapGender, type MapGender } from "./muscle-map";
import { Modal, Pill, SearchBox } from "./ui";
import { fa } from "../lib/core";

type Row = {
  id: string;
  name: string;
  en: string;
  muscle: string;
  equipment: string;
  level: string;
  custom: boolean;
};

export default function MuscleExplorer({
  onToast, onGoPrograms, lockedGender, variant = "coach",
}: {
  onToast: (t: string, d: string) => void;
  onGoPrograms?: () => void;
  /** شاگرد همیشه نقشهٔ جنسیت خودش را می‌بیند */
  lockedGender?: MapGender;
  variant?: "coach" | "student";
}) {
  const { data } = useStore();
  const [pickedGender, setGender] = useState<MapGender>(readMapGender);
  const gender: MapGender = lockedGender ?? pickedGender;
  const [selected, setSelected] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<Row | null>(null);

  const rows = useMemo<Row[]>(() => {
    const library = libraryFor(gender).map((exercise) => ({
      id: exercise.id,
      name: exercise.name,
      en: exercise.en,
      muscle: exercise.muscle,
      equipment: exercise.equipment,
      level: exercise.level,
      custom: false,
    }));
    const custom = (data.coachExercises ?? []).map((exercise) => ({
      id: exercise.id,
      name: exercise.name,
      en: exercise.en,
      muscle: exercise.muscle,
      equipment: exercise.equipment,
      level: exercise.level,
      custom: true,
    }));
    return [...custom, ...library];
  }, [data.coachExercises, gender]);

  const counts = useMemo(() => {
    const result: Record<string, number> = {};
    rows.forEach((row) => {
      groupIdsForMuscleLabel(row.muscle).forEach((id) => {
        result[id] = (result[id] ?? 0) + 1;
      });
    });
    return result;
  }, [rows]);

  const activeGroup = selected ? GROUP_BY_ID.get(selected) ?? null : null;
  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return rows.filter((row) => {
      const ids = groupIdsForMuscleLabel(row.muscle);
      if (selected && !ids.includes(selected)) return false;
      if (needle && !`${row.name} ${row.en} ${row.muscle} ${row.equipment}`.toLowerCase().includes(needle)) return false;
      return true;
    });
  }, [rows, selected, q]);

  const covered = useMemo(() => {
    const ids = new Set<string>();
    rows.forEach((row) => groupIdsForMuscleLabel(row.muscle).forEach((id) => ids.add(id)));
    return ids.size;
  }, [rows]);

  return (
    <div className="screen-in mx-auto max-w-5xl space-y-3">
      <div className="relative overflow-hidden rounded-[26px] border border-[var(--color-line)] bg-gradient-to-bl from-[#c9f31c]/[0.09] via-[var(--color-card)] to-[var(--color-card)] p-4 sm:p-5">
        <div className="pointer-events-none absolute -left-14 -top-16 h-44 w-44 rounded-full bg-[#c9f31c]/10 blur-3xl" />
        <div className="relative flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-[#c9f31c]/25 bg-[#c9f31c]/10 px-2.5 py-1 text-[10px] font-black text-[#b9dc2b]">
              <Sparkles size={11} />
              {localizeStatic("آناتومی تعاملی")}
            </span>
            <h1 className="mt-2 text-[20px] font-black leading-8 sm:text-[23px]">{localizeStatic(variant === "student" ? "نقشهٔ عضلات من" : "نقشهٔ عضلات")}</h1>
            <p className="mt-1 max-w-xl text-[11.5px] leading-6 text-[var(--color-mute)]">
              {localizeStatic(variant === "student" ? "عضله‌ای که می‌خواهی روی آن کار کنی را انتخاب کن تا حرکات همان گروه را ببینی؛ نقشه بر اساس جنسیت پروفایل تو نمایش داده می‌شود." : "روی هر عضله روی بدن کلیک کن تا حرکات همان گروه را ببینی. نقشه برای آقایان و بانوان جداگانه ترسیم شده است.")}
            </p>
          </div>
          <div className="grid shrink-0 grid-cols-3 gap-1.5 text-center">
            <div className="rounded-xl bg-[var(--color-bg)] px-2.5 py-1.5">
              <b className="tnum block text-[14px] font-black text-[#c9f31c]">{localize(fa(rows.length))}</b>
              <span className="text-[8.5px] font-bold text-[var(--color-mute)]">{localizeStatic("حرکت")}</span>
            </div>
            <div className="rounded-xl bg-[var(--color-bg)] px-2.5 py-1.5">
              <b className="tnum block text-[14px] font-black text-[#c9f31c]">{localize(fa(covered))}</b>
              <span className="text-[8.5px] font-bold text-[var(--color-mute)]">{localizeStatic("گروه")}</span>
            </div>
            <div className="rounded-xl bg-[var(--color-bg)] px-2.5 py-1.5">
              <b className="block text-[14px] font-black text-[#c9f31c]">{localizeStatic(gender === "female" ? "زن" : "مرد")}</b>
              <span className="text-[8.5px] font-bold text-[var(--color-mute)]">{localizeStatic("نقشه")}</span>
            </div>
          </div>
        </div>
      </div>

      <MuscleMapPanel
        gender={gender}
        onGender={(next) => setGender(next)}
        locked={!!lockedGender}
        selected={selected}
        onSelect={setSelected}
        counts={counts}
      />

      {activeGroup && (
        <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-[#c9f31c]/25 bg-[#c9f31c]/[0.06] px-3 py-2.5">
          <Target size={15} className="shrink-0 text-[#c9f31c]" />
          <b className="text-[12px]">{localize(activeGroup.fa)}</b>
          <span className="text-[10px] text-[var(--color-mute)]" dir="ltr">{activeGroup.en}</span>
          <span className="tnum rounded-full bg-[var(--color-bg)] px-2 py-0.5 text-[10px] font-black">{localize(fa(list.length))} {localizeStatic("حرکت")}</span>
          <span className="text-[10px] text-[var(--color-mute)]">
            {localizeStatic(activeGroup.views.length === 2 ? "در نمای روبه‌رو و پشت مشخص می‌شود" : activeGroup.views[0] === "front" ? "در نمای روبه‌رو مشخص می‌شود" : "در نمای پشت مشخص می‌شود")}
          </span>
          {q && <button onClick={() => setQ("")} className="mr-auto text-[10.5px] font-bold text-[#b9dc2b] hover:underline">{localizeStatic("پاک‌کردن جستجو")}</button>}
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2">
        <div className="min-w-[180px] flex-1">
          <SearchBox value={q} onChange={setQ} placeholder="جست‌وجوی حرکت…" />
        </div>
        <span className="tnum flex items-center gap-1 rounded-full bg-[var(--color-card)] px-3 py-2 text-[10.5px] font-bold text-[var(--color-mute)]">
          <Layers size={12} className="text-[#c9f31c]" />
          {localize(fa(list.length))} {localizeStatic("حرکت")}
        </span>
      </div>

      {list.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-[var(--color-line)] py-12 text-center">
          <Search size={22} className="mx-auto text-[var(--color-mute)]" />
          <b className="mt-2 block text-[13px]">{localizeStatic("حرکتی برای این عضله پیدا نشد")}</b>
          <p className="mt-1 text-[11.5px] text-[var(--color-mute)]">{localizeStatic("گروه دیگری را انتخاب کن یا جست‌وجو را پاک کن.")}</p>
          <button
            type="button"
            onClick={() => { setSelected(null); setQ(""); }}
            className="press mt-3 rounded-full bg-[#c9f31c] px-4 py-2 text-[11.5px] font-black text-black"
          >
            {localizeStatic("همه‌ی عضلات")}
          </button>
        </div>
      ) : (
        <div className="grid gap-2 sm:grid-cols-2">
          {list.map((row) => (
            <button
              key={row.id}
              type="button"
              onClick={() => setOpen(row)}
              className="press group flex w-full items-center gap-2.5 rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-2 text-right transition hover:border-[#c9f31c]/40 hover:bg-[var(--color-card)]/80"
            >
              <ExThumb exerciseId={row.id} data={data} className="h-14 w-14 shrink-0 rounded-xl object-cover" />
              <span className="min-w-0 flex-1">
                <b className="block truncate text-[12.5px]">
                  {localize(row.name)}
                  {row.custom && <span className="mr-1.5 rounded-full bg-[#c9f31c]/15 px-1.5 py-0.5 text-[8.5px] font-black text-[#b9dc2b]">{localizeStatic("من")}</span>}
                </b>
                {currentLanguage() === "en" && row.en && <span className="block truncate text-[9px] text-[var(--color-mute)]" dir="ltr">{row.en}</span>}
                <span className="mt-1 flex flex-wrap gap-1">
                  <Pill tone="brand">{localize(row.muscle)}</Pill>
                  <Pill>{localize(row.equipment)}</Pill>
                </span>
              </span>
              <ChevronLeft size={16} className="shrink-0 text-[var(--color-mute)] transition-transform group-hover:-translate-x-1" />
            </button>
          ))}
        </div>
      )}

      <div className="flex items-start gap-2 rounded-2xl bg-[var(--color-card)] p-3 text-[10.5px] leading-5 text-[var(--color-mute)]">
        <Info size={14} className="mt-0.5 shrink-0 text-[#c9f31c]" />
        <p>{localizeStatic("عضلهٔ انتخاب‌شده روی هر دو نمای بدن با رنگ زرد-سبز مشخص می‌شود. برای دیدن آموزش، تجهیزات و نکات هر حرکت روی کارت آن بزن.")}</p>
      </div>

      <MuscleMapCredit />

      <Modal open={!!open} onClose={() => setOpen(null)} title={localize(open?.name ?? "")} wide>
        {open && (
          <div className="grid gap-4 lg:grid-cols-2">
            <div>
              <ExVideo exerciseId={open.id} data={data} />
              <div className="mt-2 flex flex-wrap gap-1.5">
                <Pill tone="brand">{localize(open.muscle)}</Pill>
                <Pill>{localize(open.equipment)}</Pill>
                <Pill tone="info">{localize(open.level)}</Pill>
              </div>
              {variant === "coach" && <button
                type="button"
                onClick={() => {
                  if (!onGoPrograms) return;
                  setOpen(null);
                  onGoPrograms();
                  onToast(localizeStatic("برنامه‌های تمرینی"), localizeStatic("این حرکت را داخل برنامهٔ شاگرد اضافه کن"));
                }}
                className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-xl bg-[#c9f31c] py-2 text-[11.5px] font-black text-black"
              >
                <Wand2 size={13} />
                {localizeStatic("استفاده در برنامهٔ تمرینی")}
              </button>}
            </div>
            <div className="space-y-3">
              <MuscleMiniMap muscleLabel={open.muscle} gender={gender} />
              <MuscleMapCredit compact />
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
