import { localize, localizeStatic } from "../../i18n";
import { useMemo, useState } from "react";
import { genderAccent, readGender } from "../lib/gender";
import { RotateCcw, Sparkles } from "lucide-react";
import bodyPaths from "../data/body-paths.json";

/*
 * Body & muscle SVG artwork: MuscleMap — Copyright © 2026 Melih Colpan.
 * Licensed under the MIT License. The path data is reproduced from the
 * original open-source package. See the attribution panel in the UI.
 */

type Part = { slug: string; common: string[]; left: string[]; right: string[] };
type Body = { viewBox: { x: number; y: number; w: number; h: number }; parts: Part[] };
export type MapGender = "male" | "female";
export type MapView = "front" | "back";

const BODIES = bodyPaths as unknown as Record<`${MapGender}${"Front" | "Back"}`, Body>;

/** رنگ شاخص نقشه بر اساس جنسیت کاربر */
export const mapAccent = (): string => genderAccent();
export const MAP_ACCENT = "#c9f31c";
const GENDER_KEY = "revo-muscle-map-gender";

export function readMapGender(): MapGender {
  try {
    const stored = localStorage.getItem(GENDER_KEY);
    if (stored === "female" || stored === "male") return stored;
  } catch {
    /* ignore */
  }
  // پیش‌فرض: همان جنسیتی که کاربر در شروع برنامه انتخاب کرده است
  return readGender();
}

export function writeMapGender(gender: MapGender) {
  try {
    localStorage.setItem(GENDER_KEY, gender);
  } catch {
    /* ignore */
  }
}

/* ------------------------------------------------------------------ */
/* muscle groups — each group covers every overlapping sub-shape      */
/* ------------------------------------------------------------------ */

export interface MuscleGroup {
  id: string;
  fa: string;
  en: string;
  slugs: string[];
  views: MapView[];
  aliases: string[];
}

export const MUSCLE_GROUPS: MuscleGroup[] = [
  { id: "chest", fa: "سینه", en: "Chest", slugs: ["chest", "upperChest", "lowerChest"], views: ["front"], aliases: ["سینه", "chest", "pecs", "upper chest", "lower chest"] },
  { id: "shoulders", fa: "سرشانه", en: "Shoulders", slugs: ["deltoids", "frontDeltoid", "rearDeltoid"], views: ["front", "back"], aliases: ["شانه", "سرشانه", "shoulders", "deltoid", "دلتوئید"] },
  { id: "frontDelts", fa: "جلوی سرشانه", en: "Front delts", slugs: ["frontDeltoid", "deltoids"], views: ["front"], aliases: ["جلوی سرشانه", "front delt"] },
  { id: "rearDelts", fa: "پشت سرشانه", en: "Rear delts", slugs: ["rearDeltoid", "deltoids"], views: ["back"], aliases: ["پشت سرشانه", "rear delt"] },
  { id: "traps", fa: "کول", en: "Trapezius", slugs: ["trapezius", "upperTrapezius", "lowerTrapezius"], views: ["front", "back"], aliases: ["کول", "ذوزنقه", "traps", "trapezius"] },
  { id: "neck", fa: "گردن", en: "Neck", slugs: ["neck"], views: ["front", "back"], aliases: ["گردن", "neck"] },
  { id: "abs", fa: "شکم", en: "Core / abs", slugs: ["abs", "upperAbs", "lowerAbs"], views: ["front"], aliases: ["شکم", "شکم و پهلو", "core", "abs", "abdominals", "کر"] },
  { id: "obliques", fa: "پهلو", en: "Obliques", slugs: ["obliques", "serratus"], views: ["front"], aliases: ["پهلو", "obliques", "serratus", "پهلو و زیربغل"] },
  { id: "biceps", fa: "جلوبازو", en: "Biceps", slugs: ["biceps"], views: ["front"], aliases: ["جلو بازو", "جلوبازو", "biceps"] },
  { id: "triceps", fa: "پشت‌بازو", en: "Triceps", slugs: ["triceps"], views: ["front", "back"], aliases: ["پشت بازو", "پشت‌بازو", "triceps"] },
  { id: "forearm", fa: "ساعد", en: "Forearm", slugs: ["forearm"], views: ["front", "back"], aliases: ["ساعد", "forearm", "forearms"] },
  { id: "upperBack", fa: "زیربغل", en: "Upper back / lats", slugs: ["upperBack", "rhomboids", "rotatorCuff"], views: ["back"], aliases: ["پشت", "زیربغل", "لات", "upper back", "lats", "back", "rhomboids", "rotator cuff"] },
  { id: "lowerBack", fa: "کمر", en: "Lower back", slugs: ["lowerBack"], views: ["back"], aliases: ["کمر", "lower back", "lumbar"] },
  { id: "glutes", fa: "باسن", en: "Glutes", slugs: ["gluteal"], views: ["back"], aliases: ["باسن", "سرینی", "glutes", "glute", "gluteal"] },
  { id: "quads", fa: "چهارسر ران", en: "Quadriceps", slugs: ["quadriceps", "innerQuad", "outerQuad"], views: ["front"], aliases: ["پا", "چهارسر", "چهارسر ران", "ران", "quads", "quadriceps", "legs", "leg"] },
  { id: "adductors", fa: "داخل ران", en: "Adductors", slugs: ["adductors", "innerQuad"], views: ["front", "back"], aliases: ["داخل ران", "کشاله", "adductors", "inner thigh"] },
  { id: "hamstrings", fa: "همسترینگ (پشت ران)", en: "Hamstrings", slugs: ["hamstring"], views: ["back"], aliases: ["همسترینگ", "پشت ران", "خم‌کننده ران", "خم‌کننده‌ی ران", "hamstrings", "hamstring"] },
  { id: "hipFlexors", fa: "خم‌کنندهٔ ران", en: "Hip flexors", slugs: ["hipFlexors"], views: ["front"], aliases: ["خم‌کننده لگن", "hip flexors", "hip flexor"] },
  { id: "calves", fa: "ساق", en: "Calves", slugs: ["calves"], views: ["front", "back"], aliases: ["ساق", "ساق پا", "calves", "calf"] },
  { id: "tibialis", fa: "جلوی ساق", en: "Tibialis", slugs: ["tibialis"], views: ["front"], aliases: ["جلوی ساق", "tibialis", "shin"] },
];

export const GROUP_BY_ID = new Map(MUSCLE_GROUPS.map((group) => [group.id, group]));

const GROUP_BY_SLUG = new Map<string, string>();
MUSCLE_GROUPS.forEach((group) => group.slugs.forEach((slug) => GROUP_BY_SLUG.set(slug, group.id)));

/** exercise data labels → map groups (supports coach custom labels) */
const FULL_BODY = ["chest", "shoulders", "upperBack", "abs", "quads", "hamstrings", "glutes", "triceps", "biceps"];

export function groupsForMuscleLabel(label: string): MuscleGroup[] {
  const value = String(label || "").trim().toLowerCase();
  if (!value) return [];
  if (value === "تمام بدن" || value === "full body") {
    return FULL_BODY.map((id) => GROUP_BY_ID.get(id)).filter((group): group is MuscleGroup => !!group);
  }
  const exact = MUSCLE_GROUPS.filter((group) => group.aliases.some((alias) => alias.toLowerCase() === value));
  if (exact.length) return exact;
  const partial = MUSCLE_GROUPS.filter((group) => group.aliases.some((alias) => value.includes(alias.toLowerCase()) || alias.toLowerCase().includes(value)));
  return partial;
}

export function groupIdsForMuscleLabel(label: string): string[] {
  return [...new Set(groupsForMuscleLabel(label).map((group) => group.id))];
}

/* artwork tone map: keeps the original anatomical reading of the drawing */
const COSMETIC = new Set(["head", "hair"]);
const JOINT = new Set(["knees", "ankles"]);
const EXTREMITY = new Set(["hands", "feet"]);
const DEEP = new Set(["neck", "forearm", "adductors", "hipFlexors", "tibialis", "serratus"]);

function baseFill(slug: string): string {
  if (slug === "hair") return "#242a32";
  if (slug === "head") return "#3a424d";
  if (JOINT.has(slug)) return "#4b545f";
  if (EXTREMITY.has(slug)) return "#363e48";
  if (DEEP.has(slug)) return "#69737f";
  return "#818c99";
}

/* ------------------------------------------------------------------ */
/* single body figure                                                  */
/* ------------------------------------------------------------------ */

export function BodyFigure({
  gender, view, active = [], hovered = [], onPick, className = "", layered = true,
}: {
  gender: MapGender;
  view: MapView;
  active?: string[];
  hovered?: string[];
  onPick?: (groupId: string) => void;
  className?: string;
  layered?: boolean;
}) {
  const body = BODIES[`${gender}${view === "front" ? "Front" : "Back"}`];
  const activeSlugs = useMemo(() => {
    const set = new Set<string>();
    [...active, ...hovered].forEach((id) => GROUP_BY_ID.get(id)?.slugs.forEach((slug) => set.add(slug)));
    return set;
  }, [active, hovered]);
  const softSlugs = useMemo(() => {
    const set = new Set<string>();
    hovered.filter((id) => !active.includes(id)).forEach((id) => GROUP_BY_ID.get(id)?.slugs.forEach((slug) => set.add(slug)));
    return set;
  }, [active, hovered]);

  const { x, y, w, h } = body.viewBox;
  const hair = body.parts.filter((part) => COSMETIC.has(part.slug));
  const rest = body.parts.filter((part) => !COSMETIC.has(part.slug));

  const draw = (part: Part, cosmetic: boolean) => {
    const paths = [...part.common, ...part.left, ...part.right];
    if (!paths.length) return null;
    const groupId = GROUP_BY_SLUG.get(part.slug);
    const selected = activeSlugs.has(part.slug);
    const soft = softSlugs.has(part.slug);
    return (
      <g
        key={part.slug}
        className={groupId && onPick ? "muscle-part cursor-pointer" : "muscle-part"}
        onClick={groupId && onPick ? () => onPick(groupId) : undefined}
        role={groupId ? "button" : undefined}
        aria-label={groupId ? localize(GROUP_BY_ID.get(groupId)?.fa ?? "") : undefined}
        style={{ pointerEvents: cosmetic || !groupId ? "none" : "auto" }}
      >
        {paths.map((d, index) => (
          <path
            key={index}
            d={d}
            fill={selected ? mapAccent() : soft ? (readGender() === "female" ? "#b96382" : "#a9be55") : baseFill(part.slug)}
            fillOpacity={soft && !selected ? 0.65 : 1}
            stroke="#12171d"
            strokeWidth={part.slug === "hair" ? 0.8 : 1.15}
            strokeLinejoin="round"
            vectorEffect="non-scaling-stroke"
          />
        ))}
      </g>
    );
  };

  return (
    <svg
      viewBox={`${x} ${y} ${w} ${h}`}
      className={`h-full w-full overflow-visible transition-opacity duration-300 ${className}`}
      role="img"
      aria-label={localize(`${gender === "male" ? "مرد" : "زن"} — ${view === "front" ? "نمای روبه‌رو" : "نمای پشت"}`)}
    >
      <g style={layered ? { filter: "drop-shadow(0 18px 26px rgba(0,0,0,0.45))" } : undefined}>
        {[...rest, ...hair].map((part) => draw(part, COSMETIC.has(part.slug)))}
      </g>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* compact anatomy widget (exercise detail modals)                     */
/* ------------------------------------------------------------------ */

export function MuscleMiniMap({
  muscleLabel, gender, className = "",
}: {
  muscleLabel: string;
  gender: MapGender;
  className?: string;
}) {
  const groups = groupsForMuscleLabel(muscleLabel);
  const ids = groups.map((group) => group.id);
  const views = new Set(groups.flatMap((group) => group.views));
  const both = views.size !== 1;
  return (
    <div className={`rounded-2xl border border-[var(--color-line)] bg-[var(--color-bg)] p-2.5 ${className}`}>
      <div className="mb-1.5 flex items-center justify-between gap-2 px-1">
        <b className="flex items-center gap-1.5 text-[11px] text-[var(--color-ink)]">
          <Sparkles size={12} className="text-[#a7c81a]" />
          {localizeStatic("عضلات هدف")}
        </b>
        <span className="truncate text-[10px] font-bold text-[#a7c81a]">{localize(muscleLabel)}</span>
      </div>
      <div className="grid grid-cols-2 gap-1.5">
        {(both ? (["front", "back"] as MapView[]) : [...views] as MapView[]).map((view) => (
          <div key={view} className="rounded-xl bg-[#0d1117] px-1 py-1.5">
            <div className="mx-auto h-[150px] w-full">
              <BodyFigure gender={gender} view={view} active={ids} layered={false} />
            </div>
            <span className="mt-0.5 block text-center text-[8.5px] font-bold text-[#7d8794]">
              {localizeStatic(view === "front" ? "روبه‌رو" : "پشت")}
            </span>
          </div>
        ))}
      </div>
      <p className="mt-1.5 text-center text-[8px] leading-4 text-[var(--color-mute)]" dir="ltr">
        MuscleMap © 2026 Melih Colpan · MIT
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* full interactive map + group chips                                  */
/* ------------------------------------------------------------------ */

export function MuscleMapPanel({
  gender, onGender, selected, onSelect, counts, locked = false,
}: {
  gender: MapGender;
  onGender: (gender: MapGender) => void;
  selected: string | null;
  onSelect: (id: string | null) => void;
  counts?: Record<string, number>;
  /** جنسیت ثابت (شاگرد) — فقط نمایش برچسب، بدون تغییر */
  locked?: boolean;
}) {
  const [hovered, setHovered] = useState<string | null>(null);
  const active = selected ? [selected] : [];
  const hoverView = hovered ? GROUP_BY_ID.get(hovered)?.fa : undefined;

  const pick = (id: string | null) => {
    setHovered(null);
    onSelect(id);
  };

  return (
    <section data-guide="muscle-map" className="overflow-hidden rounded-[26px] border border-[var(--color-line)] bg-[var(--color-card)]">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--color-line)] px-3 py-2.5 sm:px-4">
        <div className="flex items-center gap-2">
          <div className="flex rounded-full bg-[var(--color-bg)] p-0.5" role="group" aria-label={localizeStatic("جنسیت نقشه")}>
            {(["female", "male"] as MapGender[]).map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => {
                  if (locked) return;
                  writeMapGender(option);
                  onGender(option);
                }}
                disabled={locked && gender !== option}
                className={`rounded-full px-3 py-1.5 text-[11px] font-black transition ${gender === option ? "bg-[#c9f31c] text-black shadow-[0_8px_20px_-10px_rgba(201,243,28,0.9)]" : "text-[var(--color-mute)] hover:text-[var(--color-ink)]"} ${locked && gender !== option ? "cursor-default opacity-35 hover:text-[var(--color-mute)]" : ""}`}
                aria-pressed={gender === option}
              >
                {localizeStatic(option === "female" ? "بانوان" : "آقایان")}
              </button>
            ))}
          </div>
          <span className="hidden text-[10.5px] font-bold text-[var(--color-mute)] sm:block">
            {localizeStatic(gender === "female" ? "آناتومی بانوان" : "آناتومی آقایان")}
          </span>
        </div>
        <button
          type="button"
          onClick={() => pick(null)}
          className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1.5 text-[10.5px] font-black transition ${selected === null ? "border-[#c9f31c]/60 bg-[#c9f31c]/10 text-[#c9f31c]" : "border-[var(--color-line)] text-[var(--color-mute)] hover:text-[var(--color-ink)]"}`}
        >
          <RotateCcw size={12} />
          {localizeStatic("همه‌ی عضلات")}
        </button>
      </div>

      <div className="relative grid grid-cols-2 gap-1 bg-[#0d1117] px-1.5 pb-2 pt-2 sm:gap-3 sm:px-4">
        {(["front", "back"] as MapView[]).map((view) => (
          <div key={view} className="flex min-w-0 flex-col items-center">
            <div className="h-[300px] w-full sm:h-[360px] lg:h-[400px]">
              <BodyFigure
                gender={gender}
                view={view}
                active={active}
                hovered={hovered ? [hovered] : []}
                onPick={(id) => {
                  setHovered(null);
                  onSelect(selected === id ? null : id);
                }}
              />
            </div>
            <span className="mt-1 rounded-full bg-white/[0.04] px-2.5 py-1 text-[9.5px] font-bold text-[#858f9b]">
              {localizeStatic(view === "front" ? "نمای روبه‌رو" : "نمای پشت")}
            </span>
          </div>
        ))}
        <div className="pointer-events-none absolute inset-y-3 left-1/2 w-px -translate-x-1/2 bg-gradient-to-b from-transparent via-white/[0.07] to-transparent" aria-hidden="true" />
        <div className="pointer-events-none absolute bottom-2 left-2 flex items-center gap-1.5 rounded-full bg-black/40 px-2 py-1 text-[8.5px] font-bold text-white/60 backdrop-blur">
          <span className="h-2 w-2 rounded-full bg-[#c9f31c]" />
          {localizeStatic("عضلهٔ انتخاب‌شده")}
        </div>
        {hoverView && (
          <div className="pointer-events-none absolute left-1/2 top-2 -translate-x-1/2 rounded-full border border-[#c9f31c]/30 bg-black/70 px-3 py-1 text-[10px] font-black text-[#c9f31c] backdrop-blur">
            {localize(hoverView)}
          </div>
        )}
      </div>

      <div className="grid grid-cols-3 gap-1.5 border-t border-[var(--color-line)] p-2.5 sm:grid-cols-4 sm:gap-2 sm:p-3 lg:grid-cols-5">
        {MUSCLE_GROUPS.map((group) => {
          const isSelected = selected === group.id;
          return (
            <button
              key={group.id}
              type="button"
              onClick={() => pick(isSelected ? null : group.id)}
              onMouseEnter={() => setHovered(group.id)}
              onMouseLeave={() => setHovered(null)}
              onFocus={() => setHovered(group.id)}
              onBlur={() => setHovered(null)}
              aria-pressed={isSelected}
              className={`inline-flex min-h-[38px] items-center justify-center gap-1.5 rounded-full border px-2 py-2 text-[10.5px] font-bold transition sm:min-h-[42px] sm:text-[11.5px] ${
                isSelected
                  ? "border-[#c9f31c] bg-[#c9f31c] text-black"
                  : "border-[var(--color-line)] bg-[var(--color-bg)] text-[#aeb6c0] hover:border-[#c9f31c]/45 hover:text-[var(--color-ink)]"
              }`}
            >
              {localize(group.fa)}
              {typeof counts?.[group.id] === "number" && (
                <span className={`tnum rounded-full px-1 text-[8.5px] ${isSelected ? "bg-black/15 text-black" : "bg-white/[0.06] text-[var(--color-mute)]"}`}>
                  {counts[group.id]}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* attribution — MIT                                                   */
/* ------------------------------------------------------------------ */

export function MuscleMapCredit({ compact = false }: { compact?: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <footer className="rounded-2xl border border-[var(--color-line)] bg-[var(--color-card)] p-3 text-[10.5px] leading-5 text-[var(--color-mute)]">
      <p>
        {localizeStatic("نقشهٔ بدن و مسیرهای عضلانی از پروژهٔ ")}
        <a href="https://github.com/melihcolpan/MuscleMap" target="_blank" rel="noreferrer" className="font-black text-[var(--color-ink)] underline decoration-[#c9f31c]/60 underline-offset-2 hover:text-[#c9f31c]">
          MuscleMap
        </a>
        {localizeStatic(" ساختهٔ Melih Colpan است و تحت مجوز MIT استفاده می‌شود.")}
      </p>
      <p className="mt-1 font-bold text-[var(--color-ink)]" dir="ltr">Copyright (c) 2026 Melih Colpan</p>
      {!compact && (
        <>
          <button type="button" onClick={() => setOpen((value) => !value)} className="mt-1 font-black text-[#a7c81a] hover:underline">
            {localizeStatic(open ? "بستن متن مجوز" : "مشاهدهٔ متن کامل مجوز MIT")}
          </button>
          {open && (
            <pre className="mt-2 max-h-52 overflow-auto whitespace-pre-wrap rounded-xl bg-[var(--color-bg)] p-3 text-[9.5px] leading-5 text-[var(--color-mute)]" dir="ltr">
{`MIT License

Copyright (c) 2026 Melih Colpan

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.`}
            </pre>
          )}
        </>
      )}
      {compact && <p className="mt-0.5 text-[9px]" dir="ltr">MIT License</p>}
    </footer>
  );
}
