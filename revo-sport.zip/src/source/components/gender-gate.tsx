import { localizeStatic } from "../../i18n";
import { GENDER_INTRO_IMAGE } from "../data/gender-exercises";
import { writeGender, type Gender } from "../lib/gender";
import "./gender-gate.css";

/**
 * دروازهٔ انتخاب جنسیت در شروع برنامه: تا انتخاب نشود ادامه پیدا نمی‌کند.
 * انتخاب در localStorage ذخیره می‌شود و رسانه‌ها، پوسته و پیش‌فرض‌های
 * تمرینی را برای هر جنسیت متمایز می‌کند.
 */
export default function GenderGate({ onChoose }: { onChoose: (gender: Gender) => void }) {
  const choose = (gender: Gender) => {
    writeGender(gender);
    try {
      document.documentElement.setAttribute("data-gender", gender);
    } catch {
      /* ignore */
    }
    onChoose(gender);
  };

  return (
    <div className="gender-gate" role="dialog" aria-modal="true" aria-labelledby="gender-gate-title">
      <div className="gender-gate-glow" aria-hidden="true" />
      <header className="gender-gate-head">
        <h2 id="gender-gate-title">{localizeStatic("تجربه‌ای متناسب با شما")}</h2>
        <p>{localizeStatic("برای نمایش حرکات، ویدیوها و پیش‌فرض‌های تمرینی مناسب، جنسیت خود را انتخاب کنید.")}</p>
      </header>

      <div className="gender-gate-cards">
        <button type="button" className="gender-card is-male" onClick={() => choose("male")}>
          <img src={GENDER_INTRO_IMAGE.male} alt="" draggable={false} />
          <span className="gender-card-shade" aria-hidden="true" />
          <span className="gender-card-body">
            <b>{localizeStatic("آقایان")}</b>
            <small>{localizeStatic("تمرکز بر عضله‌سازی، قدرت و حجم")}</small>
            <em>{localizeStatic("ورود")}</em>
          </span>
        </button>

        <button type="button" className="gender-card is-female" onClick={() => choose("female")}>
          <img src={GENDER_INTRO_IMAGE.female} alt="" draggable={false} />
          <span className="gender-card-shade" aria-hidden="true" />
          <span className="gender-card-body">
            <b>{localizeStatic("بانوان")}</b>
            <small>{localizeStatic("تمرکز بر فرم‌دهی، باسن و پایین‌تنه")}</small>
            <em>{localizeStatic("ورود")}</em>
          </span>
        </button>
      </div>

      <p className="gender-gate-foot">{localizeStatic("این انتخاب بعداً از بخش تنظیمات قابل تغییر است.")}</p>
    </div>
  );
}
