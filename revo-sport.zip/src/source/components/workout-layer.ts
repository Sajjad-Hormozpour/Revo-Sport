import { useEffect, useRef, type RefObject } from "react";

/** Keep modal focus local without inheriting the animated page's fixed container. */
export function useWorkoutLayer(panel: RefObject<HTMLElement | null>, onClose: () => void, backgroundSelector?: string, enabled = true) {
  const close = useRef(onClose);
  close.current = onClose;
  useEffect(() => {
    if (!enabled) return;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const background = backgroundSelector ? document.querySelector<HTMLElement>(backgroundSelector) : null;
    const wasInert = background?.inert ?? false;
    if (background) background.inert = true;
    const keydown = (event: KeyboardEvent) => {
      if (panel.current?.inert) return;
      const dialogs = [...document.querySelectorAll<HTMLElement>('[role="dialog"][aria-modal="true"]')]
        .filter((element) => element.offsetWidth > 0 && !element.closest('[inert]'));
      if (dialogs.length && dialogs[dialogs.length - 1] !== panel.current) return;
      const focusedDialog = document.activeElement?.closest('[role="dialog"]');
      if (focusedDialog && focusedDialog !== panel.current) return;
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopImmediatePropagation();
        close.current();
      }
      if (event.key === "Tab") {
        const controls = [...(panel.current?.querySelectorAll<HTMLElement>("button:not(:disabled), input:not(:disabled), select:not(:disabled), [tabindex='0']") ?? [])]
          .filter((element) => element.offsetWidth > 0 && !element.closest("[inert]"));
        if (!controls.length) return;
        const index = controls.indexOf(document.activeElement as HTMLElement);
        if (event.shiftKey && index <= 0) {
          event.preventDefault();
          controls[controls.length - 1].focus({ preventScroll: true });
        } else if (!event.shiftKey && (index === -1 || index === controls.length - 1)) {
          event.preventDefault();
          controls[0].focus({ preventScroll: true });
        }
      }
    };
    document.addEventListener("keydown", keydown, true);
    const frame = requestAnimationFrame(() => panel.current?.focus({ preventScroll: true }));
    return () => {
      cancelAnimationFrame(frame);
      document.removeEventListener("keydown", keydown, true);
      if (background) background.inert = wasInert;
      if (previousFocus?.isConnected && !previousFocus.closest("[inert]")) previousFocus.focus({ preventScroll: true });
    };
  }, [backgroundSelector, enabled, panel]);
}