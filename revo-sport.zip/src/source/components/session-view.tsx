import { currentLanguage, localize, localizeStatic } from "../../i18n";
import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  BookOpen, Check, ChevronDown, ChevronLeft, ChevronRight, Crosshair, Minus, MoreHorizontal, Play, Plus,
  Timer, Zap,
} from "lucide-react";
import type { AppData } from "../data/types";
import { fa, formatClock } from "../lib/core";
import { useNow } from "../lib/time";
import { ExThumb } from "./exercise";

/** ساعت زندهٔ ایزوله — هر ثانیه فقط خودش رندر می‌شود، نه کل صفحه */
export function SessionClock({ startedAt, className = "" }: { startedAt: string | null; className?: string }) {
  const now = useNow(1000);
  if (!startedAt) return null;
  const secs = Math.max(0, Math.floor((now.getTime() - new Date(startedAt).getTime()) / 1000));
  return <span className={`tnum tracking-wider ${className}`}>{localize(formatClock(secs))}</span>;
}

export type SetKind = "normal" | "warmup" | "drop" | "failure";

/** خروجی‌های یک ست در جلسهٔ تمرین */
export interface SessionSetValue {
  weight: string;
  reps: string;
  rir: string;
  tag?: SetKind;
}

export interface SessionMenuItem {
  label: string;
  icon?: ReactNode;
  onClick: () => void;
  danger?: boolean;
}

/* ------------------------------------------------------------------ */
/* small internals                                                     */
/* ------------------------------------------------------------------ */

function Menu({ items, label, align = "start" }: { items: SessionMenuItem[]; label: string; align?: "start" | "end" }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const close = (event: MouseEvent) => {
      if (!ref.current?.contains(event.target as Node)) setOpen(false);
    };
    const esc = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", esc);
    };
  }, [open]);

  if (!items.length) return null;

  return (
    <div className="relative shrink-0" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-label={label}
        aria-expanded={open}
        className={`press flex h-9 w-9 items-center justify-center rounded-full text-[#8f96a0] transition hover:bg-white/[0.06] hover:text-white ${open ? "bg-white/[0.06] text-white" : ""}`}
      >
        <MoreHorizontal size={20} />
      </button>
      {localize(open && (
        <div className={`absolute top-10 z-40 w-52 overflow-hidden rounded-2xl border border-white/10 bg-[#1c2027] p-1.5 text-right shadow-[0_24px_60px_-20px_rgba(0,0,0,0.9)] ${align === "end" ? "right-0" : "left-0"}`}>
          {localize(items.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => {
                setOpen(false);
                item.onClick();
              }}
              className={`flex w-full items-center gap-2 rounded-xl px-2.5 py-2.5 text-[11.5px] font-bold transition hover:bg-white/[0.06] ${item.danger ? "text-red-400" : "text-white/80"}`}
            >
              {item.icon}
              <span className="min-w-0 flex-1 text-right">{localize(item.label)}</span>
            </button>
          )))}
        </div>
      ))}
    </div>
  );
}

function Stepper({
  label, minusLabel, plusLabel, onMinus, onPlus, disabled,
}: {
  label: string;
  minusLabel: string;
  plusLabel: string;
  onMinus: () => void;
  onPlus: () => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex h-[44px] items-center justify-between rounded-[15px] bg-[#1c1d18] px-1" dir={currentLanguage() === "fa" ? "rtl" : "ltr"}>
      <button
        type="button"
        onClick={onMinus}
        disabled={disabled}
        aria-label={minusLabel}
        className="press flex h-9 w-10 items-center justify-center rounded-xl text-white/75 transition hover:bg-white/[0.07] disabled:opacity-35"
      >
        <Minus size={17} strokeWidth={2.4} />
      </button>
      <span className="text-[11px] font-bold text-white/55">{localize(label)}</span>
      <button
        type="button"
        onClick={onPlus}
        disabled={disabled}
        aria-label={plusLabel}
        className="press flex h-9 w-10 items-center justify-center rounded-xl text-white/75 transition hover:bg-white/[0.07] disabled:opacity-35"
      >
        <Plus size={17} strokeWidth={2.4} />
      </button>
    </div>
  );
}

const cellCls =
  "tnum flex h-[46px] w-full min-w-0 items-center justify-center rounded-[14px] bg-[#23282f] px-1 text-center text-[17px] font-black text-white transition focus:bg-[#2a2f28] focus:outline-none";

/* ------------------------------------------------------------------ */
/* session header                                                      */
/* ------------------------------------------------------------------ */

export function SessionHeader({
  title, subtitle, timer, done, total, volume, onFinish, menuItems, collapsed, onToggleCollapse,
  started = true, onStart, focusMode, onToggleFocus, current, totalExercises,
}: {
  title: string;
  subtitle: string;
  /** ساعت زنده — به‌صورت کامپوننت پاس داده می‌شود تا هر ثانیه فقط خودش رندر شود */
  timer?: ReactNode;
  done: number;
  total: number;
  volume?: number;
  onFinish: () => void;
  menuItems: SessionMenuItem[];
  collapsed?: boolean;
  onToggleCollapse?: () => void;
  /** قبل از شروع جلسه: دکمهٔ پایان جای خود را با دکمهٔ شروع می‌دهد */
  started?: boolean;
  onStart?: () => void;
  focusMode?: boolean;
  onToggleFocus?: () => void;
  /** شمارهٔ حرکت فعلی و تعداد کل حرکات جلسه (برای نمایش مرحله) */
  current?: number;
  totalExercises?: number;
}) {
  const pct = total ? Math.min(100, (done / total) * 100) : 0;
  const exPct = totalExercises ? Math.min(100, ((current ?? 1) / totalExercises) * 100) : 0;
  return (
    <header
      data-guide="workout-header"
      className={`relative overflow-hidden rounded-[24px] border px-2.5 pb-3 pt-2.5 transition-colors duration-500 ${
        focusMode && started
          ? "border-[#e9e400]/25 bg-[#101105] shadow-[0_0_40px_-18px_rgba(233,228,0,0.55)]"
          : "border-white/[0.06] bg-[#0a0b0a]"
      }`}
    >
      {/* درخشش ملایم در حالت تمرکز */}
      {focusMode && started && (
        <div className="pointer-events-none absolute -top-10 left-1/2 h-24 w-56 -translate-x-1/2 rounded-full bg-[#e9e400]/10 blur-2xl" aria-hidden="true" />
      )}
      <div className="relative flex items-center gap-1.5">
        <div className="flex shrink-0 items-center gap-0.5">
          <Menu items={menuItems} align="end" label={localizeStatic("گزینه‌های جلسه")} />
          {onToggleFocus && started && (
            <button
              type="button"
              onClick={onToggleFocus}
              aria-pressed={focusMode}
              aria-label={localizeStatic(focusMode ? "خروج از حالت تمرکز" : "حالت تمرکز کامل")}
              title={localizeStatic(focusMode ? "خروج از حالت تمرکز" : "حالت تمرکز کامل")}
              className={`press flex h-9 w-9 items-center justify-center rounded-full transition ${
                focusMode
                  ? "bg-[#e9e400]/15 text-[#e9e400]"
                  : "text-[#8f96a0] hover:bg-white/[0.06] hover:text-white"
              }`}
            >
              <Crosshair size={18} />
            </button>
          )}
          {onToggleCollapse && (
            <button
              type="button"
              onClick={onToggleCollapse}
              aria-label={localizeStatic(collapsed ? "باز کردن جلسه" : "جمع کردن جلسه")}
              aria-expanded={!collapsed}
              className="press flex h-9 w-8 items-center justify-center rounded-full text-[#8f96a0] transition hover:bg-white/[0.06] hover:text-white"
            >
              <ChevronDown size={20} className={`transition-transform duration-300 ${collapsed ? "" : "rotate-180"}`} />
            </button>
          )}
        </div>

        <div className="min-w-0 flex-1 text-center">
          <h1 className="truncate text-[18px] font-black leading-6 text-white sm:text-[19px]">{localize(title)}</h1>
          <p className="mt-0.5 flex items-center justify-center gap-1.5 truncate text-[10.5px] font-medium text-[#8f96a0]">
            <span className="tnum">{localize(subtitle)}</span>
            {timer && (
              <>
                <span className="text-white/20">•</span>
                {timer}
              </>
            )}
            {typeof volume === "number" && volume > 0 && (
              <>
                <span className="text-white/20">•</span>
                <span className="tnum">{localize(fa(Math.round(volume)))}{localizeStatic(" kg")}</span>
              </>
            )}
          </p>
        </div>

        {started ? (
          <button
            type="button"
            onClick={onFinish}
            className="press relative flex h-[48px] min-w-[84px] shrink-0 items-center justify-center overflow-hidden rounded-[17px] bg-[#e9e400] px-4 text-[13.5px] font-black text-black shadow-[0_16px_36px_-18px_rgba(233,228,0,0.8)] transition hover:brightness-105 active:scale-[0.98]"
          >
            <span className="absolute inset-0 -translate-x-full bg-gradient-to-l from-transparent via-white/40 to-transparent [animation:shine_2.6s_ease-in-out_infinite]" aria-hidden="true" />
            {localizeStatic("پایان")}
          </button>
        ) : (
          <button
            type="button"
            onClick={onStart}
            className="press relative flex h-[48px] min-w-[96px] shrink-0 items-center justify-center gap-1.5 overflow-hidden rounded-[17px] bg-[#e9e400] px-4 text-[13.5px] font-black text-black shadow-[0_16px_36px_-18px_rgba(233,228,0,0.8)] transition hover:brightness-105 active:scale-[0.98]"
          >
            <span className="absolute inset-0 -translate-x-full bg-gradient-to-l from-transparent via-white/40 to-transparent [animation:shine_2.2s_ease-in-out_infinite]" aria-hidden="true" />
            <Play size={15} fill="currentColor" />
            {localizeStatic("شروع")}
          </button>
        )}
      </div>

      {/* نوار پیشرفت ست‌ها */}
      <div className="relative mt-3 flex items-center gap-2 px-1">
        <div className="h-[6px] min-w-0 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
          <div
            className="h-full rounded-full bg-gradient-to-l from-[#fff35c] to-[#d9d200] transition-all duration-500 ease-out"
            style={{ width: `${pct}%` }}
          />
        </div>
        <span className="tnum shrink-0 text-[9.5px] font-bold text-[#8f96a0]">{localize(fa(Math.round(pct)))}٪</span>
      </div>

      {/* نوار پیشرفت حرکات جلسه (مرحلهٔ فعلی) */}
      {typeof totalExercises === "number" && totalExercises > 1 && (
        <div className="relative mt-2 flex items-center gap-2 px-1">
          <span className="shrink-0 text-[9px] font-bold text-[#8f96a0]">
            {localizeStatic("حرکت")} {localize(fa(current ?? 1))}/{localize(fa(totalExercises))}
          </span>
          <div className="h-[4px] min-w-0 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
            <div
              className="h-full rounded-full bg-white/70 transition-all duration-500 ease-out"
              style={{ width: `${exPct}%` }}
            />
          </div>
        </div>
      )}
    </header>
  );
}

/* ------------------------------------------------------------------ */
/* exercise card                                                       */
/* ------------------------------------------------------------------ */

export function SessionExerciseCard({
  index, exerciseId, name, muscle, equipment, data, sets, reps, rir, note,
  values, done, activeSet, mode, onField, onRir, onToggle, onGuide, onEditSet, menuItems,
  rest, tempo, extra, totalExercises,
}: {
  index: number;
  exerciseId: string;
  name: string;
  muscle: string;
  equipment: string;
  data?: AppData;
  sets: number;
  reps: string;
  rir: string;
  note?: string;
  values: SessionSetValue[];
  done: boolean[];
  activeSet: number;
  mode: "log" | "prescribe";
  onField?: (setIndex: number, field: "weight" | "reps", value: string) => void;
  onRir?: (setIndex: number, value: string) => void;
  onToggle?: (setIndex: number) => void;
  onGuide?: () => void;
  onEditSet?: (setIndex: number) => void;
  menuItems?: SessionMenuItem[];
  rest?: number;
  tempo?: string;
  extra?: ReactNode;
  /** تعداد کل حرکات جلسه — برای نمایش مرحلهٔ فعلی */
  totalExercises?: number;
}) {
  const doneCount = done.filter(Boolean).length;
  const readOnly = mode === "prescribe";

  const step = (field: "weight" | "reps", delta: number) => {
    if (!onField) return;
    const target = sets > 1 || doneCount > 0 ? activeSet : 0;
    const raw = String(values[target]?.[field] ?? "").replace(/[^\d.]/g, "");
    // وزن با گام ۲.۵ کیلو و تکرار با گام ۱ تغییر می‌کند
    const amount = field === "weight" ? 2.5 : 1;
    const next = Math.max(0, Math.round(((Number(raw) || 0) + delta * amount) * 10) / 10);
    onField(target, field, next ? String(next) : "");
  };

  const allDone = sets > 0 && doneCount === sets;
  const isLastExercise = typeof totalExercises === "number" && index >= totalExercises;

  return (
    <article className="mx-auto w-full max-w-[560px] rounded-[24px] border border-white/[0.07] bg-[#101110] px-2.5 pb-2.5 pt-2 text-right shadow-[0_24px_60px_-42px_rgba(0,0,0,0.95)] transition-colors duration-300">
      {/* نوار مرحلهٔ جلسه (حرکت فعلی از کل) */}
      {typeof totalExercises === "number" && totalExercises > 1 && (
        <div className="mb-2 flex items-center gap-2 px-0.5">
          <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-[#e9e400]/12 px-2 py-0.5 text-[9.5px] font-black text-[#e9e400]">
            <Zap size={10} fill="currentColor" />
            {localizeStatic("مرحله")} {localize(fa(index))}/{localize(fa(totalExercises))}
          </span>
          <div className="flex min-w-0 flex-1 items-center gap-1" aria-hidden="true">
            {Array.from({ length: totalExercises }).map((_, i) => (
              <span
                key={i}
                className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                  i < index - 1 ? "bg-[#e9e400]" : i === index - 1 ? "bg-[#e9e400]/80" : "bg-white/12"
                }`}
              />
            ))}
          </div>
        </div>
      )}

      {/* title + media */}
      <div data-guide="exercise-heading" className="flex items-start gap-1.5">
        <div className="h-[70px] w-[80px] shrink-0 overflow-hidden rounded-[17px] border border-white/[0.05] bg-black/30">
          <ExThumb exerciseId={exerciseId} data={data} className="h-full w-full object-cover" />
        </div>
        <div className="min-w-0 flex-1 pt-1">
          <h2 className="text-balance text-[16px] font-black leading-6 text-white">
            <span className="tnum ml-1 text-[#8f96a0]">{localize(fa(index))}</span>
            {localize(name)}
          </h2>
          <div className="mt-1.5 flex items-center gap-2">
            {onGuide && (
              <button
                type="button"
                onClick={onGuide}
                className="press inline-flex h-[26px] items-center gap-1.5 rounded-lg border border-white/[0.09] bg-white/[0.04] px-2 text-[10px] font-bold text-[#b6bdc6] transition hover:border-[#e9e400]/40 hover:text-[#e9e400]"
              >
                <BookOpen size={11.5} />
                {localizeStatic("آموزش")}
              </button>
            )}
            {/* پیشرفت ست‌های این حرکت */}
            <div className="flex min-w-0 flex-1 items-center gap-1.5">
              <div className="h-[4px] min-w-0 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
                <div
                  className="h-full rounded-full bg-[#e9e400] transition-all duration-500 ease-out"
                  style={{ width: `${sets ? (doneCount / sets) * 100 : 0}%` }}
                />
              </div>
              <span className="tnum shrink-0 text-[9px] font-bold text-[#8f96a0]">
                {localize(fa(doneCount))}/{localize(fa(sets))}
              </span>
            </div>
          </div>
        </div>
        <Menu items={menuItems ?? []} label={localizeStatic("گزینه‌های حرکت")} />
      </div>

      {/* tags + prescription */}
      <div className="mt-2 flex flex-wrap items-center justify-center gap-1.5">
        <span className="rounded-full bg-white/[0.055] px-3 py-1 text-[10.5px] font-medium text-[#c7cdd5]">{localize(muscle)}</span>
        <span className="rounded-full bg-white/[0.055] px-3 py-1 text-[10.5px] font-medium text-[#c7cdd5]">{localize(equipment)}</span>
        {typeof rest === "number" && rest > 0 && (
          <span className="rounded-full border border-[#e9e400]/25 bg-[#e9e400]/[0.08] px-3 py-1 text-[10.5px] font-bold text-[#e9e400]">
            {localizeStatic("استراحت ")}{localize(fa(rest))}{localizeStatic(" ثانیه")}
          </span>
        )}
        {tempo && (
          <span className="rounded-full bg-white/[0.055] px-3 py-1 text-[10.5px] font-medium text-[#c7cdd5]">
            Tempo {localize(tempo)}
          </span>
        )}
      </div>
      <div className="mt-2.5 flex flex-wrap items-center justify-center gap-2 text-[12.5px] font-black text-white/90">
        <span className="tnum flex items-center gap-1">
          {localize(fa(sets))} {localizeStatic("ست")}
          <span className="text-white/30">×</span>
          <span className="tnum">{localize(reps)}</span>
          <span className="text-white/60">{localizeStatic("تکرار")}</span>
        </span>
        <span className="tnum inline-flex h-[26px] items-center rounded-full bg-white/[0.055] px-2.5 text-[10.5px] font-bold text-[#c7cdd5]">
          RIR {localize(rir)}
        </span>
      </div>

      {note && (
        <p className="mt-2.5 rounded-[16px] bg-[#171814] px-3 py-2.5 text-[11px] font-medium leading-6 text-white/75">
          {localize(note)}
        </p>
      )}

      {/* راهنمای مرحله: ست فعال و حرکت بعدی */}
      {!readOnly && (
        <div className="mt-2 flex items-center justify-center gap-1.5 text-[10.5px] font-bold text-[#8f96a0]">
          <Timer size={12} className="shrink-0 text-[#e9e400]" />
          <span>
            {allDone
              ? isLastExercise
                ? localizeStatic("همهٔ ست‌های این حرکت انجام شد — جلسه کامل شد")
                : localizeStatic("همهٔ ست‌های این حرکت انجام شد — آمادهٔ حرکت بعدی")
              : `${localizeStatic("ست فعال: ")}${localize(fa(activeSet + 1))} ${localizeStatic("از ")}${localize(fa(sets))}`}
          </span>
        </div>
      )}

      {/* set table */}
      <div data-guide="exercise-sets" className="mt-2.5 rounded-[18px] border border-white/[0.04] bg-[#0c0d0c] px-1.5">
        <div className="grid grid-cols-[26px_minmax(0,1.15fr)_minmax(0,0.9fr)_46px_40px] items-center gap-1 border-b border-white/[0.06] py-2 text-center text-[9px] font-bold leading-4 text-[#8d949d]">
          <span>{localizeStatic("ست")}</span>
          <span>{localizeStatic("کل وزن، با میله")}<br />{localizeStatic("کیلو")}</span>
          <span>{localizeStatic("تکرار")}</span>
          <span>RIR</span>
          <span className="tnum">{localize(fa(doneCount))}/{localize(fa(sets))}</span>
        </div>

        {values.map((value, i) => {
          const isDone = !!done[i];
          const isActive = !readOnly && i === activeSet;
          return (
            <div
              key={i}
              data-guide-detail={isActive ? "active-set" : undefined}
              className={`border-b border-white/[0.035] py-1.5 transition-colors duration-300 last:border-b-0 ${
                isActive
                  ? "-mx-1.5 rounded-2xl border border-[#e9e400]/15 bg-[#e9e400]/[0.07] px-1.5"
                  : isDone
                    ? "bg-emerald-500/[0.04]"
                    : ""
              }`}
            >
              <div className="grid grid-cols-[26px_minmax(0,1.15fr)_minmax(0,0.9fr)_46px_40px] items-center gap-1">
                <span className={`relative text-center text-[13px] font-black transition-colors ${isActive ? "text-[#e9e400]" : "text-white/65"}`}>
                  {localize(fa(i + 1))}
                  {isActive && <span className="absolute -right-1 top-0 h-1.5 w-1.5 rounded-full bg-[#e9e400]" aria-hidden="true" />}
                </span>

                {readOnly ? (
                  <button type="button" onClick={() => onEditSet?.(i)} className={cellCls} aria-label={localizeStatic("ویرایش وزن")}>
                    {value.weight ? localize(value.weight) : <span className="text-white/20">—</span>}
                  </button>
                ) : (
                  <input
                    value={value.weight}
                    onChange={(event) => onField?.(i, "weight", event.target.value)}
                    inputMode="decimal"
                    placeholder={i === activeSet ? "" : "—"}
                    aria-label={localize(`وزن ست ${i + 1}`)}
                    className={`${cellCls} placeholder:text-[11px] placeholder:font-bold placeholder:text-white/20 focus:placeholder:text-transparent`}
                  />
                )}

                {readOnly ? (
                  <button type="button" onClick={() => onEditSet?.(i)} className={cellCls} aria-label={localizeStatic("ویرایش تکرار")}>
                    {value.reps ? localize(value.reps) : <span className="text-white/20">—</span>}
                  </button>
                ) : (
                  <input
                    value={value.reps}
                    onChange={(event) => onField?.(i, "reps", event.target.value)}
                    inputMode="numeric"
                    placeholder="—"
                    aria-label={localize(`تکرار ست ${i + 1}`)}
                    className={`${cellCls} placeholder:text-white/25`}
                  />
                )}

                {readOnly ? (
                  <button
                    type="button"
                    onClick={() => onEditSet?.(i)}
                    className="tnum flex h-[40px] w-full items-center justify-center rounded-[13px] bg-[#1c1d18] text-[10.5px] font-bold text-[#b6bdc6]"
                  >
                    {value.rir ? localize(value.rir) : "RIR"}
                  </button>
                ) : (
                  <div className="relative">
                    <span aria-hidden="true" className="tnum pointer-events-none flex h-[40px] w-full items-center justify-center rounded-[13px] bg-[#1c1d18] text-[10.5px] font-bold text-[#b6bdc6]">
                      {value.rir ? value.rir : "RIR"}
                    </span>
                    <select
                      value={value.rir}
                      onChange={(event) => onRir?.(i, event.target.value)}
                      aria-label={localize(`RIR ست ${i + 1}`)}
                      className="absolute inset-0 h-full w-full cursor-pointer appearance-none bg-transparent text-transparent outline-none"
                    >
                      <option value="">RIR</option>
                      {[0, 1, 2, 3, 4, 5].map((n) => <option key={n} value={String(n)}>{localize(fa(n))}</option>)}
                    </select>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => onToggle?.(i)}
                  disabled={!onToggle}
                  aria-label={localize(isDone ? `ست ${i + 1} انجام شد` : `تیک ست ${i + 1}`)}
                  aria-pressed={isDone}
                  className={`mx-auto flex h-[38px] w-[38px] items-center justify-center rounded-full border-2 transition-all duration-200 ${
                    isDone
                      ? "border-[#e9e400] bg-[#e9e400] text-black shadow-[0_0_18px_-4px_rgba(233,228,0,0.7)] [animation:pop-in_0.28s_ease]"
                      : isActive
                        ? "border-[#e9e400]/70 text-[#e9e400] shadow-[0_0_14px_-4px_rgba(233,228,0,0.5)]"
                        : "border-white/20 text-white/35 hover:border-[#e9e400]/50 hover:text-[#e9e400]"
                  } ${!onToggle ? "cursor-default" : "press"}`}
                >
                  <Check size={17} strokeWidth={3.2} />
                </button>
              </div>

              {!readOnly && i === activeSet && (
                <div className="mt-1.5 grid grid-cols-2 gap-1.5 pl-[42px]">
                  <Stepper
                    label={localizeStatic("کیلو")}
                    minusLabel={localizeStatic("کاهش وزن")}
                    plusLabel={localizeStatic("افزایش وزن")}
                    onMinus={() => step("weight", -1)}
                    onPlus={() => step("weight", 1)}
                  />
                  <Stepper
                    label={localizeStatic("تکرار")}
                    minusLabel={localizeStatic("کاهش تکرار")}
                    plusLabel={localizeStatic("افزایش تکرار")}
                    onMinus={() => step("reps", -1)}
                    onPlus={() => step("reps", 1)}
                  />
                </div>
              )}

              {!readOnly && isDone && i === activeSet && (
                <p className="mt-1.5 pl-[42px] text-[10px] font-bold text-[#e9e400]">
                  {localizeStatic("ست انجام شد — ست بعدی فعال شد")}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {extra && <div className="mt-2">{extra}</div>}
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* pager                                                               */
/* ------------------------------------------------------------------ */

export function SessionPager({
  current, total, onPrev, onNext, prevName, nextName, onFinish,
}: {
  current: number;
  total: number;
  onPrev: () => void;
  onNext: () => void;
  prevName?: string;
  nextName?: string;
  /** در آخرین حرکت، دکمهٔ «بعدی» به «ثبت جلسه» تبدیل می‌شود */
  onFinish?: () => void;
}) {
  const canPrev = current > 1;
  const canNext = current < total;
  const isLast = current >= total;
  return (
    <div data-guide="workout-pager">
      <div className="mb-1.5 flex items-center justify-between px-1">
        <span className="tnum text-[9.5px] font-bold text-[#8f96a0]">
          {localizeStatic("حرکت ")}
          {localize(fa(current))}
          {localizeStatic(" از ")}
          {localize(fa(total))}
        </span>
        <span className="flex items-center gap-1" aria-hidden="true">
          {Array.from({ length: total }).map((_, i) => (
            <span key={i} className={`h-1 rounded-full transition-all ${i === current - 1 ? "w-4 bg-[#e9e400]" : "w-1 bg-white/15"}`} />
          ))}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={onPrev}
          disabled={!canPrev}
          className="press flex min-h-[48px] flex-col items-center justify-center gap-0.5 rounded-[16px] bg-[#1c1d18] px-2 py-1.5 text-[13px] font-black text-white/85 transition hover:bg-[#232420] disabled:cursor-default disabled:opacity-40"
        >
          <span className="flex items-center gap-1">
            <ChevronRight size={17} />
            {localizeStatic("قبلی")}
          </span>
          {canPrev && prevName && <span className="max-w-full truncate text-[9px] font-bold text-[#8f96a0]">{localize(prevName)}</span>}
        </button>
        {isLast && onFinish ? (
          <button
            type="button"
            onClick={onFinish}
            className="press flex min-h-[48px] flex-col items-center justify-center gap-0.5 rounded-[16px] bg-[#e9e400] px-2 py-1.5 text-[13px] font-black text-black shadow-[0_14px_36px_-14px_rgba(233,228,0,0.8)] transition hover:brightness-105 active:scale-[0.98]"
          >
            <span className="flex items-center gap-1">
              <Check size={17} strokeWidth={3} />
              {localizeStatic("ثبت جلسه")}
            </span>
            <span className="max-w-full truncate text-[9px] font-bold text-black/60">{localizeStatic("پایان تمرین امروز")}</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={onNext}
            disabled={!canNext}
            className="press flex min-h-[48px] flex-col items-center justify-center gap-0.5 rounded-[16px] bg-[#1c1d18] px-2 py-1.5 text-[13px] font-black text-white/85 transition hover:bg-[#232420] disabled:cursor-default disabled:opacity-40"
          >
            <span className="flex items-center gap-1">
              {localizeStatic("بعدی")}
              <ChevronLeft size={17} />
            </span>
            {canNext && nextName && <span className="max-w-full truncate text-[9px] font-bold text-[#8f96a0]">{localize(nextName)}</span>}
          </button>
        )}
      </div>
    </div>
  );
}
