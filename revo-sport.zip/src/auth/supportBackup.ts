import { emptyData } from "../source/data/seed";
import type { AppData, Role } from "../source/data/types";

export interface SupportBackupPreview {
  data: AppData;
  accounts: SupportAccount[];
  exportedAt: string;
  exportedBy: string;
  counts: { students: number; programs: number; logs: number };
}

export type SupportAccount = { id: string; name: string; email: string; role: Role };

export const VAULT_KEY = "revofit-coach-v3";
export const MAX_BYTES = 8 * 1024 * 1024;


export function readLocalVault(): { data?: Partial<AppData>; light?: boolean; prefs?: Record<string, unknown> } | null {
  try {
    const raw = localStorage.getItem(VAULT_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

/** بررسی ساختار فایل؛ خروجی فقط پس از اعتبارسنجی کامل برگردانده می‌شود. */
export function parseSupportBackup(text: string): SupportBackupPreview {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text.replace(/^\uFEFF/, ""));
  } catch {
    throw new Error("فایل خوانده نشد. یک فایل JSON معتبر از پشتیبانی انتخاب کن.");
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error("ساختار فایل درست نیست.");
  }
  const root = parsed as Record<string, unknown>;
  const meta = (root.meta && typeof root.meta === "object" ? root.meta : {}) as Record<string, unknown>;
  const rawData = (root.data && typeof root.data === "object" ? root.data : root) as Record<string, unknown>;
  const users = Array.isArray(rawData.users) ? rawData.users : null;
  if (!users || users.length === 0) {
    throw new Error("این فایل هیچ حساب کاربری‌ای ندارد؛ فایل پشتیبانی کامل را انتخاب کن.");
  }
  const accounts: SupportAccount[] = [];
  const sanitizedUsers: AppData["users"] = [];
  for (const value of users) {
    if (!value || typeof value !== "object") continue;
    const user = value as Record<string, unknown>;
    const role = user.role;
    if (role !== "coach" && role !== "student" && role !== "admin") continue;
    const email = typeof user.email === "string" ? user.email.trim() : "";
    const id = typeof user.id === "string" ? user.id : "";
    if (!id || !email) continue;
    const name = typeof user.name === "string" && user.name.trim() ? user.name.trim() : email;
    accounts.push({ id, name, email, role });
    sanitizedUsers.push(user as unknown as AppData["users"][number]);
  }
  if (accounts.length === 0) {
    throw new Error("حساب معتبری در فایل پیدا نشد. فایل پشتیبانی Revo sport لازم است.");
  }
  const students = Array.isArray(rawData.students)
    ? rawData.students.filter((item): item is AppData["students"][number] => Boolean(item) && typeof item === "object" && typeof (item as { id?: unknown }).id === "string")
    : [];
  const data = { ...emptyData(), ...rawData, users: sanitizedUsers, students } as AppData;
  return {
    data,
    accounts: accounts.sort((a, b) => (a.role === b.role ? a.name.localeCompare(b.name, "fa") : a.role === "coach" ? -1 : 1)),
    exportedAt: typeof meta.exportedAt === "string" ? meta.exportedAt : "",
    exportedBy: typeof meta.exportedBy === "string" ? meta.exportedBy : "",
    counts: {
      students: data.students.length,
      programs: data.programs.length,
      logs: data.logs.length,
    },
  };
}

/** ادغام بدون حذف حساب‌های موجود؛ برای شناسه‌های تکراری، فایل پشتیبانی اولویت دارد. */
export function mergeBackup(current: AppData, incoming: AppData): AppData {
  const mergeById = <T extends { id: string }>(a: T[] = [], b: T[] = []): T[] => {
    const map = new Map<string, T>();
    for (const item of a) map.set(item.id, item);
    for (const item of b) map.set(item.id, item);
    return [...map.values()];
  };
  return {
    ...current,
    ...incoming,
    users: mergeById(current.users, incoming.users),
    students: mergeById(current.students, incoming.students),
    programs: mergeById(current.programs, incoming.programs),
    logs: mergeById(current.logs, incoming.logs),
    coachExercises: mergeById(current.coachExercises, incoming.coachExercises),
    workoutTemplates: mergeById(current.workoutTemplates, incoming.workoutTemplates),
    messages: mergeById(current.messages, incoming.messages),
    invoices: mergeById(current.invoices, incoming.invoices),
    checkins: mergeById(current.checkins, incoming.checkins),
    water: { ...current.water, ...incoming.water },
    sleep: { ...current.sleep, ...incoming.sleep },
    xp: { ...current.xp, ...incoming.xp },
    streak: { ...current.streak, ...incoming.streak },
    coachPlans: { ...current.coachPlans, ...incoming.coachPlans },
  };
}

