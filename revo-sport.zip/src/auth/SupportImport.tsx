import { useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  AlertTriangle, Check, CheckCircle2, FileJson, Loader2, ShieldCheck, Upload, UserRound, X,
} from "lucide-react";
import { currentDirection, localizeStatic } from "../i18n";
import type { AppData, Role } from "../source/data/types";
import { MAX_BYTES, VAULT_KEY, mergeBackup, parseSupportBackup, readLocalVault, type SupportAccount, type SupportBackupPreview } from "./supportBackup";
import "./supportImport.css";

const roleLabel = (role: Role) => role === "coach" ? "مربی" : role === "student" ? "شاگرد" : "مدیر";

export function SupportImport({ onUseAccount }: { onUseAccount: (email: string) => void }) {
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<SupportBackupPreview | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [merge, setMerge] = useState(true);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const existing = useMemo(() => {
    if (!open) return { users: 0, students: 0 };
    const vault = readLocalVault();
    return {
      users: Array.isArray(vault?.data?.users) ? (vault!.data!.users as unknown[]).length : 0,
      students: Array.isArray(vault?.data?.students) ? (vault!.data!.students as unknown[]).length : 0,
    };
  }, [open]);

  const reset = () => {
    setFile(null);
    setPreview(null);
    setError("");
    setDone(false);
    setBusy(false);
    setDragging(false);
  };
  const close = () => {
    setOpen(false);
    reset();
  };

  const pick = async (next: File | undefined) => {
    setError("");
    setDone(false);
    setFile(null);
    setPreview(null);
    if (!next) return;
    if (next.size > MAX_BYTES) {
      setError("حجم فایل بیش از ۸ مگابایت است. فایل پشتیبانی اصلی را انتخاب کن.");
      return;
    }
    if (!/\.(json|txt)$/i.test(next.name) && next.type !== "application/json") {
      setError("فقط فایل JSON پشتیبانی پذیرفته می‌شود.");
      return;
    }
    setBusy(true);
    try {
      const parsed = parseSupportBackup(await next.text());
      setFile(next);
      setPreview(parsed);
    } catch (err) {
      setError(err instanceof Error ? err.message : "خواندن فایل ممکن نشد.");
    } finally {
      setBusy(false);
    }
  };

  const restore = () => {
    if (!preview) return;
    setBusy(true);
    setError("");
    try {
      const vault = readLocalVault();
      const current = vault?.data as AppData | undefined;
      const validCurrent = current && Array.isArray(current.users) && Array.isArray(current.students) ? current : null;
      const data = merge && validCurrent ? mergeBackup(validCurrent, preview.data) : preview.data;
      // ورود خودکار انجام نمی‌شود؛ پس از بازیابی، کاربر با رمز خود وارد می‌شود.
      localStorage.setItem(VAULT_KEY, JSON.stringify({
        data,
        session: null,
        light: !!vault?.light,
        prefs: vault?.prefs ?? {},
      }));
      localStorage.setItem("revofit-last-import", new Date().toISOString());
      setDone(true);
    } catch {
      setError("ذخیره در این مرورگر ممکن نشد. فضای ذخیره‌سازی را بررسی کن یا از حالت عادی استفاده کن.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <button type="button" className="support-import-trigger" onClick={() => setOpen(true)}>
        <span className="support-import-icon"><Upload size={16} /></span>
        <span className="support-import-copy">
          <b>{localizeStatic("ورود سریع‌تر با فایل پشتیبانی")}</b>
          <small>{localizeStatic("فایل اطلاعاتی که از پشتیبانی گرفته‌اید را اینجا بارگذاری کنید")}</small>
        </span>
      </button>

      {open && createPortal(
        <div className="support-import-layer" dir={currentDirection()} role="presentation" onClick={close}>
          <div
            className="support-import-sheet"
            role="dialog"
            aria-modal="true"
            aria-labelledby="support-import-title"
            onClick={(event) => event.stopPropagation()}
          >
            <header className="support-import-head">
              <span className="support-import-badge"><ShieldCheck size={18} /></span>
              <div>
                <h2 id="support-import-title">{localizeStatic("بازیابی اطلاعات از فایل پشتیبانی")}</h2>
                <p>{localizeStatic("حساب‌ها، برنامه‌ها و سوابق خود را از فایل دریافت‌شده بازگردانید.")}</p>
              </div>
              <button type="button" onClick={close} aria-label={localizeStatic("بستن")} className="support-import-close">
                <X size={18} />
              </button>
            </header>

            {!done ? (
              <div className="support-import-body">
                <label
                  className={`support-drop ${dragging ? "is-drag" : ""} ${preview ? "has-file" : ""}`}
                  onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
                  onDragLeave={() => setDragging(false)}
                  onDrop={(event) => { event.preventDefault(); setDragging(false); void pick(event.dataTransfer.files?.[0]); }}
                >
                  <input
                    ref={inputRef}
                    type="file"
                    accept=".json,.txt,application/json,text/plain"
                    onChange={(event) => { void pick(event.target.files?.[0]); event.currentTarget.value = ""; }}
                  />
                  <span className="support-drop-icon">{busy ? <Loader2 size={22} className="spin" /> : preview ? <FileJson size={22} /> : <Upload size={22} />}</span>
                  <b>{preview ? file?.name : localizeStatic("فایل پشتیبانی را انتخاب یا اینجا رها کنید")}</b>
                  <small>{preview ? localizeStatic("برای تغییر، فایل دیگری انتخاب کنید") : localizeStatic("JSON • حداکثر ۸ مگابایت")}</small>
                </label>

                {error && (
                  <p className="support-error" role="alert">
                    <AlertTriangle size={14} />{error}
                  </p>
                )}

                {preview && (
                  <div className="support-preview">
                    <div className="support-preview-top">
                      <span><CheckCircle2 size={14} />{localizeStatic("فایل معتبر است")}</span>
                      <small>{preview.exportedAt ? localizeStatic(`تاریخ فایل: ${new Date(preview.exportedAt).toLocaleDateString("fa-IR")}`) : ""}</small>
                    </div>
                    <div className="support-metrics">
                      <div><b>{preview.accounts.length}</b><span>{localizeStatic("حساب")}</span></div>
                      <div><b>{preview.counts.students}</b><span>{localizeStatic("شاگرد")}</span></div>
                      <div><b>{preview.counts.programs}</b><span>{localizeStatic("برنامه")}</span></div>
                      <div><b>{preview.counts.logs}</b><span>{localizeStatic("تمرین ثبت‌شده")}</span></div>
                    </div>
                    <ul className="support-accounts">
                      {preview.accounts.slice(0, 6).map((account: SupportAccount) => (
                        <li key={account.id}>
                          <span className="support-avatar"><UserRound size={14} /></span>
                          <span className="min-w-0 flex-1">
                            <b>{account.name}</b>
                            <small dir="ltr">{account.email}</small>
                          </span>
                          <em>{localizeStatic(roleLabel(account.role))}</em>
                        </li>
                      ))}
                      {preview.accounts.length > 6 && (
                        <li className="support-more">{localizeStatic(`و ${preview.accounts.length - 6} حساب دیگر`)}</li>
                      )}
                    </ul>

                    {existing.users > 0 && (
                      <label className="support-merge">
                        <input type="checkbox" checked={merge} onChange={(event) => setMerge(event.target.checked)} />
                        <span>
                          <b>{localizeStatic("اطلاعات موجود حفظ شود")}</b>
                          <small>{localizeStatic(`این دستگاه ${existing.users} حساب و ${existing.students} شاگرد دارد؛ فایل فقط موارد جدید یا به‌روز را اضافه می‌کند.`)}</small>
                        </span>
                      </label>
                    )}

                    <p className="support-note">
                      {localizeStatic("پس از بازیابی، با ایمیل و رمز عبور خودتان وارد می‌شوید. ورود خودکار انجام نمی‌شود.")}
                    </p>
                  </div>
                )}

                <div className="support-actions">
                  <button type="button" className="support-secondary" onClick={close}>{localizeStatic("انصراف")}</button>
                  <button
                    type="button"
                    className="support-primary"
                    disabled={!preview || busy}
                    onClick={restore}
                  >
                    {busy ? <Loader2 size={16} className="spin" /> : <ShieldCheck size={16} />}
                    {localizeStatic("بازیابی و ادامه")}
                  </button>
                </div>
              </div>
            ) : (
              <div className="support-import-body">
                <div className="support-success">
                  <span><Check size={22} strokeWidth={3} /></span>
                  <b>{localizeStatic("اطلاعات با موفقیت بازیابی شد")}</b>
                  <p>{localizeStatic("حالا یکی از حساب‌های زیر را انتخاب کنید؛ ایمیل آن در فرم ورود قرار می‌گیرد و فقط رمز عبورتان را وارد می‌کنید.")}</p>
                </div>
                <ul className="support-accounts support-accounts--pick">
                  {preview?.accounts.slice(0, 8).map((account: SupportAccount) => (
                    <li key={account.id}>
                      <button
                        type="button"
                        onClick={() => {
                          onUseAccount(account.email);
                          close();
                        }}
                      >
                        <span className="support-avatar"><UserRound size={15} /></span>
                        <span className="min-w-0 flex-1">
                          <b>{account.name}</b>
                          <small dir="ltr">{account.email}</small>
                        </span>
                        <em>{localizeStatic(roleLabel(account.role))}</em>
                      </button>
                    </li>
                  ))}
                </ul>
                <div className="support-actions">
                  <button type="button" className="support-primary" onClick={close}>{localizeStatic("بستن و ورود دستی")}</button>
                </div>
              </div>
            )}

            <p className="support-import-foot">
              {localizeStatic("فایل پشتیبانی فقط در همین مرورگر ذخیره می‌شود. اگر حساب شما روی سرور است، پیش از بازیابی با پشتیبانی هماهنگ کنید.")}
            </p>
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}
