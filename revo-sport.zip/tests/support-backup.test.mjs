import assert from "node:assert/strict";
import { build } from "esbuild";

async function load(path) {
  const result = await build({ entryPoints: [path], bundle: true, write: false, format: "cjs", platform: "node" });
  const module = { exports: {} };
  new Function("module", "exports", result.outputFiles[0].text)(module, module.exports);
  return module.exports;
}
const memory = new Map();
globalThis.localStorage = {
  getItem: (key) => memory.get(key) ?? null,
  setItem: (key, value) => memory.set(key, value),
};
const { parseSupportBackup, mergeBackup, VAULT_KEY } = await load("src/auth/supportBackup.ts");

const user = (id, role, email, name) => ({ id, role, email, name, phone: "09120000000", avatar: "", password: "pw", createdAt: "2025-01-01", lastLoginAt: "2025-01-01" });
const backup = {
  meta: { app: "Revo sport", version: 1, exportedAt: "2026-05-01T10:00:00.000Z", exportedBy: "پشتیبانی" },
  data: {
    users: [user("u1", "coach", "coach@example.com", "مربی نمونه"), user("u2", "student", "s@example.com", "شاگرد نمونه"), { bad: true }],
    students: [{ id: "s1", userId: "u2", coachId: "u1" }],
    programs: [{ id: "p1" }],
    logs: [{ id: "l1" }],
  },
};
const parsed = parseSupportBackup(JSON.stringify(backup));
assert.equal(parsed.accounts.length, 2);
assert.equal(parsed.accounts[0].role, "coach");
assert.equal(parsed.counts.students, 1);
assert.equal(parsed.counts.programs, 1);
assert.equal(parsed.counts.logs, 1);
assert.equal(parsed.exportedBy, "پشتیبانی");
assert.equal(parsed.data.water && typeof parsed.data.water, "object");
// root-level backup format (no data wrapper) and BOM
const rootLevel = parseSupportBackup("\uFEFF" + JSON.stringify({ users: [user("u3", "student", "x@example.com", "x")], students: [] }));
assert.equal(rootLevel.accounts.length, 1);
assert.equal(rootLevel.accounts[0].email, "x@example.com");
// invalid files
assert.throws(() => parseSupportBackup("not json"), /فایل خوانده نشد/);
assert.throws(() => parseSupportBackup(JSON.stringify({ data: { students: [] } })), /هیچ حساب/);
assert.throws(() => parseSupportBackup(JSON.stringify({ data: { users: [{ id: "x", role: "guest", email: "g@x" }] } })), /حساب معتبری/);
// merge keeps existing accounts and incoming wins on the same id
const current = { users: [user("keep", "coach", "keep@example.com", "قدیمی"), user("u2", "student", "old@example.com", "نام قبلی")], students: [{ id: "keep-s" }], programs: [], logs: [], coachExercises: [], workoutTemplates: [], messages: [], invoices: [], checkins: [], water: { keep: 1 }, sleep: {}, xp: {}, streak: {}, coachPlans: {} };
const merged = mergeBackup(current, parsed.data);
assert.equal(merged.users.length, 3);
assert.equal(merged.users.find((u) => u.id === "u2").name, "شاگرد نمونه");
assert.ok(merged.users.find((u) => u.id === "keep"));
assert.ok(merged.students.find((s) => s.id === "keep-s"));
// no production data is touched by validation
assert.equal(memory.size, 0);
memory.set(VAULT_KEY, JSON.stringify({ data: { users: [], students: [] }, light: false, prefs: {} }));
assert.ok(memory.get(VAULT_KEY));
console.log("Support backup tests passed: validation, both formats, BOM, invalid input, safe merge, no write during parse.");
