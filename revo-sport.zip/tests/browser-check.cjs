/* Browser verification: login support-file import + immersive workout and rest timer. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const SHOTS = process.env.SCREENSHOTS || '/tmp/revo-browser-check-shots';
fs.mkdirSync(SHOTS, { recursive: true });
const MODULES = process.env.BROWSER_MODULES || path.join(__dirname, '..', 'node_modules');
const base = process.env.APP_URL || 'http://localhost:5173';
const chromium = require(path.join(MODULES, '@sparticuz/chromium'));
const { chromium: pw } = require(path.join(MODULES, 'playwright'));

const poster = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1400"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a3d3a"/><stop offset="1" stop-color="#111"/></linearGradient></defs><rect width="800" height="1400" fill="url(#g)"/><ellipse cx="400" cy="620" rx="240" ry="130" fill="#2c2f2c"/><rect x="120" y="600" width="560" height="26" rx="13" fill="#c9c9c9"/></svg>');
const now = new Date();
const iso = now.toISOString();
const W = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];
const itemsA = [
  { id:'it-bench', exerciseId:'ex-bench', sets:3, reps:'8-12', weight:'80', rest:180, tempo:'3-0-1', rpe:7, notes:'کتف‌ها را ثابت نگه دار و در فاز منفی وزنه را کنترل کن.' },
  { id:'it-curl', exerciseId:'ex-curl', sets:2, reps:'10', weight:'20', rest:0, tempo:'2-0-1', rpe:7, notes:'' },
];
const itemsB = [
  { id:'it-squat', exerciseId:'ex-squat', sets:2, reps:'10', weight:'60', rest:180, tempo:'3-0-1', rpe:7, notes:'زانوها را در راستای پنجه پا نگه دار.' },
  { id:'it-rdl', exerciseId:'ex-rdl', sets:2, reps:'10', weight:'40', rest:0, tempo:'3-0-1', rpe:7, notes:'' },
];
const users = [
  { id:'coach-t', role:'coach', name:'مربی آزمایش', email:'coach@test.dev', phone:'09120000001', avatar:poster, password:'Demo1234', createdAt:iso, lastLoginAt:iso, inviteCode:'REVO01', trainerProfile:{ age:32, specialization:'بدنسازی', certification:'NSCA', experienceYears:8, coachingFormat:'online', bio:'مربی آزمایشی' } },
  { id:'student-t', role:'student', name:'ورزشکار آزمایش', email:'student@test.dev', phone:'09120000002', avatar:poster, password:'Demo1234', createdAt:iso, lastLoginAt:iso },
];
const student = { id:'st-t', userId:'student-t', coachId:'coach-t', age:26, gender:'زن', height:165, weight:60, goal:'فیتنس', level:'مبتدی', experience:'', startDate:iso, subEndsAt:iso, subscription:'فعال', daysLeft:30, daysSinceWorkout:0, notes:'', status:'active', category:'', assessment:{ mainGoal:'فیتنس', level:'مبتدی', history:'', daysPerWeek:4, sessionMinutes:45, equipment:['هالتر'], lifestyle:'', dailyActivity:'متوسط', sleepHours:7, foodPrefs:'', limitations:'' } };
const days = W.map((weekday, i) => ({ id:`day-${i}`, weekday, focus: i%2 ? 'پایین‌تنه' : 'بالاتنه', items: i%2 ? itemsB : itemsA }));
const data = { users, students:[student], programs:[{ id:'pr-t', studentId:'st-t', name:'برنامه قدرت', goal:'فیتنس', weeks:8, startDate:iso, endDate:iso, days, status:'فعال', createdAt:iso }], logs:[], meals:[], progress:[], photos:[], goals:[], messages:[], notifs:[], appts:[], invoices:[], water:{}, sleep:{}, xp:{}, streak:{}, coachExercises:[], coachPlans:{}, foods:[], nutritionLogs:[], checkins:[], workoutTemplates:[] };
const backupFile = path.join(SHOTS, 'support-backup.json');
fs.writeFileSync(backupFile, JSON.stringify({ meta:{ app:'Revo sport', kind:'database-export', version:1, exportedAt:iso, exportedBy:'پشتیبانی' }, data }));

async function newPage(browser, opts = {}) {
  const context = await browser.newContext({ viewport:{ width:390, height:844 }, locale:'fa-IR', timezoneId:'Asia/Tehran', reducedMotion:'reduce', ...opts });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.route('**/api/health', route => route.fulfill({ status:200, contentType:'application/json', body: JSON.stringify({ ok:false, app:'local' }) }));
  await page.route(/https:\/\/(images\.pexels\.com|videos\.pexels\.com)\//, route => {
    const isVideo = route.request().resourceType() === 'video';
    return route.fulfill({ status:200, contentType: isVideo ? 'video/mp4' : 'image/svg+xml', body: isVideo ? Buffer.alloc(0) : poster });
  });
  return { context, page, errors };
}

(async () => {
  const browser = await pw.launch({ executablePath: await chromium.executablePath(), args: chromium.args.filter(a => a !== '--single-process'), headless: true });

  /* 1) Login support-file import */
  const first = await newPage(browser, { viewport:{ width:1280, height:800 } });
  await first.page.goto(`${base}/#/login`, { waitUntil:'domcontentloaded' });
  await first.page.waitForTimeout(3200);
  // Fresh sessions must pick a gender during startup before the sign-in panel is reachable.
  const genderGate = first.page.locator('.gender-gate');
  if (await genderGate.count()) {
    await first.page.locator('.gender-card.is-male').click();
    await first.page.locator('.login-panel').waitFor({ timeout: 15000 });
  }
  await first.page.locator('.support-import-trigger').waitFor({ state:'visible', timeout:20000 });
  await first.page.screenshot({ path: path.join(SHOTS, 'login-trigger.png') });
  await first.page.locator('.support-import-trigger').click();
  await first.page.locator('.support-import-sheet').waitFor();
  await first.page.locator('.support-drop input[type=file]').setInputFiles(backupFile);
  await first.page.locator('.support-preview').waitFor({ timeout:10000 });
  assert.deepEqual((await first.page.locator('.support-metrics b').allInnerTexts()).slice(0, 4), ['2','1','1','0']);
  await first.page.screenshot({ path: path.join(SHOTS, 'login-preview.png') });
  await first.page.locator('.support-primary').click();
  await first.page.locator('.support-success').waitFor({ timeout:10000 });
  await first.page.screenshot({ path: path.join(SHOTS, 'login-success.png') });
  const stored = await first.page.evaluate(() => {
    const value = JSON.parse(localStorage.getItem('revofit-coach-v3') || '{}');
    return { users: value.data?.users?.length, students: value.data?.students?.length, session: value.session };
  });
  assert.deepEqual(stored, { users:2, students:1, session:null });
  await first.page.locator('.support-accounts--pick button').first().click();
  await first.page.waitForTimeout(350);
  assert.equal(await first.page.locator('.field input[autocomplete=username]').inputValue(), 'coach@test.dev');
  await first.page.locator('input[autocomplete=current-password]').fill('Demo1234');
  await first.page.locator('form.auth-form button[type=submit]').click();
  await first.page.locator('[data-guide-scope="coach"]').waitFor({ timeout:15000 }).catch(()=>{});
  const coachCount = await first.page.locator('[data-guide-scope="coach"]').count();
  if (!coachCount) {
    const dbg = await first.page.evaluate(() => ({ vault: JSON.parse(localStorage.getItem('revofit-coach-v3')||'null'), hash: location.hash }));
    console.log('DEBUG LOGIN', JSON.stringify({ session: dbg.vault?.session, users: dbg.vault?.data?.users?.map(u=>({email:u.email,role:u.role,pw:u.password})), hash: dbg.hash }));
    console.log('DEBUG TEXT', (await first.page.locator('body').innerText()).slice(0, 900));
    await first.page.screenshot({ path: path.join(SHOTS, 'login-debug.png') });
  }
  assert.ok(coachCount, 'restored account should log in');
  assert.deepEqual(first.errors, []);
  await first.context.close();
  console.log('PASS login support import: trigger, preview, restore, account pick, quick login');

  await browser.close();
  const { spawnSync } = require('node:child_process');
  const result = spawnSync(process.execPath, [path.join(__dirname, 'minimal-workout.test.cjs')], { env: process.env, stdio: 'inherit' });
  if (result.status !== 0) process.exit(result.status || 1);
  console.log('ALL BROWSER CHECKS PASSED');
})().catch(error => { console.error(error); process.exit(1); });
