import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { build } from "esbuild";

async function loadModule(path) {
  const result = await build({ entryPoints: [path], bundle: true, write: false, format: "cjs", platform: "node" });
  const module = { exports: {} };
  new Function("module", "exports", result.outputFiles[0].text)(module, module.exports);
  return module.exports;
}

const memory = new Map();
globalThis.localStorage = {
  getItem: (key) => memory.get(key) ?? null,
  setItem: (key, value) => memory.set(key, value),
};

const { guideStorageKey, readGuideProgress, saveGuideProgress, placeGuidePanel } = await loadModule("src/source/lib/guide-state.ts");
const { getGuideSpec } = await loadModule("src/source/components/guide-content.ts");
const completed = { status: "completed", step: "welcome", updatedAt: new Date().toISOString() };

assert.notEqual(guideStorageKey("coach", "shared-id"), guideStorageKey("student", "shared-id"));
assert.notEqual(guideStorageKey("student", "one"), guideStorageKey("student", "two"));
saveGuideProgress("coach", "shared-id", "dash", completed);
assert.equal(readGuideProgress("coach", "shared-id").dash.status, "completed");
assert.deepEqual(readGuideProgress("student", "shared-id"), {});
assert.deepEqual(readGuideProgress("coach", "other-account"), {});
memory.set(guideStorageKey("coach", "corrupt"), "{broken");
assert.deepEqual(readGuideProgress("coach", "corrupt"), {});
memory.set(guideStorageKey("student", "invalid"), JSON.stringify({ one: null, two: [], three: { status: "unknown" } }));
assert.deepEqual(readGuideProgress("student", "invalid"), {});

globalThis.localStorage.setItem = () => { throw new Error("Storage unavailable"); };
saveGuideProgress("student", "private-mode", "workout-session", { ...completed, status: "skipped" });
assert.equal(readGuideProgress("student", "private-mode")["workout-session"].status, "skipped");
assert.deepEqual(readGuideProgress("student", "another-private-user"), {});

const pages = {
  coach: ["dash", "students", "student", "programs", "moves-library", "moves-muscles", "moves-mine", "moves-studio", "calendar", "chat", "nutrition", "reports", "billing", "settings", "profile", "admin"],
  student: ["home", "workout", "workout-session", "history", "progress", "chat", "nutrition", "profile", "subscription"],
};
for (const [role, list] of Object.entries(pages)) {
  for (const page of list) {
    const spec = getGuideSpec(role, page);
    assert.equal(spec.id, page);
    assert.ok(spec.steps.length > 0);
    assert.equal(new Set(spec.steps.map((step) => step.id)).size, spec.steps.length);
    for (const step of spec.steps) {
      for (const lang of ["fa", "en"]) {
        assert.ok(step.title[lang].trim());
        assert.ok(step.body[lang].trim());
      }
    }
  }
}
assert.equal(getGuideSpec("coach", "muscles").id, "moves-muscles");
assert.equal(getGuideSpec("coach", "library").id, "moves-library");
assert.equal(getGuideSpec("coach", "plans").id, "billing");
assert.equal(getGuideSpec("student", "workout-rest").id, "workout");

for (const [width, height] of [[320, 568], [390, 844], [768, 1024], [1440, 900], [844, 390]]) {
  const panel = { width: Math.min(420, width - 32), height: Math.min(330, height - 32) };
  for (const target of [null, { left: 20, top: 20, width: 120, height: 50 }, { left: width / 3, top: height - 90, width: 90, height: 65 }, { left: 10, top: 10, width: width - 20, height: height - 20 }]) {
    const result = placeGuidePanel(target, { left: 0, top: 0, width, height }, panel);
    assert.ok(result.left >= 16 && result.top >= 16);
    assert.ok(result.left + panel.width <= width - 16 + 0.01);
    assert.ok(result.top + panel.height <= height - 16 + 0.01);
  }
}
const above = placeGuidePanel({ left: 50, top: 500, width: 250, height: 50 }, { left: 0, top: 0, width: 390, height: 844 }, { width: 358, height: 280 });
assert.equal(above.placement, "above");
assert.ok(above.top + 280 < 500);

const engine = await readFile("src/source/components/product-guide.tsx", "utf8");
assert.doesNotMatch(engine, /logWorkout\(|purchasePlan\(|saveProgram\(|updateProfile\(/);
console.log("Guide tests passed: 25 sections, account isolation, corrupt/blocked storage, aliases, non-mutating guides and responsive placement.");