/* Browser verification: gender selection at startup, gender-specific media and exercises. */
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const modules = process.env.BROWSER_MODULES || path.join(process.cwd(), "node_modules");
const chromium = require(path.join(modules, "@sparticuz/chromium"));
const { chromium: pw } = require(path.join(modules, "playwright"));
const base = process.env.APP_URL || "http://localhost:5173";
const shots = path.join(process.env.SCREENSHOTS || "/tmp/revo-gender-shots");
fs.mkdirSync(shots, { recursive: true });

const avatar = "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><rect width="20" height="20" fill="#444"/></svg>');
const now = new Date().toISOString();
const weekday = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
function fixture(gender) {
  const users = [
    { id: "coach-g", role: "coach", name: "مربی آزمایشی", email: "coach@g.test", password: "Test1234", phone: "", avatar, createdAt: now, lastLoginAt: now, inviteCode: "GEND01", trainerProfile: { age: 30, specialization: "بدنسازی", certification: "NSCA", experienceYears: 6, coachingFormat: "online", bio: "" } },
    { id: "athlete-g", role: "student", name: "ورزشکار آزمایشی", email: "athlete@g.test", password: "Test1234", phone: "", avatar, createdAt: now, lastLoginAt: now },
  ];
  const student = { id: "st-g", userId: "athlete-g", coachId: "coach-g", age: 26, gender: gender === "female" ? "زن" : "مرد", height: 170, weight: 65, goal: "فیتنس", level: "مبتدی", experience: "", startDate: "2025-01-01", subEndsAt: "2099-01-01", subscription: "فعال", daysLeft: 30, daysSinceWorkout: 0, notes: "", status: "active", category: "", assessment: { mainGoal: "فیتنس", level: "مبتدی", history: "", daysPerWeek: 3, sessionMinutes: 45, equipment: ["هالتر"], lifestyle: "", dailyActivity: "متوسط", sleepHours: 7, foodPrefs: "", limitations: "" } };
  const days = weekday.map((day, i) => ({
    id: `d${i}`, weekday: day, focus: "پایین‌تنه",
    items: [
      { id: `squat-${i}`, exerciseId: "ex-squat", sets: 3, reps: "10", weight: "60", rest: 0, tempo: "", rpe: 7, notes: "" },
      { id: `hip-${i}`, exerciseId: "ex-hip", sets: 3, reps: "12", weight: "40", rest: 0, tempo: "", rpe: 7, notes: "" },
    ],
  }));
  return { users, students: [student], programs: [{ id: "p-g", studentId: student.id, name: "برنامه قدرت", goal: "فیتنس", weeks: 8, startDate: "2025-01-01", endDate: "2099-01-01", days, status: "فعال", createdAt: now }], logs: [], meals: [], progress: [], photos: [], goals: [], messages: [], notifs: [], appts: [], invoices: [], water: {}, sleep: {}, xp: {}, streak: {}, coachExercises: [], coachPlans: {}, foods: [], nutritionLogs: [], checkins: [], workoutTemplates: [] };
}

(async () => {
  const browser = await pw.launch({ executablePath: await chromium.executablePath(), args: chromium.args.filter((arg) => arg !== "--single-process"), headless: true });
  const errors = [];

  async function session(role, gender, script) {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "fa-IR", reducedMotion: "reduce" });
    const page = await context.newPage();
    page.on("pageerror", (error) => errors.push(error.message));
    await page.route("**/api/health", (route) => route.fulfill({ status: 200, contentType: "application/json", body: '{"app":"local"}' }));
    await page.addInitScript(({ role, gender, data }) => {
      localStorage.setItem("revo-profile-gender", gender);
      localStorage.setItem("revofit-coach-v3", JSON.stringify({ data, session: { userId: role === "coach" ? "coach-g" : "athlete-g", role }, light: false, prefs: {} }));
      const done = { status: "completed", step: "", updatedAt: new Date().toISOString() };
      const guides = {};
      ["home", "workout", "workout-session", "history", "progress", "chat", "nutrition", "subscription", "profile", "dash", "students", "programs", "moves", "moves-library", "moves-muscles", "moves-mine", "moves-studio", "settings", "admin", "calendar", "reports", "billing"].forEach((id) => { guides[id] = done; });
      localStorage.setItem(`revo-guides-v1:${role}:${role === "coach" ? "coach-g" : "athlete-g"}`, JSON.stringify(guides));
    }, { role, gender, data: fixture(gender) });
    await page.goto(`${base}/#/${role === "coach" ? "coach" : "student"}`, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(1400);
    await script(page, context);
    await context.close();
  }

  /* 1) Fresh startup shows the gender gate; choosing one persists and unlocks the app. */
  {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "fa-IR", reducedMotion: "reduce" });
    const page = await context.newPage();
    page.on("pageerror", (error) => errors.push(error.message));
    await page.route("**/api/health", (route) => route.fulfill({ status: 200, contentType: "application/json", body: '{"app":"local"}' }));
    await page.goto(`${base}/#/login`, { waitUntil: "domcontentloaded" });
    await page.locator(".gender-gate").waitFor({ timeout: 15000 });
    await page.waitForTimeout(900);
    await page.screenshot({ path: path.join(shots, "gender-gate.png") });
    assert(await page.locator(".gender-card.is-male").isVisible());
    assert(await page.locator(".gender-card.is-female").isVisible());
    await page.locator(".gender-card.is-female").click();
    await page.locator(".login-panel").waitFor({ timeout: 10000 });
    assert.equal(await page.evaluate(() => localStorage.getItem("revo-profile-gender")), "female");
    assert.equal(await page.evaluate(() => document.documentElement.getAttribute("data-gender")), "female");
    assert.equal(await page.locator(".gender-gate").count(), 0);
    await context.close();
    console.log("PASS: gender gate at startup, selection persists, data-gender theme applied, gate dismissed.");
  }

  /* 2) Gender-specific exercise media in the student workout.
     The production bundle inlines local images as data URLs, so compare bytes. */
  const dataUrl = (rel) => "data:image/jpeg;base64," + fs.readFileSync(path.join(process.cwd(), rel)).toString("base64");
  const femaleSquatUrl = dataUrl("src/auth/reel-female/squat.jpg");
  const femaleHipUrl = dataUrl("src/auth/reel-female/hip-thrust.jpg");
  await session("student", "female", async (page) => {
    await page.getByRole("button", { name: "تمرین", exact: true }).last().click();
    await page.locator(".iw-overview-start").waitFor();
    const srcs = await page.locator(".iw-overview-thumb img").evaluateAll((nodes) => nodes.map((n) => n.getAttribute("src") || ""));
    assert(srcs.length >= 2, "workout overview must list exercises");
    assert.equal(srcs[0], femaleSquatUrl, "ex-squat must show the women's squat photo");
    assert.equal(srcs[1], femaleHipUrl, "ex-hip must show the women's hip-thrust photo");
    await page.screenshot({ path: path.join(shots, "female-workout.png") });
  });
  await session("student", "male", async (page) => {
    await page.getByRole("button", { name: "تمرین", exact: true }).last().click();
    await page.locator(".iw-overview-start").waitFor();
    const srcs = await page.locator(".iw-overview-thumb img").evaluateAll((nodes) => nodes.map((n) => n.getAttribute("src") || ""));
    assert(srcs.length >= 2, "workout overview must list exercises");
    assert(srcs.every((src) => !src.includes("base64")), `male media must not be the women's bundle: ${srcs.map((s) => s.slice(0, 60)).join(" | ")}`);
    assert(srcs.every((src) => src.startsWith("http")), "men keep the original male catalogue media");
    await page.screenshot({ path: path.join(shots, "male-workout.png") });
  });
  console.log("PASS: workout imagery is gender-specific for women and men.");

  /* 3) Gender-specific exercise catalogue in the coach moves centre. */
  await session("coach", "female", async (page) => {
    await page.evaluate(() => { window.location.hash = "/coach/moves"; });
    await page.locator(".iw-overview, [class*='library-hero']").first().waitFor({ timeout: 10000 });
    await page.waitForTimeout(400);
    const text = await page.locator("body").innerText();
    assert(text.includes("پل باسن"), "female-only move must appear for women");
    assert(!text.includes("زیربغل هالتر خم"), "male-only move must stay hidden for women");
  });
  await session("coach", "male", async (page) => {
    await page.evaluate(() => { window.location.hash = "/coach/moves"; });
    await page.locator("[class*='library-hero']").first().waitFor({ timeout: 10000 });
    await page.waitForTimeout(400);
    const text = await page.locator("body").innerText();
    assert(text.includes("زیربغل هالتر خم"), "male-only move must appear for men");
    assert(!text.includes("پل باسن"), "female-only move must stay hidden for men");
    await page.screenshot({ path: path.join(shots, "male-moves.png") });
  });
  console.log("PASS: male/female-only exercises are filtered correctly in the moves centre.");

  /* 4) Gender can be changed later in settings and updates the theme. */
  await session("student", "male", async (page) => {
    // The student shell forces Home on first mount, so navigate after it settles.
    await page.waitForTimeout(500);
    await page.evaluate(() => { window.location.hash = "/student/profile"; });
    await page.getByRole("button", { name: "ظاهر", exact: true }).first().waitFor({ timeout: 15000 });
    await page.getByRole("button", { name: "ظاهر", exact: true }).first().click();
    await page.getByRole("button", { name: "بانوان", exact: true }).first().waitFor({ timeout: 15000 });
    await page.waitForTimeout(300);
    await page.getByRole("button", { name: "بانوان", exact: true }).first().click();
    await page.waitForTimeout(350);
    assert.equal(await page.evaluate(() => document.documentElement.getAttribute("data-gender")), "female");
    assert.equal(await page.evaluate(() => localStorage.getItem("revo-profile-gender")), "female");
    await page.screenshot({ path: path.join(shots, "settings-gender.png") });
    await page.getByRole("button", { name: "آقایان", exact: true }).first().click();
    await page.waitForTimeout(200);
    assert.equal(await page.evaluate(() => document.documentElement.getAttribute("data-gender")), "male");
  });
  console.log("PASS: gender preference is editable in settings and updates the theme live.");

  assert.deepEqual(errors, []);
  await browser.close();
  console.log("ALL GENDER CHECKS PASSED");
})().catch((error) => { console.error(error); process.exit(1); });
