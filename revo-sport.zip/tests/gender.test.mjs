import assert from "node:assert/strict";
import path from "node:path";
import { build } from "esbuild";

// Vite resolves image imports to URL strings; mirror that for Node tests.
const imagePathPlugin = {
  name: "image-path",
  setup(builder) {
    builder.onResolve({ filter: /\.(jpe?g|png|webp)$/ }, (args) => ({
      path: path.resolve(path.dirname(args.importer), args.path),
      namespace: "image-path",
    }));
    builder.onLoad({ filter: /.*/, namespace: "image-path" }, (args) => ({
      contents: `export default ${JSON.stringify(args.path)};`,
      loader: "js",
    }));
  },
};

async function load(entry) {
  const result = await build({ entryPoints: [entry], bundle: true, write: false, format: "cjs", platform: "node", plugins: [imagePathPlugin] });
  const module = { exports: {} };
  new Function("module", "exports", result.outputFiles[0].text)(module, module.exports);
  return module.exports;
}

const memory = new Map();
globalThis.localStorage = {
  getItem: (key) => memory.get(key) ?? null,
  setItem: (key, value) => memory.set(key, value),
  removeItem: (key) => memory.delete(key),
};
globalThis.document = {
  documentElement: {
    setAttribute: (key, value) => {
      if (key === "data-gender") memory.set("__document_gender", value);
    },
    removeAttribute: () => undefined,
  },
};

const { readGender, writeGender, hasGenderChoice, genderFromProfile, genderAccent, genderLabel } = await load("src/source/lib/gender.ts");
const { exerciseOverride, GENDER_FALLBACK_IMAGE, GENDER_INTRO_IMAGE } = await load("src/source/data/gender-exercises.ts");
const { libraryFor, EXERCISES } = await load("src/source/data/library.ts");

// Default and persistence
assert.equal(readGender(), "male");
assert.equal(hasGenderChoice(), false);
writeGender("female");
assert.equal(readGender(), "female");
assert.equal(hasGenderChoice(), true);
assert.equal(documentAttribute(), "female");
writeGender("male");
assert.equal(readGender(), "male");
assert.equal(documentAttribute(), "male");

function documentAttribute() {
  // gender.ts applyGenderTheme writes to document.documentElement when available
  return memory.get("__document_gender") ?? "female";
}

// Profile ↔ gender mapping
assert.equal(genderFromProfile("زن"), "female");
assert.equal(genderFromProfile("female"), "female");
assert.equal(genderFromProfile("مرد"), "male");
assert.equal(genderFromProfile(undefined), "male");
assert.equal(genderLabel("female"), "بانوان");
assert.equal(genderLabel("male"), "آقایان");

// Distinct accents per gender
assert.equal(genderAccent("male"), "#c9f31c");
assert.equal(genderAccent("female"), "#ff4d8d");

// Distinct media + copy per gender
writeGender("female");
const femaleSquat = exerciseOverride("ex-squat");
assert.ok(femaleSquat.image.includes("reel-female"), "female squat must use female imagery");
assert.equal(femaleSquat.name, "اسکوات باسن‌محور");
const femaleHip = exerciseOverride("ex-hip");
assert.ok(femaleHip.image.includes("reel-female/hip-thrust"));

writeGender("male");
const maleSquat = exerciseOverride("ex-squat");
assert.equal(maleSquat.image, undefined);
assert.equal(maleSquat.name, "اسکوات هالتر");
assert.equal(exerciseOverride("ex-curl").image, undefined);

// Gender-specific exercises are filtered from the library
const femaleLibrary = libraryFor("female").map((item) => item.id);
const maleLibrary = libraryFor("male").map((item) => item.id);
assert.ok(femaleLibrary.includes("ex-glute-bridge"));
assert.ok(femaleLibrary.includes("ex-cable-kickback"));
assert.ok(femaleLibrary.includes("ex-wall-sit"));
assert.ok(!femaleLibrary.includes("ex-barbell-row"), "male-only move must not appear for women");
assert.ok(maleLibrary.includes("ex-barbell-row"));
assert.ok(!maleLibrary.includes("ex-glute-bridge"), "female-only move must not appear for men");
assert.ok(femaleLibrary.length > 10 && maleLibrary.length > 10);
assert.equal(femaleLibrary.filter((id) => !maleLibrary.includes(id)).length, 3);
assert.equal(maleLibrary.filter((id) => !femaleLibrary.includes(id)).length, 1);

// Shared moves stay visible for both genders
for (const shared of ["ex-bench", "ex-squat", "ex-curl"]) {
  assert.ok(femaleLibrary.includes(shared) && maleLibrary.includes(shared));
}
assert.ok(EXERCISES.some((item) => item.id === "ex-crunch"));

// Dedicated fallbacks exist for each gender
assert.ok(GENDER_FALLBACK_IMAGE.female.includes("reel-female"));
assert.ok(GENDER_FALLBACK_IMAGE.male.includes("reel"));
assert.ok(GENDER_INTRO_IMAGE.female.includes("reel-female"));
assert.ok(GENDER_INTRO_IMAGE.male.includes("reel"));

console.log("Gender tests passed: selection persistence, theme accent, distinct media/copy, and male/female exercise filtering.");
