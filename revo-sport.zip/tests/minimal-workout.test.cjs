/* Run with BROWSER_MODULES pointing to an isolated Playwright + Chromium install. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const modules = process.env.BROWSER_MODULES || path.join(process.cwd(), 'node_modules');
const chromium = require(path.join(modules, '@sparticuz/chromium'));
const { chromium: pw } = require(path.join(modules, 'playwright'));
const base = process.env.APP_URL || 'http://localhost:5173';
const shots = process.env.SCREENSHOTS || '/tmp/revo-minimal-shots';
fs.mkdirSync(shots, { recursive: true });
const poster = `data:image/jpeg;base64,${fs.readFileSync('src/auth/reel/bench.jpg').toString('base64')}`;
const avatar = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><rect width="20" height="20" fill="#444"/></svg>');
const date = new Date().toISOString();
const users = [
  { id: 'coach-minimal', role: 'coach', name: 'مربی آزمایشی', email: 'coach@test.dev', password: 'Test1234', phone: '', avatar, createdAt: date, lastLoginAt: date, inviteCode: 'SIMPL1' },
  { id: 'athlete-minimal', role: 'student', name: 'ورزشکار آزمایشی', email: 'athlete@test.dev', password: 'Test1234', phone: '', avatar, createdAt: date, lastLoginAt: date },
];
const student = { id: 'st-minimal', userId: users[1].id, coachId: users[0].id, age: 26, gender: 'مرد', height: 180, weight: 80, goal: 'فیتنس', level: 'متوسط', experience: '', startDate: '2025-01-01', subEndsAt: '2099-01-01', subscription: 'فعال', daysLeft: 40, daysSinceWorkout: 0, notes: '', status: 'active', category: '', assessment: { mainGoal: 'فیتنس', level: 'متوسط', history: '', daysPerWeek: 4, sessionMinutes: 45, equipment: ['هالتر'], lifestyle: '', dailyActivity: 'متوسط', sleepHours: 7, foodPrefs: '', limitations: '' } };
const move = { id: 'custom-bench', coachId: users[0].id, name: 'پرس سینه هالتر', en: 'Bench Press', muscle: 'سینه', equipment: 'هالتر', level: 'متوسط', imageUrl: poster, imageMediaId: '', videoUrl: '', videoMediaId: '', how: 'حرکت را کنترل‌شده اجرا کن.', tips: 'کتف‌ها را ثابت نگه دار.', defaultSets: 4, defaultReps: '6', defaultWeight: '80', defaultRest: 20, defaultRpe: 7, defaultTempo: '3-0-1', createdAt: date };
const weekday = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];
function fixture({ count = 2, sets = 4, rest = 20 } = {}) {
  const days = weekday.map((day, dayIndex) => ({ id: `day-${dayIndex}`, weekday: day, focus: 'بالاتنه', items: Array.from({ length: count }, (_, i) => ({ id: `item-${dayIndex}-${i}`, exerciseId: move.id, sets: i === 0 ? sets : 1, reps: '6', weight: '80', rest: i === 0 ? rest : 0, tempo: '3-0-1', rpe: 7, notes: 'کتف‌ها را ثابت نگه دار.' })) }));
  return { users, students: [student], programs: [{ id: 'plan-minimal', studentId: student.id, name: 'برنامهٔ قدرت', goal: 'فیتنس', weeks: 8, startDate: '2025-01-01', endDate: '2099-01-01', days, status: 'فعال', createdAt: date }], logs: [], meals: [], progress: [], photos: [], goals: [], messages: [], notifs: [], appts: [], invoices: [], water: {}, sleep: {}, xp: {}, streak: {}, coachExercises: [move], coachPlans: {}, foods: [], nutritionLogs: [], checkins: [], workoutTemplates: [] };
}

(async () => {
  const browser = await pw.launch({ executablePath: await chromium.executablePath(), args: chromium.args.filter(arg => arg !== '--single-process'), headless: true });
  const errors = [];
  async function open(viewport, data = fixture(), lang = 'fa') {
    const context = await browser.newContext({ viewport, locale: lang === 'fa' ? 'fa-IR' : 'en-US', reducedMotion: 'reduce' });
    const page = await context.newPage();
    page.on('pageerror', error => errors.push(error.message));
    await page.route('**/api/health', route => route.fulfill({ status: 200, contentType: 'application/json', body: '{"app":"local"}' }));
    await page.route('https://invalid.test/**', route => route.abort());
    await page.addInitScript(({ data, lang }) => {
      if (!localStorage.getItem('revofit-coach-v3')) localStorage.setItem('revofit-coach-v3', JSON.stringify({ data, session: { userId: 'athlete-minimal', role: 'student' }, light: false, prefs: {} }));
      const seen = { status: 'completed', step: '', updatedAt: new Date().toISOString() };
      localStorage.setItem('revo-guides-v1:student:athlete-minimal', JSON.stringify({ home: seen, 'workout-session': seen, history: seen }));
      localStorage.setItem('revo-lang', lang);
    }, { data, lang });
    await page.goto(`${base}/#/student`, { waitUntil: 'domcontentloaded' });
    await page.locator('[data-guide="student-nav-workout"]').click();
    await page.locator('.iw-overview-start').waitFor();
    if (!fs.existsSync(path.join(shots, 'workout-overview.png'))) {
      await page.waitForTimeout(250);
      await page.screenshot({ path: path.join(shots, 'workout-overview.png') });
    }
    await page.locator('.iw-overview-start').click();
    await page.locator('.iw-screen').waitFor();
    await page.waitForFunction(() => { const img = document.querySelector('.iw-poster'); return img?.complete && img.naturalWidth > 0; });
    return { context, page };
  }
  async function withinViewport(page, selector) {
    const box = await page.locator(selector).boundingBox();
    const v = page.viewportSize();
    assert(box && box.x >= -1 && box.y >= -1 && box.x + box.width <= v.width + 1 && box.y + box.height <= v.height + 1, `${selector}: ${JSON.stringify({ box, v })}`);
  }
  const { context, page } = await open({ width: 390, height: 844 });
  const player = page.locator('.iw-screen');
  const bounds = await player.boundingBox();
  assert.equal(bounds.x, 0); assert.equal(bounds.y, 0); assert.equal(bounds.width, 390); assert.equal(bounds.height, 844);
  assert.equal(await page.locator('[data-guide-scope="student"]').evaluate(el => el.inert), true);
  assert.equal(await player.locator('.iw-topbar button').count(), 2);
  assert.equal(await player.locator('.iw-sheet').count(), 0);
  assert.equal(await player.locator('.iw-quick-bar').count(), 0);
  assert.equal(await player.locator('.iw-set-row').count(), 4);
  assert.equal(await player.getByRole('button', { name: 'افزایش وزن' }).count(), 0);
  assert.equal(await player.locator('.iw-active-dot').count(), 1);
  await withinViewport(page, '.iw-footer');
  await page.screenshot({ path: path.join(shots, 'minimal-workout.png') });

  // Add extra set and remove it cleanly.
  await player.getByRole('button', { name: 'ست اضافه' }).click();
  assert.equal(await player.locator('.iw-set-row').count(), 5);
  await player.getByRole('button', { name: 'حذف ست آخر' }).click();
  assert.equal(await player.locator('.iw-set-row').count(), 4);

  // Set type tag cycles on tap without extra row buttons.
  await player.locator('.iw-set-number').nth(1).click();
  assert.equal(await player.locator('.iw-set-number').nth(1).innerText(), 'W');
  await player.locator('.iw-set-number').nth(1).click();
  await player.locator('.iw-set-number').nth(1).click();
  await player.locator('.iw-set-number').nth(1).click();

  // Notes, RIR, 1RM records and Plate Calculator live in the 3-tab Pro Sheet.
  await player.locator('.iw-exercise-title').click();
  await page.locator('.iw-sheet').waitFor();
  assert(await page.locator('.iw-coach-note').isVisible());
  await page.locator('.iw-rir-field select').selectOption('2');
  await page.getByRole('tab', { name: 'ابزارها' }).click();
  assert(await page.locator('.iw-plates-visual').isVisible());
  await page.screenshot({ path: path.join(shots, 'pro-sheet-tools.png') });
  await page.getByRole('tab', { name: 'رکورد و سوابق' }).click();
  assert(await page.locator('.iw-records-grid').isVisible());
  await page.keyboard.press('Escape');
  assert.equal(await page.locator('.iw-sheet').count(), 0);
  assert.equal(await page.locator('.iw-screen').count(), 1);

  await player.getByRole('textbox', { name: 'وزن ست 1', exact: true }).fill('۸۲٫۵');
  await player.getByRole('textbox', { name: 'تکرار ست 1', exact: true }).fill('۸');
  assert.equal(await player.getByRole('textbox', { name: 'وزن ست 1', exact: true }).inputValue(), '82.5');
  await player.getByRole('button', { name: 'تیک ست 1', exact: true }).click();
  await page.locator('.rest-overlay').waitFor();
  await page.screenshot({ path: path.join(shots, 'minimal-rest.png') });
  assert.equal(await player.evaluate(el => el.inert), true);
  assert.equal(await page.locator('.iw-rest-controls').count(), 0);
  await page.getByRole('button', { name: 'تنظیم زمان استراحت' }).click();
  await page.getByRole('button', { name: 'توقف استراحت' }).click();
  const beforePause = await page.locator('.iw-countdown').innerText();
  await page.waitForTimeout(1150);
  assert.equal(await page.locator('.iw-countdown').innerText(), beforePause);
  await page.getByRole('button', { name: '۱۵ ثانیه بیشتر' }).click();
  await page.getByRole('button', { name: 'ادامه استراحت' }).click();
  await page.getByRole('button', { name: 'رد کردن', exact: true }).click();
  assert.equal(await player.evaluate(el => el.inert), false);
  assert.equal(await player.locator('.iw-check.is-done').count(), 1);
  await page.screenshot({ path: path.join(shots, 'minimal-completed-set.png') });
  // Undo and recomplete remain available.
  await player.getByRole('button', { name: 'لغو تیک ست 1' }).click();
  assert.equal(await player.locator('.iw-check.is-done').count(), 0);
  await player.getByRole('button', { name: 'تیک ست 1', exact: true }).click();
  await page.getByRole('button', { name: 'رد کردن', exact: true }).click();
  // Explicit zero kilograms must not be replaced by the coach's 80 kg.
  await player.getByRole('textbox', { name: 'وزن ست 2' }).fill('0');
  for (let i = 2; i <= 4; i++) {
    await player.getByRole('button', { name: `تیک ست ${i}`, exact: true }).click();
    await page.getByRole('button', { name: 'رد کردن', exact: true }).click();
  }
  await page.waitForTimeout(100);
  assert.equal(await player.locator('.iw-page[aria-current="step"]').innerText(), '2');
  await player.getByRole('button', { name: 'تیک ست 1', exact: true }).click();
  await page.getByRole('dialog', { name: 'خلاصهٔ تمرین' }).waitFor();
  await page.getByRole('button', { name: 'ذخیره و ارسال برای مربی' }).click();
  await page.waitForTimeout(400);
  const log = await page.evaluate(() => JSON.parse(localStorage.getItem('revofit-coach-v3')).data.logs[0]);
  assert.equal(log.items[0].sets[0].weight, 82.5);
  assert.equal(log.items[0].sets[0].reps, 8);
  assert.equal(log.items[0].sets[0].rpe, 8);
  assert.equal(log.items[0].sets[1].weight, 0);
  assert.equal(log.items.flatMap(item => item.sets).filter(set => set.done).length, 5);
  assert.equal(await page.locator('.iw-layer').count(), 0);
  assert.equal(await page.locator('[data-guide-scope="student"]').evaluate(el => el.inert), false);
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.locator('[data-guide="student-nav-workout"]').click();
  assert(await page.getByText('تمرین امروز ثبت شد', { exact: true }).isVisible());
  await context.close();
  console.log('PASS: fullscreen composition, on-demand details, numeric editing, completion, rest pause/adjust/skip, saved RIR/zero weight, reload persistence.');

  for (const viewport of [{ width: 320, height: 568 }, { width: 844, height: 390 }, { width: 768, height: 1024 }, { width: 1440, height: 900 }]) {
    const screen = await open(viewport, fixture({ count: 12, sets: 12 }));
    await withinViewport(screen.page, '.iw-screen');
    await withinViewport(screen.page, '.iw-footer');
    const sets = screen.page.locator('.iw-sets');
    assert(await sets.evaluate(el => el.scrollHeight > el.clientHeight));
    await screen.page.locator('.iw-pager button').last().click();
    await screen.page.waitForTimeout(200);
    assert.equal(await screen.page.locator('.iw-page[aria-current="step"]').innerText(), '12');
    await withinViewport(screen.page, '.iw-page[aria-current="step"]');
    await screen.page.locator('.iw-exercise-title').click();
    await withinViewport(screen.page, '.iw-sheet');
    await screen.page.keyboard.press('Escape');
    await screen.page.getByRole('button', { name: 'بازگشت به فهرست' }).click();
    assert(await screen.page.locator('.iw-overview-start').isVisible());
    await screen.page.locator('.iw-overview-start').click();
    await screen.page.screenshot({ path: path.join(shots, `responsive-${viewport.width}.png`) });
    await screen.context.close();
  }
  console.log('PASS: 320px phone, landscape, tablet, desktop; 12 sets/exercises; returning and resuming.');
  const last = await open({ width: 390, height: 844 }, fixture({ count: 1, sets: 1, rest: 15 }), 'en');
  await last.page.getByRole('button', { name: 'Complete set 1' }).click();
  await last.page.getByRole('button', { name: 'Skip', exact: true }).click();
  await last.page.locator('.iw-modal-panel').waitFor();
  assert.equal(await last.page.locator('.rest-overlay').count(), 0);
  await last.context.close();
  // Generate a tiny real video solely for playback-control testing.
  const generator = await browser.newPage();
  const videoData = await generator.evaluate(async () => {
    const canvas = document.createElement('canvas'); canvas.width = 64; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    const stream = canvas.captureStream(12);
    const chunks = [];
    const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
    const result = new Promise(resolve => { recorder.onstop = () => {
      const reader = new FileReader(); reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(new Blob(chunks, { type: 'video/webm' }));
    }; });
    recorder.ondataavailable = e => chunks.push(e.data);
    recorder.start();
    const timer = setInterval(() => { ctx.fillStyle = '#555'; ctx.fillRect(0, 0, 64, 64); ctx.fillStyle = '#999'; ctx.fillRect(Math.random()*40, 10, 20, 40); }, 60);
    await new Promise(resolve => setTimeout(resolve, 600));
    clearInterval(timer); recorder.stop();
    const source = await result; stream.getTracks().forEach(track => track.stop()); return source;
  });
  await generator.close();
  const videoFixture = fixture(); videoFixture.coachExercises = [{ ...move, videoUrl: videoData }];
  const playback = await open({ width: 390, height: 844 }, videoFixture);
  await playback.page.locator('.iw-video.is-ready').waitFor();
  await playback.page.getByRole('button', { name: 'توقف ویدیو', exact: true }).click();
  assert.equal(await playback.page.locator('.iw-video').evaluate(video => video.paused), true);
  await playback.page.getByRole('button', { name: 'ادامه ویدیو', exact: true }).click();
  await playback.page.waitForFunction(() => !document.querySelector('.iw-video').paused);
  await playback.context.close();

  const brokenFixture = fixture(); brokenFixture.coachExercises = [{ ...move, videoUrl: 'https://invalid.test/video.mp4', imageUrl: poster }];
  const broken = await open({ width: 390, height: 844 }, brokenFixture);
  await broken.page.getByRole('button', { name: 'جزئیات و تنظیمات تمرین', exact: true }).waitFor();
  assert(await broken.page.locator('.iw-poster').isVisible());
  await broken.context.close();
  console.log('PASS: real video play/pause/resume and photo fallback when video is unavailable.');
  assert.deepEqual(errors, []);
  await browser.close();
  console.log('PASS: English/LTR and finishing after the final rest. No runtime errors.');
})().catch(error => { console.error(error); process.exit(1); });