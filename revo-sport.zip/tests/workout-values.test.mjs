import assert from "node:assert/strict";
import { build } from "esbuild";

const bundle = await build({ entryPoints: ["src/source/lib/workout-values.ts"], bundle: true, write: false, format: "cjs", platform: "node" });
const mod = { exports: {} };
new Function("module", "exports", bundle.outputFiles[0].text)(mod, mod.exports);
const { cleanWorkoutInput, prescribedMetric, resolvedMetric } = mod.exports;

assert.equal(cleanWorkoutInput("۸۲٫۵", true), "82.5");
assert.equal(cleanWorkoutInput("٨٢,٥", true), "82.5");
assert.equal(cleanWorkoutInput("1.2.3", true), "1.23");
assert.equal(cleanWorkoutInput("۱۲", false), "12");
assert.equal(prescribedMetric("۸۰ کیلو", "weight"), 80);
assert.equal(prescribedMetric("80 kg", "weight"), 80);
assert.equal(prescribedMetric("RPE 8", "weight"), 0);
assert.equal(prescribedMetric("وزن بدن", "weight"), 0);
assert.equal(prescribedMetric("۸ تا ۱۲", "reps"), 8);
assert.equal(resolvedMetric("0", "80", "weight"), 0);
assert.equal(resolvedMetric("", "80", "weight"), 80);
assert.equal(resolvedMetric("۸۲٫۵", "80", "weight"), 82.5);
assert.equal(resolvedMetric("۰", "10", "reps"), 0);
assert.equal(resolvedMetric(undefined, "12", "reps"), 12);
assert.equal(resolvedMetric("", "RPE ۸", "weight"), 0);

const { estimate1RM, calculatePlates } = mod.exports;
assert.equal(estimate1RM(100, 1), 100);
assert.equal(estimate1RM(90, 5), 105);
assert.equal(estimate1RM(0, 10), 0);
assert.deepEqual(calculatePlates(100, 20), { perSide: 40, plates: [25, 15], remainder: 0 });
assert.deepEqual(calculatePlates(62.5, 20), { perSide: 21.25, plates: [20, 1.25], remainder: 0 });
assert.deepEqual(calculatePlates(15, 20), { perSide: 0, plates: [], remainder: 0 });
console.log("Workout values passed: Persian/Arabic digits, decimal input, zero weight, 1RM and plate calculator.");